<?php
/**
 * Application Configuration
 * National Agro Business Support Initiative
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* -----------------------------
   App identity / environment
----------------------------- */
define('APP_NAME', ' Kaliro Lords Community Development Corporation');
define('APP_VERSION', '1.0.0');

/**
 * Build APP_URL dynamically so buttons/links don’t point to localhost.
 * Works for localhost subfolders, tunnels, and real domains.
 */
if (!defined('APP_URL')) {
    $isHttps = (
        (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443)
    );
    $scheme = $isHttps ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';

    // Figure out the web path to your project root based on filesystem paths
    $docRoot = isset($_SERVER['DOCUMENT_ROOT']) ? realpath($_SERVER['DOCUMENT_ROOT']) : null;
    $projRoot = realpath(dirname(__DIR__)); // one level up from /config

    $relPath = '';
    if ($docRoot && $projRoot && strpos($projRoot, $docRoot) === 0) {
        $relPath = str_replace('\\', '/', substr($projRoot, strlen($docRoot)));
    }

    // Ensure leading slash if there is a relative path
    if ($relPath !== '' && $relPath[0] !== '/') $relPath = '/' . $relPath;

    define('APP_URL', $scheme . '://' . $host . $relPath);
}

/* -----------------------------
   Security / sessions
----------------------------- */
define('SESSION_TIMEOUT', 3600);     // 1 hour
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_TIME', 900);         // 15 minutes

/* -----------------------------
   Uploads / files
----------------------------- */
define('UPLOAD_PATH', 'uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_EXTENSIONS', ['jpg','jpeg','png','gif']);

/* -----------------------------
   PDF / company branding
----------------------------- */
define('PDF_TEMP_PATH', 'temp/');
define('COMPANY_NAME',   'National Agro Business Support Initiative');
define('COMPANY_ADDRESS','Agricultural Development Center, Uganda');
define('COMPANY_PHONE',  '+256-xxx-xxx-xxxx');
define('COMPANY_EMAIL',  'info@agrobusiness.co.ug');

/* -----------------------------
   Registration
----------------------------- */
define('ALLOW_PUBLIC_REGISTRATION', true);

/* -----------------------------
   Timezone / errors
----------------------------- */
date_default_timezone_set('Africa/Kampala');
error_reporting(E_ALL);
ini_set('display_errors', 1);

/* -----------------------------
   Database bootstrap
   IMPORTANT: we only include database.php and DO NOT
   declare getDbConnection() here to avoid redeclare errors.
----------------------------- */
require_once __DIR__ . '/database.php';

/* -----------------------------
   Helpers
----------------------------- */
function sanitize_input($data) {
    return htmlspecialchars(stripslashes(trim((string)$data)), ENT_QUOTES, 'UTF-8');
}

function generateRandomString($length = 10) {
    $length = max(2, (int)$length);
    // ensure even length for bin2hex
    if ($length % 2 !== 0) $length++;
    return bin2hex(random_bytes($length / 2));
}

function formatCurrency($amount) {
    $n = (float)$amount;
    return 'UGX ' . number_format($n, 0, '.', ',');
}

function formatDate($date, $format = 'Y-m-d H:i:s') {
    $ts = is_numeric($date) ? (int)$date : strtotime((string)$date);
    if (!$ts) return '';
    return date($format, $ts);
}

function isLoggedIn() {
    return !empty($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function redirect($url) {
    header("Location: $url");
    exit;
}

function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCSRFToken($token) {
    return !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], (string)$token);
}

function logActivity($message, $user_id = null) {
    $logDir  = __DIR__ . '/../logs';
    $logFile = $logDir . '/activity.log';
    if (!is_dir($logDir)) {
        @mkdir($logDir, 0755, true);
    }
    $timestamp = date('Y-m-d H:i:s');
    $userInfo  = $user_id ? " [User: $user_id]" : "";
    $entry     = "[$timestamp]$userInfo $message" . PHP_EOL;
    file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);
}

/**
 * Optional: simple session timeout enforcement (keeps your existing behavior)
 */
if (!empty($_SESSION['last_activity']) && (time() - (int)$_SESSION['last_activity'] > SESSION_TIMEOUT)) {
    session_unset();
    session_destroy();
    session_start();
}
$_SESSION['last_activity'] = time();
