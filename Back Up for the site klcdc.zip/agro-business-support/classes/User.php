<?php
/**
 * User Management Class
 * National Agro Business Support Initiative
 */

require_once '../config/config.php';

class User {
    private $conn;

    public function __construct() {
        $this->conn = getDbConnection();
    }

    /**
     * Create new user
     */
    public function createUser($data) {
        try {
            $this->conn->beginTransaction();

            // Check if username or email already exists
            $query = "SELECT id FROM users WHERE username = :username OR email = :email";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':username', $data['username']);
            $stmt->bindParam(':email', $data['email']);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                $this->conn->rollBack();
                return [
                    'success' => false,
                    'message' => 'Username or email already exists'
                ];
            }

            // Create user
            $hashed_password = password_hash($data['password'], PASSWORD_DEFAULT);
            $query = "INSERT INTO users (username, email, password, role, status)
                     VALUES (:username, :email, :password, :role, :status)";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':username', $data['username']);
            $stmt->bindParam(':email', $data['email']);
            $stmt->bindParam(':password', $hashed_password);
            $stmt->bindParam(':role', $data['role']);
            $stmt->bindParam(':status', $data['status']);
            $stmt->execute();

            $user_id = $this->conn->lastInsertId();

            $this->conn->commit();

            logActivity("User created: " . $data['username'], $_SESSION['user_id'] ?? null);

            return [
                'success' => true,
                'message' => 'User created successfully',
                'user_id' => $user_id
            ];

        } catch (Exception $e) {
            $this->conn->rollBack();
            error_log("Create user error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Failed to create user'
            ];
        }
    }

    /**
     * Update user
     */
    public function updateUser($user_id, $data) {
        try {
            // Check if username or email already exists for other users
            $query = "SELECT id FROM users WHERE (username = :username OR email = :email) AND id != :user_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':username', $data['username']);
            $stmt->bindParam(':email', $data['email']);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                return [
                    'success' => false,
                    'message' => 'Username or email already exists'
                ];
            }

            // Update user
            $query = "UPDATE users SET username = :username, email = :email, role = :role,
                     status = :status, updated_at = CURRENT_TIMESTAMP WHERE id = :user_id";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':username', $data['username']);
            $stmt->bindParam(':email', $data['email']);
            $stmt->bindParam(':role', $data['role']);
            $stmt->bindParam(':status', $data['status']);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();

            logActivity("User updated: " . $data['username'], $_SESSION['user_id'] ?? null);

            return [
                'success' => true,
                'message' => 'User updated successfully'
            ];

        } catch (Exception $e) {
            error_log("Update user error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Failed to update user'
            ];
        }
    }

    /**
     * Delete user
     */
    public function deleteUser($user_id) {
        try {
            // Check if user has related data
            $query = "SELECT COUNT(*) as count FROM investors WHERE user_id = :user_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();
            $result = $stmt->fetch();

            if ($result['count'] > 0) {
                return [
                    'success' => false,
                    'message' => 'Cannot delete user with investor profile'
                ];
            }

            // Delete user
            $query = "DELETE FROM users WHERE id = :user_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();

            logActivity("User deleted (ID: $user_id)", $_SESSION['user_id'] ?? null);

            return [
                'success' => true,
                'message' => 'User deleted successfully'
            ];

        } catch (Exception $e) {
            error_log("Delete user error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Failed to delete user'
            ];
        }
    }

    /**
     * Get all users
     */
    public function getAllUsers($limit = 50, $offset = 0, $search = '') {
        try {
            $where_clause = "";
            $params = [];

            if (!empty($search)) {
                $where_clause = "WHERE u.username LIKE :search OR u.email LIKE :search";
                $params[':search'] = "%$search%";
            }

            $query = "SELECT u.*,
                     CASE WHEN i.id IS NOT NULL THEN 'Yes' ELSE 'No' END as has_investor_profile
                     FROM users u
                     LEFT JOIN investors i ON u.id = i.user_id
                     $where_clause
                     ORDER BY u.created_at DESC
                     LIMIT :limit OFFSET :offset";

            $stmt = $this->conn->prepare($query);

            foreach ($params as $key => $value) {
                $stmt->bindParam($key, $value);
            }

            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();

            return $stmt->fetchAll();

        } catch (Exception $e) {
            error_log("Get all users error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get user by ID
     */
    public function getUserById($user_id) {
        try {
            $query = "SELECT u.*, i.account_number, i.first_name, i.last_name
                     FROM users u
                     LEFT JOIN investors i ON u.id = i.user_id
                     WHERE u.id = :user_id";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();

            return $stmt->fetch();

        } catch (Exception $e) {
            error_log("Get user by ID error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get total users count
     */
    public function getTotalUsersCount($search = '') {
        try {
            $where_clause = "";
            $params = [];

            if (!empty($search)) {
                $where_clause = "WHERE username LIKE :search OR email LIKE :search";
                $params[':search'] = "%$search%";
            }

            $query = "SELECT COUNT(*) as total FROM users $where_clause";
            $stmt = $this->conn->prepare($query);

            foreach ($params as $key => $value) {
                $stmt->bindParam($key, $value);
            }

            $stmt->execute();
            $result = $stmt->fetch();

            return $result['total'];

        } catch (Exception $e) {
            error_log("Get total users count error: " . $e->getMessage());
            return 0;
        }
    }

    /**
     * Update user status
     */
    public function updateUserStatus($user_id, $status) {
        try {
            $query = "UPDATE users SET status = :status, updated_at = CURRENT_TIMESTAMP WHERE id = :user_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':status', $status);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();

            logActivity("User status updated to $status (ID: $user_id)", $_SESSION['user_id'] ?? null);

            return [
                'success' => true,
                'message' => 'User status updated successfully'
            ];

        } catch (Exception $e) {
            error_log("Update user status error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Failed to update user status'
            ];
        }
    }
}
?>
