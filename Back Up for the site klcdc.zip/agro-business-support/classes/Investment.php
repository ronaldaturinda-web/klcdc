<?php
/**
 * Investment Management Class
 * National Agro Business Support Initiative
 */

require_once '../config/config.php';

class Investment {
    private $conn;

    public function __construct() {
        $this->conn = getDbConnection();
    }

    /**
     * Record new investment
     */
    public function recordInvestment($data) {
        try {
            $this->conn->beginTransaction();

            // Generate transaction ID and receipt number
            $transaction_id = $this->generateTransactionId();
            $receipt_number = $this->generateReceiptNumber();

            // Create investment record
            $query = "INSERT INTO investments (investor_id, transaction_id, investment_type, amount,
                     description, investment_date, receipt_number, payment_method, notes, status, recorded_by)
                     VALUES (:investor_id, :transaction_id, :investment_type, :amount, :description,
                     :investment_date, :receipt_number, :payment_method, :notes, :status, :recorded_by)";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':investor_id', $data['investor_id']);
            $stmt->bindParam(':transaction_id', $transaction_id);
            $stmt->bindParam(':investment_type', $data['investment_type']);
            $stmt->bindParam(':amount', $data['amount']);
            $stmt->bindParam(':description', $data['description']);
            $stmt->bindParam(':investment_date', $data['investment_date']);
            $stmt->bindParam(':receipt_number', $receipt_number);
            $stmt->bindParam(':payment_method', $data['payment_method']);
            $stmt->bindParam(':notes', $data['notes']);
            $stmt->bindParam(':status', $data['status']);
            $stmt->bindParam(':recorded_by', $data['recorded_by']);
            $stmt->execute();

            $investment_id = $this->conn->lastInsertId();

            $this->conn->commit();

            logActivity("Investment recorded: $transaction_id (Amount: " . formatCurrency($data['amount']) . ")", $data['recorded_by']);

            return [
                'success' => true,
                'message' => 'Investment recorded successfully',
                'investment_id' => $investment_id,
                'transaction_id' => $transaction_id,
                'receipt_number' => $receipt_number
            ];

        } catch (Exception $e) {
            $this->conn->rollBack();
            error_log("Record investment error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Failed to record investment'
            ];
        }
    }

    /**
     * Update investment
     */
    public function updateInvestment($investment_id, $data) {
        try {
            $query = "UPDATE investments SET investment_type = :investment_type, amount = :amount,
                     description = :description, investment_date = :investment_date,
                     payment_method = :payment_method, notes = :notes, status = :status,
                     updated_at = CURRENT_TIMESTAMP WHERE id = :investment_id";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':investment_type', $data['investment_type']);
            $stmt->bindParam(':amount', $data['amount']);
            $stmt->bindParam(':description', $data['description']);
            $stmt->bindParam(':investment_date', $data['investment_date']);
            $stmt->bindParam(':payment_method', $data['payment_method']);
            $stmt->bindParam(':notes', $data['notes']);
            $stmt->bindParam(':status', $data['status']);
            $stmt->bindParam(':investment_id', $investment_id);
            $stmt->execute();

            logActivity("Investment updated (ID: $investment_id)", $_SESSION['user_id'] ?? null);

            return [
                'success' => true,
                'message' => 'Investment updated successfully'
            ];

        } catch (Exception $e) {
            error_log("Update investment error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Failed to update investment'
            ];
        }
    }

    /**
     * Delete investment
     */
    public function deleteInvestment($investment_id) {
        try {
            // Get investment details for logging
            $investment = $this->getInvestmentById($investment_id);

            $query = "DELETE FROM investments WHERE id = :investment_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':investment_id', $investment_id);
            $stmt->execute();

            if ($investment) {
                logActivity("Investment deleted: " . $investment['transaction_id'], $_SESSION['user_id'] ?? null);
            }

            return [
                'success' => true,
                'message' => 'Investment deleted successfully'
            ];

        } catch (Exception $e) {
            error_log("Delete investment error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Failed to delete investment'
            ];
        }
    }

    /**
     * Get all investments
     */
    public function getAllInvestments($limit = 50, $offset = 0, $filters = []) {
        try {
            $where_conditions = [];
            $params = [];

            // Search filter
            if (!empty($filters['search'])) {
                $where_conditions[] = "(inv.transaction_id LIKE :search OR inv.receipt_number LIKE :search
                                     OR i.account_number LIKE :search OR CONCAT(i.first_name, ' ', i.last_name) LIKE :search)";
                $params[':search'] = "%{$filters['search']}%";
            }

            // Date range filter
            if (!empty($filters['date_from'])) {
                $where_conditions[] = "inv.investment_date >= :date_from";
                $params[':date_from'] = $filters['date_from'] . ' 00:00:00';
            }

            if (!empty($filters['date_to'])) {
                $where_conditions[] = "inv.investment_date <= :date_to";
                $params[':date_to'] = $filters['date_to'] . ' 23:59:59';
            }

            // Investment type filter
            if (!empty($filters['investment_type'])) {
                $where_conditions[] = "inv.investment_type = :investment_type";
                $params[':investment_type'] = $filters['investment_type'];
            }

            // Status filter
            if (!empty($filters['status'])) {
                $where_conditions[] = "inv.status = :status";
                $params[':status'] = $filters['status'];
            }

            // Investor filter
            if (!empty($filters['investor_id'])) {
                $where_conditions[] = "inv.investor_id = :investor_id";
                $params[':investor_id'] = $filters['investor_id'];
            }

            $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

            $query = "SELECT inv.*,
                     CONCAT(i.first_name, ' ', i.last_name) as investor_name,
                     i.account_number,
                     CONCAT(u.username) as recorded_by_username
                     FROM investments inv
                     JOIN investors i ON inv.investor_id = i.id
                     JOIN users u ON inv.recorded_by = u.id
                     $where_clause
                     ORDER BY inv.investment_date DESC
                     LIMIT :limit OFFSET :offset";

            $stmt = $this->conn->prepare($query);

            foreach ($params as $key => $value) {
                $stmt->bindParam($key, $value);
            }

            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();

            return $stmt->fetchAll();

        } catch (Exception $e) {
            error_log("Get all investments error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get investment by ID
     */
    public function getInvestmentById($investment_id) {
        try {
            $query = "SELECT inv.*,
                     CONCAT(i.first_name, ' ', i.last_name) as investor_name,
                     i.account_number, i.phone, i.address,
                     CONCAT(u.username) as recorded_by_username
                     FROM investments inv
                     JOIN investors i ON inv.investor_id = i.id
                     JOIN users u ON inv.recorded_by = u.id
                     WHERE inv.id = :investment_id";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':investment_id', $investment_id);
            $stmt->execute();

            return $stmt->fetch();

        } catch (Exception $e) {
            error_log("Get investment by ID error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get investments by investor ID
     */
    public function getInvestmentsByInvestorId($investor_id, $limit = 50, $offset = 0) {
        try {
            $query = "SELECT inv.*,
                     CONCAT(u.username) as recorded_by_username
                     FROM investments inv
                     JOIN users u ON inv.recorded_by = u.id
                     WHERE inv.investor_id = :investor_id AND inv.status = 'confirmed'
                     ORDER BY inv.investment_date DESC
                     LIMIT :limit OFFSET :offset";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':investor_id', $investor_id);
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();

            return $stmt->fetchAll();

        } catch (Exception $e) {
            error_log("Get investments by investor ID error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get total investments count
     */
    public function getTotalInvestmentsCount($filters = []) {
        try {
            $where_conditions = [];
            $params = [];

            // Apply same filters as getAllInvestments
            if (!empty($filters['search'])) {
                $where_conditions[] = "(inv.transaction_id LIKE :search OR inv.receipt_number LIKE :search
                                     OR i.account_number LIKE :search OR CONCAT(i.first_name, ' ', i.last_name) LIKE :search)";
                $params[':search'] = "%{$filters['search']}%";
            }

            if (!empty($filters['date_from'])) {
                $where_conditions[] = "inv.investment_date >= :date_from";
                $params[':date_from'] = $filters['date_from'] . ' 00:00:00';
            }

            if (!empty($filters['date_to'])) {
                $where_conditions[] = "inv.investment_date <= :date_to";
                $params[':date_to'] = $filters['date_to'] . ' 23:59:59';
            }

            if (!empty($filters['investment_type'])) {
                $where_conditions[] = "inv.investment_type = :investment_type";
                $params[':investment_type'] = $filters['investment_type'];
            }

            if (!empty($filters['status'])) {
                $where_conditions[] = "inv.status = :status";
                $params[':status'] = $filters['status'];
            }

            if (!empty($filters['investor_id'])) {
                $where_conditions[] = "inv.investor_id = :investor_id";
                $params[':investor_id'] = $filters['investor_id'];
            }

            $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

            $query = "SELECT COUNT(*) as total FROM investments inv
                     JOIN investors i ON inv.investor_id = i.id
                     $where_clause";

            $stmt = $this->conn->prepare($query);

            foreach ($params as $key => $value) {
                $stmt->bindParam($key, $value);
            }

            $stmt->execute();
            $result = $stmt->fetch();

            return $result['total'];

        } catch (Exception $e) {
            error_log("Get total investments count error: " . $e->getMessage());
            return 0;
        }
    }

    /**
     * Get investment statistics
     */
    public function getInvestmentStatistics($filters = []) {
        try {
            $where_conditions = ["inv.status = 'confirmed'"];
            $params = [];

            // Apply date filters
            if (!empty($filters['date_from'])) {
                $where_conditions[] = "inv.investment_date >= :date_from";
                $params[':date_from'] = $filters['date_from'] . ' 00:00:00';
            }

            if (!empty($filters['date_to'])) {
                $where_conditions[] = "inv.investment_date <= :date_to";
                $params[':date_to'] = $filters['date_to'] . ' 23:59:59';
            }

            $where_clause = 'WHERE ' . implode(' AND ', $where_conditions);

            $query = "SELECT
                     COUNT(*) as total_transactions,
                     SUM(amount) as total_amount,
                     SUM(CASE WHEN investment_type = 'cash' THEN amount ELSE 0 END) as cash_total,
                     SUM(CASE WHEN investment_type = 'material' THEN amount ELSE 0 END) as material_total,
                     SUM(CASE WHEN investment_type = 'labor' THEN amount ELSE 0 END) as labor_total,
                     COUNT(CASE WHEN investment_type = 'cash' THEN 1 END) as cash_count,
                     COUNT(CASE WHEN investment_type = 'material' THEN 1 END) as material_count,
                     COUNT(CASE WHEN investment_type = 'labor' THEN 1 END) as labor_count,
                     AVG(amount) as average_investment
                     FROM investments inv $where_clause";

            $stmt = $this->conn->prepare($query);

            foreach ($params as $key => $value) {
                $stmt->bindParam($key, $value);
            }

            $stmt->execute();

            return $stmt->fetch();

        } catch (Exception $e) {
            error_log("Get investment statistics error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get monthly investment summary
     */
    public function getMonthlyInvestmentSummary($year = null) {
        try {
            $year = $year ?: date('Y');

            $query = "SELECT
                     MONTH(investment_date) as month,
                     MONTHNAME(investment_date) as month_name,
                     investment_type,
                     COUNT(*) as transaction_count,
                     SUM(amount) as total_amount
                     FROM investments
                     WHERE YEAR(investment_date) = :year AND status = 'confirmed'
                     GROUP BY MONTH(investment_date), investment_type
                     ORDER BY MONTH(investment_date), investment_type";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':year', $year);
            $stmt->execute();

            return $stmt->fetchAll();

        } catch (Exception $e) {
            error_log("Get monthly investment summary error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Generate transaction ID
     */
    private function generateTransactionId() {
        $prefix = 'TXN';
        $date = date('Ymd');

        // Get last transaction ID for today
        $query = "SELECT transaction_id FROM investments
                 WHERE transaction_id LIKE :pattern
                 ORDER BY transaction_id DESC LIMIT 1";

        $pattern = $prefix . $date . '%';
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':pattern', $pattern);
        $stmt->execute();
        $result = $stmt->fetch();

        if ($result) {
            $last_number = intval(substr($result['transaction_id'], -3));
            $next_number = $last_number + 1;
        } else {
            $next_number = 1;
        }

        return $prefix . $date . str_pad($next_number, 3, '0', STR_PAD_LEFT);
    }

    /**
     * Generate receipt number
     */
    private function generateReceiptNumber() {
        $prefix = 'RCP';
        $date = date('Ymd');

        // Get last receipt number for today
        $query = "SELECT receipt_number FROM investments
                 WHERE receipt_number LIKE :pattern
                 ORDER BY receipt_number DESC LIMIT 1";

        $pattern = $prefix . $date . '%';
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':pattern', $pattern);
        $stmt->execute();
        $result = $stmt->fetch();

        if ($result) {
            $last_number = intval(substr($result['receipt_number'], -3));
            $next_number = $last_number + 1;
        } else {
            $next_number = 1;
        }

        return $prefix . $date . str_pad($next_number, 3, '0', STR_PAD_LEFT);
    }
}
?>
