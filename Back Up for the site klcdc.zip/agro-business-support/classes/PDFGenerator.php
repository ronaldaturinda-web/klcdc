<?php
/**
 * PDF Generator Class
 * National Agro Business Support Initiative
 * Uses TCPDF library for PDF generation
 */

require_once '../vendor/tcpdf/tcpdf.php';
require_once '../config/config.php';

class PDFGenerator {
    private $pdf;

    public function __construct() {
        // Create new PDF document
        $this->pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

        // Set document information
        $this->pdf->SetCreator(PDF_CREATOR);
        $this->pdf->SetAuthor(COMPANY_NAME);
        $this->pdf->SetTitle('Investment Document');
        $this->pdf->SetSubject('National Agro Business Support Initiative');

        // Set default header and footer
        $this->pdf->setPrintHeader(false);
        $this->pdf->setPrintFooter(false);

        // Set margins
        $this->pdf->SetMargins(15, 15, 15);
        $this->pdf->SetAutoPageBreak(TRUE, 20);

        // Set font
        $this->pdf->SetFont('helvetica', '', 10);
    }

    /**
     * Generate investment receipt
     */
    public function generateReceipt($investment_data) {
        try {
            $this->pdf->AddPage();

            // Header
            $this->addHeader('INVESTMENT RECEIPT');

            // Company info
            $this->pdf->Ln(5);
            $this->pdf->SetFont('helvetica', 'B', 12);
            $this->pdf->Cell(0, 8, COMPANY_NAME, 0, 1, 'C');
            $this->pdf->SetFont('helvetica', '', 10);
            $this->pdf->Cell(0, 6, COMPANY_ADDRESS, 0, 1, 'C');
            $this->pdf->Cell(0, 6, 'Phone: ' . COMPANY_PHONE . ' | Email: ' . COMPANY_EMAIL, 0, 1, 'C');

            // Line separator
            $this->pdf->Ln(5);
            $this->pdf->Line(15, $this->pdf->GetY(), 195, $this->pdf->GetY());
            $this->pdf->Ln(5);

            // Receipt details
            $this->pdf->SetFont('helvetica', 'B', 12);
            $this->pdf->Cell(0, 8, 'INVESTMENT RECEIPT', 0, 1, 'C');
            $this->pdf->Ln(5);

            // Receipt info table
            $this->pdf->SetFont('helvetica', '', 10);

            // Left column
            $this->pdf->Cell(95, 6, 'Receipt Number: ' . $investment_data['receipt_number'], 0, 0, 'L');
            $this->pdf->Cell(95, 6, 'Transaction ID: ' . $investment_data['transaction_id'], 0, 1, 'L');

            $this->pdf->Cell(95, 6, 'Date: ' . formatDate($investment_data['investment_date'], 'd/m/Y H:i'), 0, 0, 'L');
            $this->pdf->Cell(95, 6, 'Status: ' . ucfirst($investment_data['status']), 0, 1, 'L');

            $this->pdf->Ln(5);

            // Investor information
            $this->pdf->SetFont('helvetica', 'B', 11);
            $this->pdf->Cell(0, 8, 'INVESTOR INFORMATION', 0, 1, 'L');
            $this->pdf->SetFont('helvetica', '', 10);

            $this->pdf->Cell(95, 6, 'Name: ' . $investment_data['investor_name'], 0, 0, 'L');
            $this->pdf->Cell(95, 6, 'Account Number: ' . $investment_data['account_number'], 0, 1, 'L');

            if (!empty($investment_data['phone'])) {
                $this->pdf->Cell(95, 6, 'Phone: ' . $investment_data['phone'], 0, 1, 'L');
            }

            if (!empty($investment_data['address'])) {
                $this->pdf->Cell(0, 6, 'Address: ' . $investment_data['address'], 0, 1, 'L');
            }

            $this->pdf->Ln(5);

            // Investment details
            $this->pdf->SetFont('helvetica', 'B', 11);
            $this->pdf->Cell(0, 8, 'INVESTMENT DETAILS', 0, 1, 'L');
            $this->pdf->SetFont('helvetica', '', 10);

            $this->pdf->Cell(95, 6, 'Investment Type: ' . ucfirst($investment_data['investment_type']), 0, 0, 'L');
            $this->pdf->Cell(95, 6, 'Payment Method: ' . ($investment_data['payment_method'] ?? 'N/A'), 0, 1, 'L');

            if (!empty($investment_data['description'])) {
                $this->pdf->Cell(0, 6, 'Description: ' . $investment_data['description'], 0, 1, 'L');
            }

            if (!empty($investment_data['notes'])) {
                $this->pdf->Cell(0, 6, 'Notes: ' . $investment_data['notes'], 0, 1, 'L');
            }

            $this->pdf->Ln(5);

            // Amount box
            $this->pdf->SetFillColor(240, 240, 240);
            $this->pdf->Rect(15, $this->pdf->GetY(), 180, 15, 'F');
            $this->pdf->SetFont('helvetica', 'B', 14);
            $this->pdf->Cell(0, 15, 'AMOUNT: ' . formatCurrency($investment_data['amount']), 0, 1, 'C');

            $this->pdf->Ln(10);

            // Footer
            $this->pdf->SetFont('helvetica', '', 9);
            $this->pdf->Cell(0, 6, 'This is a computer-generated receipt and does not require a signature.', 0, 1, 'C');
            $this->pdf->Cell(0, 6, 'For inquiries, please contact us at ' . COMPANY_EMAIL, 0, 1, 'C');

            $this->pdf->Ln(10);
            $this->pdf->Cell(0, 6, 'Generated on: ' . date('d/m/Y H:i:s'), 0, 1, 'R');

            return $this->outputPDF('receipt_' . $investment_data['receipt_number'] . '.pdf');

        } catch (Exception $e) {
            error_log("Generate receipt error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Generate investment statement
     */
    public function generateStatement($investor_data, $investments, $period = '') {
        try {
            $this->pdf->AddPage();

            // Header
            $this->addHeader('INVESTMENT STATEMENT');

            // Company info
            $this->pdf->Ln(5);
            $this->pdf->SetFont('helvetica', 'B', 12);
            $this->pdf->Cell(0, 8, COMPANY_NAME, 0, 1, 'C');
            $this->pdf->SetFont('helvetica', '', 10);
            $this->pdf->Cell(0, 6, COMPANY_ADDRESS, 0, 1, 'C');

            // Line separator
            $this->pdf->Ln(5);
            $this->pdf->Line(15, $this->pdf->GetY(), 195, $this->pdf->GetY());
            $this->pdf->Ln(5);

            // Statement title
            $this->pdf->SetFont('helvetica', 'B', 12);
            $this->pdf->Cell(0, 8, 'INVESTMENT STATEMENT', 0, 1, 'C');
            if (!empty($period)) {
                $this->pdf->Cell(0, 6, $period, 0, 1, 'C');
            }
            $this->pdf->Ln(5);

            // Investor information
            $this->pdf->SetFont('helvetica', 'B', 11);
            $this->pdf->Cell(0, 8, 'INVESTOR INFORMATION', 0, 1, 'L');
            $this->pdf->SetFont('helvetica', '', 10);

            $this->pdf->Cell(95, 6, 'Name: ' . $investor_data['first_name'] . ' ' . $investor_data['last_name'], 0, 0, 'L');
            $this->pdf->Cell(95, 6, 'Account Number: ' . $investor_data['account_number'], 0, 1, 'L');
            $this->pdf->Cell(95, 6, 'Phone: ' . $investor_data['phone'], 0, 0, 'L');
            $this->pdf->Cell(95, 6, 'Date Joined: ' . formatDate($investor_data['date_joined'], 'd/m/Y'), 0, 1, 'L');

            $this->pdf->Ln(5);

            // Investment summary
            $total_amount = 0;
            $cash_total = 0;
            $material_total = 0;
            $labor_total = 0;

            foreach ($investments as $investment) {
                $total_amount += $investment['amount'];
                switch ($investment['investment_type']) {
                    case 'cash':
                        $cash_total += $investment['amount'];
                        break;
                    case 'material':
                        $material_total += $investment['amount'];
                        break;
                    case 'labor':
                        $labor_total += $investment['amount'];
                        break;
                }
            }

            $this->pdf->SetFont('helvetica', 'B', 11);
            $this->pdf->Cell(0, 8, 'INVESTMENT SUMMARY', 0, 1, 'L');
            $this->pdf->SetFont('helvetica', '', 10);

            $this->pdf->Cell(95, 6, 'Total Investments: ' . count($investments), 0, 0, 'L');
            $this->pdf->Cell(95, 6, 'Total Amount: ' . formatCurrency($total_amount), 0, 1, 'L');
            $this->pdf->Cell(95, 6, 'Cash Investments: ' . formatCurrency($cash_total), 0, 0, 'L');
            $this->pdf->Cell(95, 6, 'Material Investments: ' . formatCurrency($material_total), 0, 1, 'L');
            $this->pdf->Cell(95, 6, 'Labor Investments: ' . formatCurrency($labor_total), 0, 1, 'L');

            $this->pdf->Ln(5);

            // Investment details table
            if (!empty($investments)) {
                $this->pdf->SetFont('helvetica', 'B', 9);
                $this->pdf->Cell(25, 8, 'Date', 1, 0, 'C');
                $this->pdf->Cell(30, 8, 'Receipt No.', 1, 0, 'C');
                $this->pdf->Cell(25, 8, 'Type', 1, 0, 'C');
                $this->pdf->Cell(30, 8, 'Amount', 1, 0, 'C');
                $this->pdf->Cell(70, 8, 'Description', 1, 1, 'C');

                $this->pdf->SetFont('helvetica', '', 8);
                foreach ($investments as $investment) {
                    $this->pdf->Cell(25, 6, formatDate($investment['investment_date'], 'd/m/Y'), 1, 0, 'C');
                    $this->pdf->Cell(30, 6, $investment['receipt_number'], 1, 0, 'C');
                    $this->pdf->Cell(25, 6, ucfirst($investment['investment_type']), 1, 0, 'C');
                    $this->pdf->Cell(30, 6, formatCurrency($investment['amount']), 1, 0, 'R');
                    $this->pdf->Cell(70, 6, substr($investment['description'] ?? '', 0, 30), 1, 1, 'L');
                }

                // Total row
                $this->pdf->SetFont('helvetica', 'B', 9);
                $this->pdf->Cell(80, 8, 'TOTAL', 1, 0, 'C');
                $this->pdf->Cell(30, 8, formatCurrency($total_amount), 1, 0, 'R');
                $this->pdf->Cell(70, 8, '', 1, 1, 'C');
            }

            $this->pdf->Ln(10);

            // Footer
            $this->pdf->SetFont('helvetica', '', 9);
            $this->pdf->Cell(0, 6, 'This statement is generated electronically and is valid without signature.', 0, 1, 'C');
            $this->pdf->Cell(0, 6, 'Generated on: ' . date('d/m/Y H:i:s'), 0, 1, 'R');

            return $this->outputPDF('statement_' . $investor_data['account_number'] . '_' . date('Y-m-d') . '.pdf');

        } catch (Exception $e) {
            error_log("Generate statement error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Generate summary report
     */
    public function generateSummaryReport($statistics, $monthly_data, $period = '') {
        try {
            $this->pdf->AddPage();

            // Header
            $this->addHeader('INVESTMENT SUMMARY REPORT');

            // Company info
            $this->pdf->Ln(5);
            $this->pdf->SetFont('helvetica', 'B', 12);
            $this->pdf->Cell(0, 8, COMPANY_NAME, 0, 1, 'C');
            $this->pdf->SetFont('helvetica', '', 10);
            $this->pdf->Cell(0, 6, COMPANY_ADDRESS, 0, 1, 'C');

            // Line separator
            $this->pdf->Ln(5);
            $this->pdf->Line(15, $this->pdf->GetY(), 195, $this->pdf->GetY());
            $this->pdf->Ln(5);

            // Report title
            $this->pdf->SetFont('helvetica', 'B', 12);
            $this->pdf->Cell(0, 8, 'INVESTMENT SUMMARY REPORT', 0, 1, 'C');
            if (!empty($period)) {
                $this->pdf->Cell(0, 6, $period, 0, 1, 'C');
            }
            $this->pdf->Ln(5);

            // Overall statistics
            $this->pdf->SetFont('helvetica', 'B', 11);
            $this->pdf->Cell(0, 8, 'OVERALL STATISTICS', 0, 1, 'L');
            $this->pdf->SetFont('helvetica', '', 10);

            $this->pdf->Cell(95, 6, 'Total Transactions: ' . number_format($statistics['total_transactions']), 0, 0, 'L');
            $this->pdf->Cell(95, 6, 'Total Amount: ' . formatCurrency($statistics['total_amount']), 0, 1, 'L');
            $this->pdf->Cell(95, 6, 'Average Investment: ' . formatCurrency($statistics['average_investment']), 0, 1, 'L');

            $this->pdf->Ln(5);

            // Investment type breakdown
            $this->pdf->SetFont('helvetica', 'B', 11);
            $this->pdf->Cell(0, 8, 'INVESTMENT TYPE BREAKDOWN', 0, 1, 'L');
            $this->pdf->SetFont('helvetica', '', 10);

            $this->pdf->Cell(95, 6, 'Cash Investments: ' . formatCurrency($statistics['cash_total']) . ' (' . $statistics['cash_count'] . ' transactions)', 0, 1, 'L');
            $this->pdf->Cell(95, 6, 'Material Investments: ' . formatCurrency($statistics['material_total']) . ' (' . $statistics['material_count'] . ' transactions)', 0, 1, 'L');
            $this->pdf->Cell(95, 6, 'Labor Investments: ' . formatCurrency($statistics['labor_total']) . ' (' . $statistics['labor_count'] . ' transactions)', 0, 1, 'L');

            $this->pdf->Ln(5);

            // Monthly breakdown
            if (!empty($monthly_data)) {
                $this->pdf->SetFont('helvetica', 'B', 11);
                $this->pdf->Cell(0, 8, 'MONTHLY BREAKDOWN', 0, 1, 'L');

                $this->pdf->SetFont('helvetica', 'B', 9);
                $this->pdf->Cell(30, 8, 'Month', 1, 0, 'C');
                $this->pdf->Cell(25, 8, 'Type', 1, 0, 'C');
                $this->pdf->Cell(25, 8, 'Count', 1, 0, 'C');
                $this->pdf->Cell(30, 8, 'Amount', 1, 1, 'C');

                $this->pdf->SetFont('helvetica', '', 8);
                foreach ($monthly_data as $data) {
                    $this->pdf->Cell(30, 6, $data['month_name'], 1, 0, 'L');
                    $this->pdf->Cell(25, 6, ucfirst($data['investment_type']), 1, 0, 'C');
                    $this->pdf->Cell(25, 6, $data['transaction_count'], 1, 0, 'C');
                    $this->pdf->Cell(30, 6, formatCurrency($data['total_amount']), 1, 1, 'R');
                }
            }

            $this->pdf->Ln(10);

            // Footer
            $this->pdf->SetFont('helvetica', '', 9);
            $this->pdf->Cell(0, 6, 'This report is generated electronically for internal use.', 0, 1, 'C');
            $this->pdf->Cell(0, 6, 'Generated on: ' . date('d/m/Y H:i:s'), 0, 1, 'R');

            return $this->outputPDF('summary_report_' . date('Y-m-d') . '.pdf');

        } catch (Exception $e) {
            error_log("Generate summary report error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Add header to PDF
     */
    private function addHeader($title) {
        $this->pdf->SetY(15);
        $this->pdf->SetFont('helvetica', 'B', 16);
        $this->pdf->Cell(0, 10, $title, 0, 1, 'C');
        $this->pdf->Ln(5);
    }

    /**
     * Output PDF
     */
    private function outputPDF($filename) {
        try {
            // Create temp directory if not exists
            if (!file_exists(PDF_TEMP_PATH)) {
                mkdir(PDF_TEMP_PATH, 0755, true);
            }

            $filepath = PDF_TEMP_PATH . $filename;
            $this->pdf->Output($filepath, 'F');

            return $filepath;

        } catch (Exception $e) {
            error_log("Output PDF error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Download PDF
     */
    public function downloadPDF($filepath, $filename) {
        if (file_exists($filepath)) {
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Content-Length: ' . filesize($filepath));
            readfile($filepath);

            // Clean up temp file
            unlink($filepath);
            exit;
        } else {
            return false;
        }
    }
}
?>
