<?php
/**
 * Investor Management Class
 * National Agro Business Support Initiative
 */

require_once '../config/config.php';

class Investor {
    private $conn;

    public function __construct() {
        $this->conn = getDbConnection();
    }

    /**
     * Create new investor
     */
    public function createInvestor($data) {
        try {
            $this->conn->beginTransaction();

            // Check if account number already exists
            $query = "SELECT id FROM investors WHERE account_number = :account_number";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':account_number', $data['account_number']);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                $this->conn->rollBack();
                return [
                    'success' => false,
                    'message' => 'Account number already exists'
                ];
            }

            // Create investor
            $query = "INSERT INTO investors (user_id, account_number, first_name, last_name, phone,
                     address, city, state, country, postal_code, date_joined, status)
                     VALUES (:user_id, :account_number, :first_name, :last_name, :phone,
                     :address, :city, :state, :country, :postal_code, :date_joined, :status)";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $data['user_id']);
            $stmt->bindParam(':account_number', $data['account_number']);
            $stmt->bindParam(':first_name', $data['first_name']);
            $stmt->bindParam(':last_name', $data['last_name']);
            $stmt->bindParam(':phone', $data['phone']);
            $stmt->bindParam(':address', $data['address']);
            $stmt->bindParam(':city', $data['city']);
            $stmt->bindParam(':state', $data['state']);
            $stmt->bindParam(':country', $data['country']);
            $stmt->bindParam(':postal_code', $data['postal_code']);
            $stmt->bindParam(':date_joined', $data['date_joined']);
            $stmt->bindParam(':status', $data['status']);
            $stmt->execute();

            $investor_id = $this->conn->lastInsertId();

            $this->conn->commit();

            logActivity("Investor created: " . $data['account_number'], $_SESSION['user_id'] ?? null);

            return [
                'success' => true,
                'message' => 'Investor created successfully',
                'investor_id' => $investor_id
            ];

        } catch (Exception $e) {
            $this->conn->rollBack();
            error_log("Create investor error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Failed to create investor'
            ];
        }
    }

    /**
     * Update investor
     */
    public function updateInvestor($investor_id, $data) {
        try {
            // Check if account number already exists for other investors
            $query = "SELECT id FROM investors WHERE account_number = :account_number AND id != :investor_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':account_number', $data['account_number']);
            $stmt->bindParam(':investor_id', $investor_id);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                return [
                    'success' => false,
                    'message' => 'Account number already exists'
                ];
            }

            // Update investor
            $query = "UPDATE investors SET account_number = :account_number, first_name = :first_name,
                     last_name = :last_name, phone = :phone, address = :address, city = :city,
                     state = :state, country = :country, postal_code = :postal_code,
                     date_joined = :date_joined, status = :status, updated_at = CURRENT_TIMESTAMP
                     WHERE id = :investor_id";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':account_number', $data['account_number']);
            $stmt->bindParam(':first_name', $data['first_name']);
            $stmt->bindParam(':last_name', $data['last_name']);
            $stmt->bindParam(':phone', $data['phone']);
            $stmt->bindParam(':address', $data['address']);
            $stmt->bindParam(':city', $data['city']);
            $stmt->bindParam(':state', $data['state']);
            $stmt->bindParam(':country', $data['country']);
            $stmt->bindParam(':postal_code', $data['postal_code']);
            $stmt->bindParam(':date_joined', $data['date_joined']);
            $stmt->bindParam(':status', $data['status']);
            $stmt->bindParam(':investor_id', $investor_id);
            $stmt->execute();

            logActivity("Investor updated: " . $data['account_number'], $_SESSION['user_id'] ?? null);

            return [
                'success' => true,
                'message' => 'Investor updated successfully'
            ];

        } catch (Exception $e) {
            error_log("Update investor error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Failed to update investor'
            ];
        }
    }

    /**
     * Delete investor
     */
    public function deleteInvestor($investor_id) {
        try {
            $this->conn->beginTransaction();

            // Check if investor has investments
            $query = "SELECT COUNT(*) as count FROM investments WHERE investor_id = :investor_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':investor_id', $investor_id);
            $stmt->execute();
            $result = $stmt->fetch();

            if ($result['count'] > 0) {
                $this->conn->rollBack();
                return [
                    'success' => false,
                    'message' => 'Cannot delete investor with existing investments'
                ];
            }

            // Get user_id before deleting investor
            $query = "SELECT user_id, account_number FROM investors WHERE id = :investor_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':investor_id', $investor_id);
            $stmt->execute();
            $investor = $stmt->fetch();

            if (!$investor) {
                $this->conn->rollBack();
                return [
                    'success' => false,
                    'message' => 'Investor not found'
                ];
            }

            // Delete investor
            $query = "DELETE FROM investors WHERE id = :investor_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':investor_id', $investor_id);
            $stmt->execute();

            // Delete associated user
            $query = "DELETE FROM users WHERE id = :user_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $investor['user_id']);
            $stmt->execute();

            $this->conn->commit();

            logActivity("Investor deleted: " . $investor['account_number'], $_SESSION['user_id'] ?? null);

            return [
                'success' => true,
                'message' => 'Investor deleted successfully'
            ];

        } catch (Exception $e) {
            $this->conn->rollBack();
            error_log("Delete investor error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Failed to delete investor'
            ];
        }
    }

    /**
     * Get all investors
     */
    public function getAllInvestors($limit = 50, $offset = 0, $search = '') {
        try {
            $where_clause = "";
            $params = [];

            if (!empty($search)) {
                $where_clause = "WHERE i.account_number LIKE :search OR i.first_name LIKE :search
                               OR i.last_name LIKE :search OR i.phone LIKE :search";
                $params[':search'] = "%$search%";
            }

            $query = "SELECT i.*, u.username, u.email, u.status as user_status,
                     (SELECT COUNT(*) FROM investments WHERE investor_id = i.id AND status = 'confirmed') as total_investments,
                     (SELECT COALESCE(SUM(amount), 0) FROM investments WHERE investor_id = i.id AND status = 'confirmed') as total_amount
                     FROM investors i
                     JOIN users u ON i.user_id = u.id
                     $where_clause
                     ORDER BY i.created_at DESC
                     LIMIT :limit OFFSET :offset";

            $stmt = $this->conn->prepare($query);

            foreach ($params as $key => $value) {
                $stmt->bindParam($key, $value);
            }

            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();

            return $stmt->fetchAll();

        } catch (Exception $e) {
            error_log("Get all investors error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get investor by ID
     */
    public function getInvestorById($investor_id) {
        try {
            $query = "SELECT i.*, u.username, u.email, u.role, u.status as user_status
                     FROM investors i
                     JOIN users u ON i.user_id = u.id
                     WHERE i.id = :investor_id";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':investor_id', $investor_id);
            $stmt->execute();

            return $stmt->fetch();

        } catch (Exception $e) {
            error_log("Get investor by ID error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get investor by user ID
     */
    public function getInvestorByUserId($user_id) {
        try {
            $query = "SELECT i.*, u.username, u.email, u.role, u.status as user_status
                     FROM investors i
                     JOIN users u ON i.user_id = u.id
                     WHERE i.user_id = :user_id";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();

            return $stmt->fetch();

        } catch (Exception $e) {
            error_log("Get investor by user ID error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get investor by account number
     */
    public function getInvestorByAccountNumber($account_number) {
        try {
            $query = "SELECT i.*, u.username, u.email, u.role, u.status as user_status
                     FROM investors i
                     JOIN users u ON i.user_id = u.id
                     WHERE i.account_number = :account_number";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':account_number', $account_number);
            $stmt->execute();

            return $stmt->fetch();

        } catch (Exception $e) {
            error_log("Get investor by account number error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get total investors count
     */
    public function getTotalInvestorsCount($search = '') {
        try {
            $where_clause = "";
            $params = [];

            if (!empty($search)) {
                $where_clause = "WHERE i.account_number LIKE :search OR i.first_name LIKE :search
                               OR i.last_name LIKE :search OR i.phone LIKE :search";
                $params[':search'] = "%$search%";
            }

            $query = "SELECT COUNT(*) as total FROM investors i JOIN users u ON i.user_id = u.id $where_clause";
            $stmt = $this->conn->prepare($query);

            foreach ($params as $key => $value) {
                $stmt->bindParam($key, $value);
            }

            $stmt->execute();
            $result = $stmt->fetch();

            return $result['total'];

        } catch (Exception $e) {
            error_log("Get total investors count error: " . $e->getMessage());
            return 0;
        }
    }

    /**
     * Update investor status
     */
    public function updateInvestorStatus($investor_id, $status) {
        try {
            $query = "UPDATE investors SET status = :status, updated_at = CURRENT_TIMESTAMP WHERE id = :investor_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':status', $status);
            $stmt->bindParam(':investor_id', $investor_id);
            $stmt->execute();

            logActivity("Investor status updated to $status (ID: $investor_id)", $_SESSION['user_id'] ?? null);

            return [
                'success' => true,
                'message' => 'Investor status updated successfully'
            ];

        } catch (Exception $e) {
            error_log("Update investor status error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Failed to update investor status'
            ];
        }
    }

    /**
     * Upload profile picture
     */
    public function uploadProfilePicture($investor_id, $file) {
        try {
            // Validate file
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
            if (!in_array($file['type'], $allowed_types)) {
                return [
                    'success' => false,
                    'message' => 'Invalid file type. Only JPG, PNG and GIF allowed.'
                ];
            }

            if ($file['size'] > MAX_FILE_SIZE) {
                return [
                    'success' => false,
                    'message' => 'File size too large. Maximum 5MB allowed.'
                ];
            }

            // Create upload directory if not exists
            $upload_dir = UPLOAD_PATH . 'profiles/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }

            // Generate unique filename
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = 'profile_' . $investor_id . '_' . time() . '.' . $extension;
            $file_path = $upload_dir . $filename;

            // Move uploaded file
            if (move_uploaded_file($file['tmp_name'], $file_path)) {
                // Update database
                $query = "UPDATE investors SET profile_picture = :profile_picture, updated_at = CURRENT_TIMESTAMP WHERE id = :investor_id";
                $stmt = $this->conn->prepare($query);
                $stmt->bindParam(':profile_picture', $filename);
                $stmt->bindParam(':investor_id', $investor_id);
                $stmt->execute();

                logActivity("Profile picture uploaded for investor ID: $investor_id", $_SESSION['user_id'] ?? null);

                return [
                    'success' => true,
                    'message' => 'Profile picture uploaded successfully',
                    'filename' => $filename
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to upload file'
                ];
            }

        } catch (Exception $e) {
            error_log("Upload profile picture error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Failed to upload profile picture'
            ];
        }
    }

    /**
     * Generate next account number
     */
    public function generateAccountNumber() {
        try {
            $query = "SELECT account_number FROM investors ORDER BY account_number DESC LIMIT 1";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            $result = $stmt->fetch();

            if ($result) {
                $last_number = intval(substr($result['account_number'], 3));
                $next_number = $last_number + 1;
            } else {
                $next_number = 1;
            }

            return 'AGR' . str_pad($next_number, 3, '0', STR_PAD_LEFT);

        } catch (Exception $e) {
            error_log("Generate account number error: " . $e->getMessage());
            return 'AGR001';
        }
    }
}
?>
