-- National Agro Business Support Initiative Database Schema
-- Created for production-ready application

-- Create database
CREATE DATABASE IF NOT EXISTS `agro_business_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `agro_business_db`;

-- Users table for authentication
CREATE TABLE `users` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `username` varchar(50) NOT NULL UNIQUE,
    `email` varchar(100) NOT NULL UNIQUE,
    `password` varchar(255) NOT NULL,
    `role` enum('admin','investor') NOT NULL DEFAULT 'investor',
    `status` enum('active','inactive') NOT NULL DEFAULT 'active',
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_username` (`username`),
    INDEX `idx_email` (`email`),
    INDEX `idx_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Investors table for detailed investor information
CREATE TABLE `investors` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `user_id` int(11) NOT NULL,
    `account_number` varchar(20) NOT NULL UNIQUE,
    `first_name` varchar(50) NOT NULL,
    `last_name` varchar(50) NOT NULL,
    `phone` varchar(20) NOT NULL,
    `address` text NOT NULL,
    `city` varchar(50) NOT NULL,
    `state` varchar(50) NOT NULL,
    `country` varchar(50) NOT NULL DEFAULT 'Nigeria',
    `postal_code` varchar(10),
    `profile_picture` varchar(255),
    `date_joined` date NOT NULL,
    `status` enum('active','inactive','suspended') NOT NULL DEFAULT 'active',
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `unique_account_number` (`account_number`),
    KEY `fk_investor_user` (`user_id`),
    INDEX `idx_account_number` (`account_number`),
    INDEX `idx_name` (`first_name`, `last_name`),
    CONSTRAINT `fk_investor_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Investments table for tracking all investment transactions
CREATE TABLE `investments` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `investor_id` int(11) NOT NULL,
    `transaction_id` varchar(50) NOT NULL UNIQUE,
    `investment_type` enum('cash','material','labor') NOT NULL,
    `amount` decimal(15,2) NOT NULL,
    `description` text,
    `investment_date` datetime NOT NULL,
    `receipt_number` varchar(50) NOT NULL UNIQUE,
    `payment_method` varchar(50),
    `notes` text,
    `status` enum('pending','confirmed','cancelled') NOT NULL DEFAULT 'confirmed',
    `recorded_by` int(11) NOT NULL, -- Admin user who recorded the investment
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `unique_transaction_id` (`transaction_id`),
    UNIQUE KEY `unique_receipt_number` (`receipt_number`),
    KEY `fk_investment_investor` (`investor_id`),
    KEY `fk_investment_recorded_by` (`recorded_by`),
    INDEX `idx_investment_date` (`investment_date`),
    INDEX `idx_investment_type` (`investment_type`),
    INDEX `idx_amount` (`amount`),
    INDEX `idx_status` (`status`),
    CONSTRAINT `fk_investment_investor` FOREIGN KEY (`investor_id`) REFERENCES `investors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_investment_recorded_by` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sessions table for secure session management
CREATE TABLE `user_sessions` (
    `id` varchar(128) NOT NULL,
    `user_id` int(11) NOT NULL,
    `ip_address` varchar(45) NOT NULL,
    `user_agent` text,
    `last_activity` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `fk_session_user` (`user_id`),
    INDEX `idx_last_activity` (`last_activity`),
    CONSTRAINT `fk_session_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default admin user (password: admin123)
INSERT INTO `users` (`username`, `email`, `password`, `role`) VALUES
('admin', 'admin@agrobusiness.ng', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Sample investors data
INSERT INTO `users` (`username`, `email`, `password`, `role`) VALUES
('investor1', 'john.doe@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'investor'),
('investor2', 'jane.smith@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'investor');

INSERT INTO `investors` (`user_id`, `account_number`, `first_name`, `last_name`, `phone`, `address`, `city`, `state`, `date_joined`) VALUES
(2, 'AGR001', 'John', 'Doe', '+234-801-234-5678', '123 Farm Avenue', 'Lagos', 'Lagos', '2024-01-15'),
(3, 'AGR002', 'Jane', 'Smith', '+234-802-345-6789', '456 Agricultural Road', 'Abuja', 'FCT', '2024-01-20');

-- Sample investments
INSERT INTO `investments` (`investor_id`, `transaction_id`, `investment_type`, `amount`, `description`, `investment_date`, `receipt_number`, `recorded_by`) VALUES
(1, 'TXN001', 'cash', 500000.00, 'Initial cash investment', '2024-01-15 10:30:00', 'RCP001', 1),
(1, 'TXN002', 'material', 250000.00, 'Farm equipment contribution', '2024-02-01 14:15:00', 'RCP002', 1),
(2, 'TXN003', 'cash', 750000.00, 'Cash investment for expansion', '2024-01-20 09:45:00', 'RCP003', 1);

-- Create views for reporting
CREATE VIEW `investment_summary` AS
SELECT
    i.id,
    CONCAT(i.first_name, ' ', i.last_name) as investor_name,
    i.account_number,
    COUNT(inv.id) as total_investments,
    SUM(inv.amount) as total_amount,
    SUM(CASE WHEN inv.investment_type = 'cash' THEN inv.amount ELSE 0 END) as cash_investments,
    SUM(CASE WHEN inv.investment_type = 'material' THEN inv.amount ELSE 0 END) as material_investments,
    SUM(CASE WHEN inv.investment_type = 'labor' THEN inv.amount ELSE 0 END) as labor_investments,
    MIN(inv.investment_date) as first_investment,
    MAX(inv.investment_date) as last_investment
FROM investors i
LEFT JOIN investments inv ON i.id = inv.investor_id AND inv.status = 'confirmed'
GROUP BY i.id;

CREATE VIEW `monthly_investment_summary` AS
SELECT
    YEAR(investment_date) as year,
    MONTH(investment_date) as month,
    MONTHNAME(investment_date) as month_name,
    investment_type,
    COUNT(*) as transaction_count,
    SUM(amount) as total_amount
FROM investments
WHERE status = 'confirmed'
GROUP BY YEAR(investment_date), MONTH(investment_date), investment_type
ORDER BY year DESC, month DESC;
