<?php
// admin/print_receipt.php
declare(strict_types=1);

require_once '../config/config.php';
require_once '../classes/Auth.php';

// Gate
if (!isLoggedIn() /* || !isAdmin() */) {
    redirect('../index.php');
}
$auth = new Auth();
if (!$auth->validateSession()) {
    redirect('../index.php');
}

/** Resolve PDO even if your app exposes it differently */
function resolvePDO(): PDO {
    if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) return $GLOBALS['pdo'];
    if (function_exists('getDbConnection')) { $p = getDbConnection(); if ($p instanceof PDO) return $p; }
    if (class_exists('Database')) {
        $db = new Database();
        if (method_exists($db,'connect'))       { $p = $db->connect();       if ($p instanceof PDO) return $p; }
        if (method_exists($db,'getConnection')) { $p = $db->getConnection(); if ($p instanceof PDO) return $p; }
    }
    throw new RuntimeException('DB connection not available.');
}

try {
    $pdo = resolvePDO();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    http_response_code(500);
    exit('Database connection not available.');
}

/** TCPDF loader */
function includeTCPDF(): bool {
    $candidates = [
        __DIR__ . '/../vendor/tcpdf/tcpdf.php',
        __DIR__ . '/../tcpdf_min/tcpdf.php',
        __DIR__ . '/../tcpdf.php',
    ];
    foreach ($candidates as $p) {
        if (is_readable($p)) {
            if (!defined('K_PATH_CACHE')) {
                $cache = realpath(__DIR__ . '/../temp');
                if (!$cache) { @mkdir(__DIR__ . '/../temp', 0775, true); $cache = __DIR__ . '/../temp'; }
                define('K_PATH_CACHE', rtrim($cache, '/\\') . DIRECTORY_SEPARATOR);
            }
            require_once $p;
            return true;
        }
    }
    return false;
}

/** Small helpers */
function hasCol(PDO $pdo, string $table, string $col): bool {
    $st = $pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?");
    $st->execute([$col]);
    return (bool)$st->fetch();
}
function fmt_money($n) {
    if (function_exists('formatCurrency')) return formatCurrency((float)$n);
    return 'UGX ' . number_format((float)$n, 0, '.', ',');
}

/** Load settings map (fallbacks baked in) */
function getSettings(PDO $pdo): array {
    $defaults = [
        'org.name'              => 'Kaliro Lords Community Development Corporation',
        'org.email'             => 'info@example.com',
        'org.phone'             => '+256 700 000 000',
        'org.address'           => 'Kampala, Uganda',
        'brand.logo'            => '',            // relative path e.g. uploads/branding/logo.png
        'brand.color_primary'   => '#2c5530',     // header bar color
        'brand.color_secondary' => '#4a7c59',
    ];
    $map = $defaults;
    try {
        $rows = $pdo->query("SELECT `key`,`value` FROM settings")->fetchAll();
        foreach ($rows as $r) { $map[$r['key']] = $r['value']; }
    } catch (Throwable $e) {
        // ignore; fallbacks apply
    }
    return $map;
}

/** Robust absolute path resolution for the logo
 *  - Uses setting if present (relative or absolute)
 *  - Otherwise tries common locations in project root
 */
function resolveLogoPath(?string $rel): ?string {
    $candidates = [];

    // 1) If settings provided a path
    if ($rel) {
        // absolute path
        if (@is_file($rel)) $candidates[] = $rel;
        // relative to project root (admin/..)
        $candidates[] = dirname(__DIR__) . DIRECTORY_SEPARATOR . ltrim($rel, '/\\');
        // relative to this folder
        $candidates[] = __DIR__ . DIRECTORY_SEPARATOR . ltrim($rel, '/\\');
    }

    // 2) Common fallbacks in project root
    $root = dirname(__DIR__); // e.g. /path/to/project
    foreach (['logo.png','logo.jpg','logo.jpeg','public/logo.png','uploads/branding/logo.png'] as $fn) {
        $candidates[] = $root . DIRECTORY_SEPARATOR . $fn;
    }

    foreach ($candidates as $p) {
        $norm = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $p);
        if (@is_readable($norm) && is_file($norm)) return $norm;
    }
    return null;
}

/** Input */
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    http_response_code(400);
    exit('Invalid receipt reference.');
}

/** Detect column names in investments */
$table = 'investments';
$typeCol = null; foreach (['investment_type','type','category'] as $c) { if (hasCol($pdo, $table, $c)) { $typeCol = $c; break; } }
$dateCol = null; foreach (['investment_date','created_at','date','created_on','timestamp'] as $c) { if (hasCol($pdo, $table, $c)) { $dateCol = $c; break; } }
$hasTxn  = hasCol($pdo, $table, 'transaction_id');
$hasRcp  = hasCol($pdo, $table, 'receipt_number');

/** Build SELECT */
$fields = "inv.id, inv.amount";
$fields .= $typeCol ? ", inv.`$typeCol` AS investment_type" : ", 'cash' AS investment_type";
$fields .= $dateCol ? ", inv.`$dateCol` AS created_at"       : ", NOW() AS created_at";
$fields .= $hasTxn  ? ", inv.transaction_id"                 : ", CONCAT('TXN-', LPAD(inv.id,6,'0')) AS transaction_id";
$fields .= $hasRcp  ? ", inv.receipt_number"                 : ", CONCAT('RCP-', LPAD(inv.id,6,'0')) AS receipt_number";

$sql = "SELECT $fields,
               i.account_number, i.first_name, i.last_name,
               u.email AS investor_email
        FROM investments inv
        JOIN investors i ON i.id = inv.investor_id
        JOIN users u     ON u.id = i.user_id
        WHERE inv.id = ?
        LIMIT 1";
$st = $pdo->prepare($sql);
$st->execute([$id]);
$row = $st->fetch();

if (!$row) {
    http_response_code(404);
    exit('Receipt not found.');
}

/** Settings (fallbacks to Admin → Settings) */
$S = getSettings($pdo);
$company  = $S['org.name']              ?: 'National Agro Business Support Initiative';
$email    = $S['org.email']             ?: '';
$phone    = $S['org.phone']             ?: '';
$address  = $S['org.address']           ?: 'Kampala, Uganda';
$logoAbs  = resolveLogoPath($S['brand.logo'] ?? '');
$brandHex = preg_match('/^#[0-9a-f]{6}$/i', $S['brand.color_primary'] ?? '') ? $S['brand.color_primary'] : '#2c5530';

/** TCPDF fallback */
if (!includeTCPDF()) {
    header('Content-Type: text/plain; charset=utf-8');
    echo "TCPDF not found.\n\n";
    echo "Receipt: " . ($row['receipt_number'] ?? $row['transaction_id']) . "\n";
    echo "Investor: " . $row['first_name'] . " " . $row['last_name'] . " (" . $row['account_number'] . ")\n";
    echo "Amount: " . fmt_money($row['amount']) . "\n";
    echo "Type: " . ucfirst($row['investment_type']) . "\n";
    echo "Date: " . (function_exists('formatDate') ? formatDate($row['created_at'],'d M Y H:i') : $row['created_at']) . "\n";
    exit;
}

/** Utilities for colors */
function hexToRgb(string $hex): array {
    $hex = ltrim($hex, '#');
    return [
        hexdec(substr($hex,0,2)),
        hexdec(substr($hex,2,2)),
        hexdec(substr($hex,4,2)),
    ];
}

/** Build QR payload (signed) */
function buildQrPayload(array $row): string {
    $data = [
        'receipt'   => (string)($row['receipt_number'] ?? ''),
        'txn'       => (string)($row['transaction_id'] ?? ''),
        'amount'    => (float)$row['amount'],
        'type'      => (string)$row['investment_type'],
        'account'   => (string)$row['account_number'],
        'investor'  => trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? '')),
        'date'      => (string)$row['created_at'],
    ];
    $secret = defined('APP_KEY') ? APP_KEY : 'nabsisecret';
    $data['sig'] = hash_hmac('sha256', json_encode($data, JSON_UNESCAPED_SLASHES), $secret);
    return json_encode($data, JSON_UNESCAPED_SLASHES);
}

/** Start PDF */
$pdf = new TCPDF('P','mm','A5',true,'UTF-8',false);
$pdf->SetTitle('Investment Receipt');
$pdf->SetMargins(10,12,10);
$pdf->AddPage();

/* ------------------------------------------------------------------
   WATERMARK — use the same logo as header (if found), otherwise skip
------------------------------------------------------------------- */
$hasLogo = ($logoAbs && is_readable($logoAbs));
if ($hasLogo) {
    // Fit the watermark to ~65% of the printable width, centered
    $m = $pdf->getMargins();
    $printableW = $pdf->getPageWidth()  - ($m['left'] + $m['right']);
    $wmW = $printableW * 0.65;

    $imgW = 1; $imgH = 1;
    if ($info = @getimagesize($logoAbs)) { $imgW = max(1,$info[0]); $imgH = max(1,$info[1]); }
    $wmH = $wmW * ($imgH / $imgW);

    $wmX = ($pdf->getPageWidth()  - $wmW) / 2;
    $wmY = ($pdf->getPageHeight() - $wmH) / 2;

    if (method_exists($pdf,'SetAlpha')) $pdf->SetAlpha(0.06);
    $pdf->Image($logoAbs, $wmX, $wmY, $wmW, $wmH, '', '', '', false, 300, '', false, false, 0, false, false, false);
    if (method_exists($pdf,'SetAlpha')) $pdf->SetAlpha(1);
}

/* Header bar with brand color (unchanged) */
list($r,$g,$b) = hexToRgb($brandHex);
$pdf->SetFillColor($r,$g,$b);
$pdf->Rect(10,12,130,12,'F');

/* Logo in HEADER (left, inside the bar) */
if ($hasLogo) {
    $pdf->Image($logoAbs, 12, 13, 10, 10, '', '', '', true, 300, '', false, false, 0, false, false, false);
}

$pdf->SetTextColor(255,255,255);
$pdf->SetFont('helvetica','B',12);
$pdf->SetXY($hasLogo ? 24 : 12, 14);
$pdf->Write(7, $company);

/* Company details block (unchanged) */
$pdf->SetTextColor(0,0,0);
$pdf->SetFont('helvetica','',9);
$companyHtml = "<div>$address</div>"
             . ($phone? "<div>$phone</div>" : "")
             . ($email? "<div>$email</div>" : "");
$pdf->SetXY(12, 26);
$pdf->writeHTML($companyHtml, true, false, true, false, '');

/* Receipt meta (unchanged) */
$displayDate = function_exists('formatDate') ? formatDate($row['created_at'],'d M Y H:i') : date('d M Y H:i', strtotime($row['created_at']));
$rcpNo = htmlspecialchars((string)($row['receipt_number'] ?? $row['transaction_id']));
$meta = '
<table cellpadding="4" cellspacing="0" border="0" style="font-size:10px;">
  <tr>
    <td><b>Receipt No:</b> '. $rcpNo .'</td>
    <td><b>Date:</b> '. $displayDate .'</td>
  </tr>
  <tr>
    <td><b>Account #:</b> '. htmlspecialchars((string)$row['account_number']) .'</td>
    <td><b>Type:</b> '. htmlspecialchars(ucfirst((string)$row['investment_type'])) .'</td>
  </tr>
</table>';
$pdf->writeHTML($meta, true, false, true, false, '');

/* Investor + Amount table (unchanged) */
$tbl = '
<table cellpadding="6" cellspacing="0" border="1" style="font-size:11px;">
  <tr style="background-color:#eef5ef;">
    <td width="60%"><b>Investor</b></td>
    <td width="40%"><b>Amount</b></td>
  </tr>
  <tr>
    <td>'. htmlspecialchars(trim(($row['first_name'] ?? '').' '.($row['last_name'] ?? ''))) .'</td>
    <td><b>'. fmt_money($row['amount']) .'</b></td>
  </tr>
</table>';
$pdf->writeHTML($tbl, true, false, true, false, '');

/* QR Code (unchanged) */
$qrData = buildQrPayload($row);
$style = [
    'border' => 0,
    'vpadding' => 'auto',
    'hpadding' => 'auto',
    'fgcolor' => [0,0,0],
    'bgcolor' => false,
    'module_width' => 1,
    'module_height' => 1
];
$pdf->write2DBarcode($qrData, 'QRCODE,H', 120, 90, 28, 28, $style, 'N');

/* QR caption (unchanged) */
$pdf->SetFont('helvetica','',8);
$pdf->SetXY(120, 120);
$pdf->Cell(30, 4, 'Scan to verify', 0, 1, 'C');

/* Footer note (unchanged) */
$pdf->Ln(2);
$pdf->SetFont('helvetica','I',9);
$pdf->writeHTML('<div style="color:#6b7280;">Thank you for your investment. Please keep this receipt for your records.</div>', true, false, true, false, '');

$pdf->Output('receipt_'.$rcpNo.'.pdf','I');
