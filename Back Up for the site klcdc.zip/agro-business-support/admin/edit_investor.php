<?php
// admin/edit_investor.php
declare(strict_types=1);

require_once '../config/config.php';
require_once '../classes/Auth.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect('../index.php');
}

$auth = new Auth();
if (!$auth->validateSession()) {
    redirect('../index.php');
}

/** Resolve a PDO from common patterns in your config */
function resolvePDO(): PDO {
    if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) return $GLOBALS['pdo'];
    if (isset($GLOBALS['conn']) && $GLOBALS['conn'] instanceof PDO) return $GLOBALS['conn'];
    if (isset($GLOBALS['db'])  && $GLOBALS['db']  instanceof PDO) return $GLOBALS['db'];

    if (function_exists('getDbConnection')) { $p = getDbConnection(); if ($p instanceof PDO) return $p; }
    if (function_exists('getPDO'))          { $p = getPDO();          if ($p instanceof PDO) return $p; }
    if (function_exists('db'))              { $p = db();              if ($p instanceof PDO) return $p; }

    if (class_exists('Database')) {
        $db = new Database();
        if (method_exists($db,'connect'))       { $p = $db->connect();       if ($p instanceof PDO) return $p; }
        if (method_exists($db,'getConnection')) { $p = $db->getConnection(); if ($p instanceof PDO) return $p; }
    }

    throw new RuntimeException('Database connection not available.');
}

try {
    $pdo = resolvePDO();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    http_response_code(500);
    exit('Database connection not available.');
}


$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    redirect('investors.php');
}

/** Load investor + user email */
$st = $pdo->prepare("
    SELECT i.*, u.email
    FROM investors i
    JOIN users u ON u.id = i.user_id
    WHERE i.id = ?
    LIMIT 1
");
$st->execute([$id]);
$inv = $st->fetch(PDO::FETCH_ASSOC);
if (!$inv) {
    redirect('investors.php');
}

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $message = 'Invalid request. Please try again.';
        $message_type = 'error';
    } else {
        $first_name  = sanitize_input($_POST['first_name'] ?? '');
        $last_name   = sanitize_input($_POST['last_name'] ?? '');
        $email       = sanitize_input($_POST['email'] ?? '');
        $phone       = sanitize_input($_POST['phone'] ?? '');
        $address     = sanitize_input($_POST['address'] ?? '');
        $city        = sanitize_input($_POST['city'] ?? '');
        $state       = sanitize_input($_POST['state'] ?? '');
        $date_joined = sanitize_input($_POST['date_joined'] ?? '');

        // Basic validation
        if ($first_name==='' || $last_name==='' || $phone==='' || $address==='' || $city==='' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $message = 'Please fill all fields correctly.';
            $message_type = 'error';
        } else {
            try {
                $pdo->beginTransaction();

                // Update investor profile
                $u1 = $pdo->prepare("
                    UPDATE investors
                    SET first_name=?, last_name=?, phone=?, address=?, city=?, state=?, date_joined=?
                    WHERE id=?
                ");
                $u1->execute([$first_name,$last_name,$phone,$address,$city,$state,$date_joined,$id]);

                // Update linked user email
                $u2 = $pdo->prepare("
                    UPDATE users u
                    JOIN investors i ON i.user_id = u.id
                    SET u.email = ?
                    WHERE i.id = ?
                ");
                $u2->execute([$email, $id]);

                $pdo->commit();

                $message = 'Investor updated successfully.';
                $message_type = 'success';

                // Refresh local data for display
                $st->execute([$id]);
                $inv = $st->fetch(PDO::FETCH_ASSOC);

            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();

                $msg = $e->getMessage();
                if (stripos($msg,'duplicate') !== false && stripos($msg,'email') !== false) {
                    $msg = 'Email already exists on another account.';
                }
                $message = 'Update failed: ' . htmlspecialchars($msg);
                $message_type = 'error';
            }
        }
    }
}

$page_title = 'Edit Investor';
include 'includes/header.php';
?>

<style>
/* ===== Edit Investor — scoped form polish (safe, no layout break) ===== */
.main-content .card{
  border-radius:16px;
  border:1px solid var(--border-color, #e6edf1);
  box-shadow:0 10px 28px rgba(0,0,0,.06);
}

/* Spacing & small utility fixes (Bootstrap-like) */
.main-content .d-flex{display:flex}
.main-content .justify-content-end{justify-content:flex-end}
.main-content .gap-2{gap:10px}
.main-content .mt-3{margin-top:14px}

/* Headings + muted text */
.main-content .page-header{margin-bottom:18px;padding-bottom:10px;border-bottom:1px solid var(--border-color, #e6edf1)}
.main-content .page-header h1{margin:0;font-size:1.35rem;color:var(--primary-color, #2c5530)}
.main-content .text-muted{color:#6b7280}

/* Form groups */
.main-content .form-group{margin-bottom:14px}
.main-content .form-group label{
  display:block;
  margin-bottom:6px;
  font-size:.92rem;
  color:#6b7280;
}

/* Inputs */
.main-content .form-control{
  width:100%;
  padding:12px 14px;
  background:#fff;
  color:#111827;
  border:1px solid var(--border-color, #e6edf1);
  border-radius:12px;
  outline:0;
  transition:box-shadow .15s ease, border-color .15s ease;
}
.main-content .form-control::placeholder{color:#9aa3ad}
.main-content .form-control:focus{
  border-color:var(--primary-color, #2c5530);
  box-shadow:0 0 0 4px var(--focus-ring, #d1fae5);
}

/* Alerts (success/error) */
.main-content .alert{
  border-radius:12px;
  padding:12px 14px;
  border:1px solid var(--border-color, #e6edf1);
  box-shadow:0 2px 8px rgba(0,0,0,.05);
  margin-bottom:12px;
}
.main-content .alert-success{background:#eefaf1;color:#14532d}
.main-content .alert-error{background:#fff5f5;color:#7f1d1d}

/* Buttons */
.main-content .btn{
  appearance:none;
  border:1px solid transparent;
  border-radius:12px;
  padding:10px 14px;
  font-weight:700;
  cursor:pointer;
  line-height:1;
  text-decoration:none;
  display:inline-flex;
  align-items:center;
  gap:8px;
  box-shadow:0 2px 8px rgba(0,0,0,.05);
  transition:filter .15s ease, box-shadow .15s ease, background .15s ease, color .15s ease, border-color .15s ease;
}
.main-content .btn i{font-size:0.95em}

/* Primary / Secondary colors match your theme */
.main-content .btn-primary{
  background:var(--primary-color, #2c5530);
  color:#fff;
  border-color:var(--primary-color, #2c5530);
}
.main-content .btn-primary:hover{filter:brightness(.96); box-shadow:0 0 0 3px var(--focus-ring, #d1fae5)}

.main-content .btn-secondary{
  background:#fff;
  color:var(--primary-color, #2c5530);
  border-color:var(--primary-color, #2c5530);
}
.main-content .btn-secondary:hover{background:#f7faf7}

/* Make narrow columns breathe a bit on small screens */
@media (max-width: 768px){
  .main-content .row{gap:10px}
}
</style>

<div class="main-content">
  <div class="page-header">
    <h1><i class="fas fa-user-edit"></i> Edit Investor</h1>
    <p class="text-muted">Update investor profile</p>
  </div>

  <?php if (!empty($message)): ?>
    <div class="alert alert-<?php echo $message_type; ?>">
      <i class="fas fa-<?php echo $message_type==='success'?'check-circle':'exclamation-circle'; ?>"></i>
      <?php echo htmlspecialchars($message); ?>
    </div>
  <?php endif; ?>

  <div class="card">
    <div class="card-body">
      <form method="POST" novalidate>
        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">

        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label>First Name</label>
              <input class="form-control" name="first_name" value="<?php echo htmlspecialchars($inv['first_name']); ?>" required>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label>Last Name</label>
              <input class="form-control" name="last_name" value="<?php echo htmlspecialchars($inv['last_name']); ?>" required>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label>Email</label>
              <input class="form-control" type="email" name="email" value="<?php echo htmlspecialchars($inv['email']); ?>" required>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label>Phone</label>
              <input class="form-control" name="phone" value="<?php echo htmlspecialchars($inv['phone']); ?>" required>
            </div>
          </div>
        </div>

        <div class="form-group">
          <label>Address</label>
          <input class="form-control" name="address" value="<?php echo htmlspecialchars($inv['address']); ?>" required>
        </div>

        <div class="row">
          <div class="col-md-5">
            <div class="form-group">
              <label>City</label>
              <input class="form-control" name="city" value="<?php echo htmlspecialchars($inv['city']); ?>" required>
            </div>
          </div>
          <div class="col-md-5">
            <div class="form-group">
              <label>State/Region</label>
              <input class="form-control" name="state" value="<?php echo htmlspecialchars($inv['state']); ?>">
            </div>
          </div>
          <div class="col-md-2">
            <div class="form-group">
              <label>Date Joined</label>
              <input class="form-control" type="date" name="date_joined" value="<?php echo htmlspecialchars(substr($inv['date_joined'],0,10)); ?>" required>
            </div>
          </div>
        </div>

        <div class="d-flex justify-content-end gap-2 mt-3">
          <a href="investors.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
          <button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Save Changes</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
