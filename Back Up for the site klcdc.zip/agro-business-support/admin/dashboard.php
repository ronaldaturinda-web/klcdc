<?php
/**
 * Admin Dashboard
 * National Agro Business Support Initiative
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../classes/Auth.php';
require_once __DIR__ . '/../classes/Investment.php';
require_once __DIR__ . '/../classes/Investor.php';

// --- Auth guards ---
if (!isLoggedIn() || !isAdmin()) {
    redirect(APP_URL . '/index.php');
    exit;
}

$auth       = new Auth();
$investment = new Investment();
$investor   = new Investor();

if (!$auth->validateSession()) {
    redirect(APP_URL . '/index.php');
    exit;
}

// --- Data for dashboard ---
$stats            = $investment->getInvestmentStatistics() ?? [];
$total_investors  = (int) ($investor->getTotalInvestorsCount() ?? 0);
$monthly_data     = $investment->getMonthlyInvestmentSummary() ?? []; // expect: [{month:'1',investment_type:'cash',total_amount:'12345.00'}, ...]
$recent_investments = $investment->getAllInvestments(10, 0) ?? [];

$page_title = 'Admin Dashboard';
include __DIR__ . '/includes/header.php';
?>
<div class="main-content">
  <div class="page-header">
    <h1><i class="fas fa-tachometer-alt"></i> Dashboard</h1>
    <p class="text-muted">
      Welcome back, <?php echo htmlspecialchars($_SESSION['username'] ?? ''); ?>!
    </p>
  </div>

  <!-- Statistics Cards -->
  <div class="stats-grid">
    <div class="stat-card success">
      <div class="stat-icon"><i class="fas fa-money-bill-wave"></i></div>
      <div class="stat-number"><?php echo formatCurrency($stats['total_amount'] ?? 0); ?></div>
      <div class="stat-label">Total Investments</div>
    </div>

    <div class="stat-card info">
      <div class="stat-icon"><i class="fas fa-users"></i></div>
      <div class="stat-number"><?php echo number_format($total_investors); ?></div>
      <div class="stat-label">Total Investors</div>
    </div>

    <div class="stat-card warning">
      <div class="stat-icon"><i class="fas fa-chart-line"></i></div>
      <div class="stat-number"><?php echo number_format($stats['total_transactions'] ?? 0); ?></div>
      <div class="stat-label">Total Transactions</div>
    </div>

    <div class="stat-card danger">
      <div class="stat-icon"><i class="fas fa-calculator"></i></div>
      <div class="stat-number"><?php echo formatCurrency($stats['average_investment'] ?? 0); ?></div>
      <div class="stat-label">Average Investment</div>
    </div>
  </div>

  <!-- Charts -->
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h3><i class="fas fa-chart-bar"></i> Monthly Investment Trends</h3>
        </div>
        <div class="card-body">
          <canvas id="monthlyInvestmentChart" width="400" height="200"></canvas>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card">
        <div class="card-header">
          <h3><i class="fas fa-pie-chart"></i> Investment Types</h3>
        </div>
        <div class="card-body">
          <canvas id="investmentTypeChart" width="300" height="300"></canvas>

          <div class="mt-3">
            <div class="d-flex justify-content-between mb-2">
              <span>Cash:</span><strong><?php echo formatCurrency($stats['cash_total'] ?? 0); ?></strong>
            </div>
            <div class="d-flex justify-content-between mb-2">
              <span>Material:</span><strong><?php echo formatCurrency($stats['material_total'] ?? 0); ?></strong>
            </div>
            <div class="d-flex justify-content-between mb-2">
              <span>Labor:</span><strong><?php echo formatCurrency($stats['labor_total'] ?? 0); ?></strong>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>

  <!-- Recent Investments -->
  <div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
      <h3><i class="fas fa-clock"></i> Recent Investments</h3>
      <a href="<?php echo APP_URL; ?>/admin/investments.php" class="btn btn-primary btn-sm">
        <i class="fas fa-eye"></i> View All
      </a>
    </div>
    <div class="card-body">
      <?php if (!empty($recent_investments)): ?>
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Investor</th>
                <th>Account No.</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
            <?php foreach ($recent_investments as $inv): ?>
              <tr>
                <td><?php echo formatDate($inv['investment_date'] ?? '', 'd/m/Y'); ?></td>
                <td><?php echo htmlspecialchars($inv['investor_name'] ?? ''); ?></td>
                <td><?php echo htmlspecialchars($inv['account_number'] ?? ''); ?></td>
                <td>
                  <?php $t = $inv['investment_type'] ?? 'cash'; ?>
                  <span class="badge badge-<?php echo $t === 'cash' ? 'success' : ($t === 'material' ? 'warning' : 'info'); ?>">
                    <?php echo ucfirst($t); ?>
                  </span>
                </td>
                <td><?php echo formatCurrency($inv['amount'] ?? 0); ?></td>
                <td>
                  <?php $st = $inv['status'] ?? 'pending'; ?>
                  <span class="badge badge-<?php echo $st === 'confirmed' ? 'success' : ($st === 'pending' ? 'warning' : 'danger'); ?>">
                    <?php echo ucfirst($st); ?>
                  </span>
                </td>
                <td>
                  <a href="<?php echo APP_URL; ?>/admin/investor_details.php?id=<?php echo (int)$inv['id']; ?>" class="btn btn-sm btn-info" title="View Details">
                    <i class="fas fa-eye"></i>
                  </a>
                  <a href="<?php echo APP_URL; ?>/admin/print_receipt.php?id=<?php echo (int)$inv['id']; ?>" class="btn btn-sm btn-secondary" title="Download Receipt" target="_blank">
                    <i class="fas fa-download"></i>
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <div class="text-center py-4">
          <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
          <h5>No investments found</h5>
          <p class="text-muted">Start by recording the first investment.</p>
          <a href="<?php echo APP_URL; ?>/admin/add_investment.php" class="btn btn-primary">
            <i class="fas fa-plus"></i> Record Investment
          </a>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Quick Actions -->
  <div class="card">
    <div class="card-header"><h3><i class="fas fa-bolt"></i> Quick Actions</h3></div>
    <div class="card-body">
      <div class="row">
        <div class="col-md-3">
          <a href="<?php echo APP_URL; ?>/admin/add_investor.php" class="btn btn-primary btn-block mb-2">
            <i class="fas fa-user-plus"></i> Add New Investor
          </a>
        </div>
        <div class="col-md-3">
          <a href="<?php echo APP_URL; ?>/admin/add_investment.php" class="btn btn-success btn-block mb-2">
            <i class="fas fa-plus-circle"></i> Record Investment
          </a>
        </div>
        <div class="col-md-3">
          <a href="<?php echo APP_URL; ?>/admin/reports.php" class="btn btn-info btn-block mb-2">
            <i class="fas fa-chart-line"></i> Generate Report
          </a>
        </div>
        <div class="col-md-3">
          <a href="<?php echo APP_URL; ?>/admin/users.php" class="btn btn-warning btn-block mb-2">
            <i class="fas fa-users"></i> Manage Investors
          </a>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Monthly Investment Chart (UGX)
const monthlyCtx = document.getElementById('monthlyInvestmentChart').getContext('2d');
const monthlyData = <?php echo json_encode(array_values($monthly_data)); ?>;

const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const chartData = {
  labels: months,
  datasets: [
    { label: 'Cash',     data: Array(12).fill(0), backgroundColor:'rgba(40,167,69,0.8)',  borderColor:'rgba(40,167,69,1)',  borderWidth:1 },
    { label: 'Material', data: Array(12).fill(0), backgroundColor:'rgba(255,193,7,0.8)', borderColor:'rgba(255,193,7,1)', borderWidth:1 },
    { label: 'Labor',    data: Array(12).fill(0), backgroundColor:'rgba(23,162,184,0.8)', borderColor:'rgba(23,162,184,1)', borderWidth:1 }
  ]
};

monthlyData.forEach(item => {
  const m = parseInt(item.month, 10) - 1;
  const idx = item.investment_type === 'cash' ? 0 : (item.investment_type === 'material' ? 1 : 2);
  if (!Number.isNaN(m) && m >= 0 && m < 12) {
    chartData.datasets[idx].data[m] = parseFloat(item.total_amount || 0);
  }
});

new Chart(monthlyCtx, {
  type: 'bar',
  data: chartData,
  options: {
    responsive: true,
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: (value) => new Intl.NumberFormat('en-UG', { style:'currency', currency:'UGX', minimumFractionDigits:0 }).format(value)
        }
      }
    },
    plugins: {
      tooltip: {
        callbacks: {
          label: (ctx) => `${ctx.dataset.label}: ` + new Intl.NumberFormat('en-UG', { style:'currency', currency:'UGX' }).format(ctx.raw)
        }
      }
    }
  }
});

// Investment Type Chart (UGX)
const typeCtx = document.getElementById('investmentTypeChart').getContext('2d');
const cashTotal     = <?php echo (float)($stats['cash_total'] ?? 0); ?>;
const materialTotal = <?php echo (float)($stats['material_total'] ?? 0); ?>;
const laborTotal    = <?php echo (float)($stats['labor_total'] ?? 0); ?>;

new Chart(typeCtx, {
  type: 'doughnut',
  data: {
    labels: ['Cash','Material','Labor'],
    datasets: [{
      data: [cashTotal, materialTotal, laborTotal],
      backgroundColor: ['rgba(40,167,69,0.8)','rgba(255,193,7,0.8)','rgba(23,162,184,0.8)'],
      borderColor:   ['rgba(40,167,69,1)','rgba(255,193,7,1)','rgba(23,162,184,1)'],
      borderWidth: 2
    }]
  },
  options: {
    responsive: true,
    plugins: {
      legend: { position: 'bottom' },
      tooltip: {
        callbacks: {
          label: (ctx) => `${ctx.label}: ` + new Intl.NumberFormat('en-UG', { style:'currency', currency:'UGX' }).format(ctx.raw)
        }
      }
    }
  }
});
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
