<?php
// admin/investments.php
declare(strict_types=1);
session_start();

/**
 * Investments Overview (Admin)
 * - Filters, CSV/PDF export, receipt link (kept)
 * - EDIT via modal (pop out), DELETE with confirm
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../classes/Auth.php';

if (!isLoggedIn() || !isAdmin()) { redirect('../index.php'); }
$auth = new Auth();
if (!$auth->validateSession()) { redirect('../index.php'); }

/** Resolve PDO robustly */
function resolvePDO(): PDO {
    if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) return $GLOBALS['pdo'];
    if (function_exists('getDbConnection')) { $p = getDbConnection(); if ($p instanceof PDO) return $p; }
    if (class_exists('Database')) {
        $db = new Database();
        if (method_exists($db,'connect'))       { $p = $db->connect();       if ($p instanceof PDO) return $p; }
        if (method_exists($db,'getConnection')) { $p = $db->getConnection(); if ($p instanceof PDO) return $p; }
    }
    throw new RuntimeException('Could not obtain a PDO connection');
}
try {
    $pdo = resolvePDO();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    http_response_code(500);
    die('Database error: ' . htmlspecialchars($e->getMessage()));
}

/** TCPDF for PDF export */
function tryIncludeTCPDF(): bool {
    $candidates = [
        __DIR__ . '/../vendor/tcpdf/tcpdf.php',
        __DIR__ . '/../tcpdf_min/tcpdf.php',
        __DIR__ . '/../tcpdf.php',
    ];
    foreach ($candidates as $p) {
        if (is_readable($p)) {
            if (!defined('K_PATH_CACHE')) {
                $cache = realpath(__DIR__ . '/../temp');
                if (!$cache) { @mkdir(__DIR__ . '/../temp', 0775, true); $cache = __DIR__ . '/../temp'; }
                define('K_PATH_CACHE', rtrim($cache, '/\\') . DIRECTORY_SEPARATOR);
            }
            require_once $p;
            return true;
        }
    }
    return false;
}

/** Helpers */
function moneyUGX(float $amount): string { return 'UGX ' . number_format($amount, 0, '.', ','); }
function validType(?string $t): ?string { $t = $t ? strtolower($t) : null; return in_array($t, ['cash','material','labor'], true) ? $t : null; }
function parseDate(?string $s, string $eod='00:00:00'): ?string {
    if(!$s) return null; $ts=strtotime($s); if(!$ts) return null; return date('Y-m-d', $ts).' '.$eod;
}
function typeIcon(string $type, int $size=16): string {
    $s=$size; switch(strtolower($type)){
        case 'cash': return "<svg width='{$s}' height='{$s}' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'>
            <rect x='3' y='6' width='18' height='12' rx='2' stroke='#2c5530' stroke-width='1.7'/>
            <circle cx='12' cy='12' r='3' stroke='#2c5530' stroke-width='1.7'/></svg>";
        case 'material': return "<svg width='{$s}' height='{$s}' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'>
            <path d='M12 3L3 9l9 6 9-6-9-6Z' stroke='#2c5530' stroke-width='1.7'/>
            <path d='M3 15l9 6 9-6' stroke='#2c5530' stroke-width='1.7'/></svg>";
        default: return "<svg width='{$s}' height='{$s}' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'>
            <path d='M7 7l10 10M7 17L17 7' stroke='#2c5530' stroke-width='1.7'/>
            <circle cx='6' cy='6' r='2' stroke='#2c5530' stroke-width='1.7'/>
            <circle cx='18' cy='18' r='2' stroke='#2c5530' stroke-width='1.7'/></svg>";
    }
}

/** Queries */
function buildWhere(array $filters, array &$params): string {
    $w=[];
    if (!empty($filters['q'])) {
        $w[]="(i.first_name LIKE :q OR i.last_name LIKE :q OR i.account_number LIKE :q OR inv.transaction_id LIKE :q OR inv.receipt_number LIKE :q)";
        $params[':q']='%'.$filters['q'].'%';
    }
    if (!empty($filters['type'])) { $w[]="inv.investment_type=:t"; $params[':t']=$filters['type']; }
    if (!empty($filters['from'])) { $w[]="inv.investment_date>=:from"; $params[':from']=$filters['from']; }
    if (!empty($filters['to']))   { $w[]="inv.investment_date<=:to";   $params[':to']=$filters['to']; }
    return $w ? 'WHERE '.implode(' AND ',$w) : '';
}
function fetchInvestments(PDO $pdo, array $filters, int $limit, int $offset): array {
    $params=[]; $where=buildWhere($filters,$params);
    $sql="SELECT inv.id, inv.transaction_id, inv.receipt_number, inv.investment_type, inv.amount, inv.investment_date,
                 i.account_number, i.first_name, i.last_name
          FROM investments inv
          JOIN investors i ON inv.investor_id=i.id
          $where
          ORDER BY inv.investment_date DESC, inv.id DESC
          LIMIT $limit OFFSET $offset";
    $st=$pdo->prepare($sql); $st->execute($params); return $st->fetchAll();
}
function countInvestments(PDO $pdo, array $filters): int {
    $params=[]; $where=buildWhere($filters,$params);
    $st=$pdo->prepare("SELECT COUNT(*) AS c FROM investments inv JOIN investors i ON inv.investor_id=i.id $where");
    $st->execute($params); $row=$st->fetch(); return (int)($row['c']??0);
}
function totalsInvestments(PDO $pdo, array $filters): array {
    $params=[]; $where=buildWhere($filters,$params);
    $st=$pdo->prepare("SELECT
        SUM(inv.amount) AS total_amount,
        SUM(CASE WHEN inv.investment_type='cash' THEN inv.amount ELSE 0 END) AS total_cash,
        SUM(CASE WHEN inv.investment_type='material' THEN inv.amount ELSE 0 END) AS total_material,
        SUM(CASE WHEN inv.investment_type='labor' THEN inv.amount ELSE 0 END) AS total_labor
      FROM investments inv
      JOIN investors i ON inv.investor_id=i.id
      $where");
    $st->execute($params); $r=$st->fetch()?:[];
    return [
        'total_amount'=>(float)($r['total_amount']??0),
        'total_cash'=>(float)($r['total_cash']??0),
        'total_material'=>(float)($r['total_material']??0),
        'total_labor'=>(float)($r['total_labor']??0),
    ];
}

/** Exports */
function exportCSV(PDO $pdo, array $filters): void {
    $params=[]; $where=buildWhere($filters,$params);
    $st=$pdo->prepare("SELECT inv.investment_date, inv.transaction_id, inv.receipt_number, inv.investment_type, inv.amount,
                              i.account_number, CONCAT(i.first_name,' ',i.last_name) AS investor_name
                       FROM investments inv
                       JOIN investors i ON inv.investor_id=i.id
                       $where
                       ORDER BY inv.investment_date DESC, inv.id DESC");
    $st->execute($params); $rows=$st->fetchAll();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=investments_export.csv');
    $out=fopen('php://output','w');
    fputcsv($out,['Date','TXN','Receipt','Type','Amount(UGX)','Account','Investor']);
    foreach($rows as $r){
        fputcsv($out,[
            $r['investment_date'],$r['transaction_id'],$r['receipt_number'],
            strtoupper($r['investment_type']),number_format((float)$r['amount'],0,'.',','),
            $r['account_number'],$r['investor_name']
        ]);
    }
    fclose($out); exit;
}
function exportPDF(PDO $pdo, array $filters): void {
    if(!tryIncludeTCPDF()){ header('Content-Type: text/plain'); echo 'TCPDF not found.'; exit; }
    while(ob_get_level()){ ob_end_clean(); }

    $params=[]; $where=buildWhere($filters,$params);
    $st=$pdo->prepare("SELECT inv.investment_date, inv.transaction_id, inv.receipt_number, inv.investment_type, inv.amount,
                              i.account_number, CONCAT(i.first_name,' ',i.last_name) AS investor_name
                       FROM investments inv
                       JOIN investors i ON inv.investor_id=i.id
                       $where
                       ORDER BY inv.investment_date DESC, inv.id DESC");
    $st->execute($params); $rows=$st->fetchAll();
    $tot=totalsInvestments($pdo,$filters);

    $pdf=new TCPDF('P','mm','A4',true,'UTF-8',false);
    $pdf->SetTitle('Investment Report'); $pdf->SetMargins(12,12,12); $pdf->AddPage(); $pdf->SetFont('helvetica','',11);
    $pdf->SetFillColor(44,85,48); $pdf->Rect(12,12,186,14,'F');
    $pdf->SetTextColor(255,255,255); $pdf->SetFont('helvetica','B',13); $pdf->SetXY(16,14);
    $pdf->Write(8,'National Agro Business Support Initiative — Investment Report');
    $pdf->Ln(18); $pdf->SetTextColor(0,0,0);

    $fQ=htmlspecialchars($filters['q']??''); $fT=htmlspecialchars($filters['type']??'All'); $fF=htmlspecialchars($filters['from_raw']??''); $fT0=htmlspecialchars($filters['to_raw']??'');
    $pdf->writeHTML("<table cellpadding='4' style='font-size:11px;'>
      <tr><td><b>Search:</b> $fQ</td><td><b>Type:</b> ".strtoupper($fT)."</td><td><b>From:</b> $fF</td><td><b>To:</b> $fT0</td></tr>
    </table><hr>", true,false,true,false,'');

    $pdf->writeHTML("<table cellpadding='5' style='font-size:11px;'>
      <tr>
        <td><b>Total:</b> ".moneyUGX($tot['total_amount'])."</td>
        <td><b>Cash:</b> ".moneyUGX($tot['total_cash'])."</td>
        <td><b>Material:</b> ".moneyUGX($tot['total_material'])."</td>
        <td><b>Labor:</b> ".moneyUGX($tot['total_labor'])."</td>
      </tr>
    </table>", true,false,true,false,'');

    $tbl="<table border='1' cellpadding='5' cellspacing='0' style='font-size:10.5px;'>
      <thead><tr style='background-color:#eef5ef;'>
        <th width='18%'>Date</th><th width='14%'>Receipt</th><th width='14%'>TXN</th>
        <th width='12%'>Type</th><th width='14%'>Amount</th><th width='28%'>Investor (Acct)</th>
      </tr></thead><tbody>";
    foreach($rows as $r){
        $tbl.="<tr>
          <td>".htmlspecialchars($r['investment_date'])."</td>
          <td>".htmlspecialchars($r['receipt_number'])."</td>
          <td>".htmlspecialchars($r['transaction_id'])."</td>
          <td>".strtoupper(htmlspecialchars($r['investment_type']))."</td>
          <td>".moneyUGX((float)$r['amount'])."</td>
          <td>".htmlspecialchars($r['investor_name'])." (".htmlspecialchars($r['account_number']).")</td>
        </tr>";
    }
    $tbl.="</tbody></table>";
    $pdf->writeHTML($tbl,true,false,true,false,''); $pdf->Output('investment_report.pdf','I'); exit;
}

/* ---------- Handle POST: update & delete ---------- */
$errors = [];
$successMsg = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf'] ?? '')) {
        $errors[] = 'Invalid security token.';
    } else {
        $action = $_POST['action'] ?? '';
        if ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id <= 0) { $errors[] = 'Invalid investment ID.'; }
            else {
                try {
                    $chk=$pdo->prepare("SELECT id FROM investments WHERE id=? LIMIT 1"); $chk->execute([$id]);
                    if(!$chk->fetch()){ $errors[]='Investment not found.'; }
                    else { $del=$pdo->prepare("DELETE FROM investments WHERE id=?"); $del->execute([$id]); $successMsg='Investment deleted successfully.'; }
                } catch (Throwable $e) { $errors[] = 'Delete failed: ' . htmlspecialchars($e->getMessage()); }
            }
        }
        if ($action === 'update') {
            $id = (int)($_POST['id'] ?? 0);
            $type = validType($_POST['investment_type'] ?? '');
            $amount = (float)($_POST['amount'] ?? 0);
            $receipt = trim($_POST['receipt_number'] ?? '');
            $txn = trim($_POST['transaction_id'] ?? '');
            $dtRaw = trim($_POST['investment_date'] ?? ''); // from datetime-local (YYYY-MM-DDTHH:MM)
            // Normalize datetime
            $dt = null;
            if ($dtRaw !== '') {
                $norm = str_replace('T',' ',$dtRaw);
                $ts = strtotime($norm);
                if ($ts) $dt = date('Y-m-d H:i:s',$ts);
            }

            if ($id<=0) $errors[]='Invalid investment ID.';
            if (!$type) $errors[]='Invalid investment type.';
            if ($amount <= 0) $errors[]='Amount must be greater than zero.';
            if (!$errors) {
                try {
                    $sql="UPDATE investments
                          SET investment_type=?, amount=?, investment_date=?, receipt_number=?, transaction_id=?
                          WHERE id=?";
                    $st=$pdo->prepare($sql);
                    $st->execute([$type, $amount, $dt ?: date('Y-m-d H:i:s'), $receipt, $txn, $id]);
                    $successMsg='Investment updated successfully.';
                } catch (Throwable $e) {
                    $errors[]='Update failed: '.htmlspecialchars($e->getMessage());
                }
            }
        }
    }
}

/* ---------- Filters ---------- */
$qRaw = trim($_GET['q'] ?? '');
$type = validType($_GET['type'] ?? null);
$fromR= trim($_GET['from'] ?? '');
$toR  = trim($_GET['to'] ?? '');
$from = $fromR ? parseDate($fromR,'00:00:00') : null;
$to   = $toR   ? parseDate($toR,'23:59:59')  : null;
$filters = ['q'=>$qRaw?:null,'type'=>$type,'from'=>$from,'to'=>$to,'from_raw'=>$fromR,'to_raw'=>$toR];

/* ---------- Exports ---------- */
if (($_GET['export'] ?? '') === 'csv') exportCSV($pdo, $filters);
if (($_GET['export'] ?? '') === 'pdf') exportPDF($pdo, $filters);

/* ---------- Pagination ---------- */
$perPage = max(10,(int)($_GET['per'] ?? 25));
$page    = max(1,(int)($_GET['page'] ?? 1));
$total   = countInvestments($pdo,$filters);
$pages   = max(1,(int)ceil($total/$perPage));
$page    = min($page,$pages);
$offset  = ($page-1)*$perPage;

/* ---------- Data ---------- */
$rows   = fetchInvestments($pdo,$filters,$perPage,$offset);
$totals = totalsInvestments($pdo,$filters);

/* ---------- Header / Layout ---------- */
$page_title = 'Investments';
include 'includes/header.php';
?>
<style>
  /* Scoped so it won’t fight your global theme */
  .main-content :root{
    --brand:#2c5530; --brand-2:#4a7c59; --bg:#f6f8f6; --text:#1f2937; --muted:#6b7280;
    --card:#ffffff; --border:#e8edf1; --ring:#d1fae5; --shadow:0 10px 30px rgba(0,0,0,.08);
  }
  .main-content .wrap{max-width:1120px;margin:28px auto;padding:0 16px}
  .main-content .card{background:var(--card);border-radius:16px;box-shadow:var(--shadow);border:1px solid var(--border);padding:18px}
  .main-content h1{margin:0;font-size:1.45rem}
  .main-content .topbar{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
  .main-content .toolbar{display:flex;gap:10px;flex-wrap:wrap;align-items:end;margin-top:12px}
  .main-content .toolbar .field{display:flex;flex-direction:column;gap:4px}
  .main-content .toolbar input,.main-content .toolbar select{padding:10px 12px;border:1px solid var(--border);border-radius:12px;outline:none;background:#fff}
  .main-content .toolbar input:focus,.main-content .toolbar select:focus{box-shadow:0 0 0 4px var(--ring);border-color:var(--brand-2)}
  .main-content .meta{display:flex;gap:12px;flex-wrap:wrap;margin-top:12px}
  .main-content .meta .item{background:#eef5ef;border:1px solid #dce9de;border-radius:999px;padding:6px 10px;font-size:.9rem;color:#2c5530}
  .main-content table{width:100%;border-collapse:separate;border-spacing:0 8px}
  .main-content th{font-size:.9rem;color:#374151;text-align:left;padding:0 10px}
  .main-content td{background:#fff;border:1px solid var(--border);border-left:none;border-right:none;padding:12px 10px}
  .main-content tr{box-shadow:0 4px 12px rgba(0,0,0,.04);border-radius:12px}
  .main-content tr td:first-child{border-top-left-radius:12px;border-bottom-left-radius:12px;border-left:1px solid var(--border)}
  .main-content tr td:last-child{border-top-right-radius:12px;border-bottom-right-radius:12px;border-right:1px solid var(--border)}
  .main-content .badge{display:inline-flex;align-items:center;gap:6px;background:#eef5ef;color:#2c5530;border-radius:999px;padding:4px 10px;font-size:.8rem;border:1px solid #dce9de}

  /* Actions — compact buttons to avoid CSS conflicts */
  .row-actions{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
  .row-actions form{display:inline;margin:0}
  .btn-compact{padding:6px 10px;min-height:32px;font-size:.85rem;line-height:1;border-radius:10px}
  .btn-danger.btn-compact{background:#fee2e2;border:1px solid #fecaca;color:#7f1d1d}
  .btn-danger.btn-compact:hover{background:#fecaca}
  .btn-primary.btn-compact{border:1px solid var(--brand)}
  .btn.btn-compact{border:1px solid var(--border)}
  .btn-linklike{background:#fff;color:var(--brand);border:1px solid var(--brand)}
  .btn-linklike:hover{background:#f6fff7}

  /* Modal */
  .modal-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.45);display:none;z-index:1100}
  .modal{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:#fff;border-radius:14px;border:1px solid var(--border);box-shadow:0 20px 50px rgba(0,0,0,.2);width:96%;max-width:560px;display:none;z-index:1110}
  .modal-header{display:flex;justify-content:space-between;align-items:center;padding:14px 16px;border-bottom:1px solid var(--border)}
  .modal-body{padding:16px}
  .modal-actions{display:flex;gap:8px;justify-content:flex-end;padding:12px 16px;border-top:1px solid var(--border)}
  .close-x{background:none;border:0;font-size:20px;line-height:1;cursor:pointer}
  .grid-2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
  .modal label{display:block;font-size:.9rem;color:#6b7280;margin-bottom:6px}
  .modal input,.modal select{width:100%;padding:10px 12px;border:1px solid var(--border);border-radius:10px;background:#fff;outline:none}
  .modal input:focus,.modal select:focus{box-shadow:0 0 0 4px var(--ring);border-color:var(--brand-2)}
  @media (max-width:640px){.grid-2{grid-template-columns:1fr}}

  /* Receipt button: off-white background */
.row-actions .btn-linklike{
  background:#4A7C59;  /* subtle off-white */
  color:#fff
}
.row-actions .btn-linklike:hover{
  background:#eef5ef;  /* gentle hover */
}

</style>

<div class="main-content">
  <div class="wrap">

    <div class="card" style="margin-bottom:12px;">
      <div class="topbar">
        <h1>Investments</h1>
        <div style="display:flex;gap:8px;">
          <a class="btn btn-secondary" href="dashboard.php">← Back to Dashboard</a>
          <a class="btn btn-primary" href="add_investment.php">+ Add Investment</a>
        </div>
      </div>

      <?php if ($errors): ?>
        <div class="alert alert-danger" style="margin-top:10px;">
          <ul style="margin:0 0 0 18px;"><?php foreach($errors as $e): ?><li><?=htmlspecialchars($e)?></li><?php endforeach; ?></ul>
        </div>
      <?php elseif ($successMsg): ?>
        <div class="alert alert-success" style="margin-top:10px;"><?=htmlspecialchars($successMsg)?></div>
      <?php endif; ?>

      <form class="toolbar" method="get">
        <div class="field">
          <label>Search</label>
          <input type="text" name="q" value="<?=htmlspecialchars($qRaw)?>" placeholder="name, account, receipt, TXN">
        </div>
        <div class="field">
          <label>Type</label>
          <select name="type">
            <option value="">All</option>
            <option value="cash"     <?=$type==='cash'?'selected':''?>>Cash</option>
            <option value="material" <?=$type==='material'?'selected':''?>>Material</option>
            <option value="labor"    <?=$type==='labor'?'selected':''?>>Labor</option>
          </select>
        </div>
        <div class="field">
          <label>From</label>
          <input type="date" name="from" value="<?=htmlspecialchars($fromR)?>">
        </div>
        <div class="field">
          <label>To</label>
          <input type="date" name="to" value="<?=htmlspecialchars($toR)?>">
        </div>
        <div class="field">
          <label>Per page</label>
          <select name="per">
            <?php foreach([10,25,50,100] as $opt): ?>
              <option value="<?=$opt?>" <?=$perPage===$opt?'selected':''?>><?=$opt?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field" style="gap:8px;flex-direction:row;align-items:center;">
          <button class="btn btn-primary" type="submit">Filter</button>
          <a class="btn btn-secondary" href="investments.php">Reset</a>
          <a class="btn btn-secondary" href="?<?=http_build_query(array_merge($_GET,['export'=>'csv','page'=>null]))?>">Export CSV</a>
          <a class="btn btn-secondary" href="?<?=http_build_query(array_merge($_GET,['export'=>'pdf','page'=>null]))?>">PDF Report</a>
        </div>
      </form>

      <div class="meta">
        <div class="item"><strong>Total:</strong> <?=moneyUGX($totals['total_amount'])?></div>
        <div class="item"><strong>Cash:</strong> <?=moneyUGX($totals['total_cash'])?></div>
        <div class="item"><strong>Material:</strong> <?=moneyUGX($totals['total_material'])?></div>
        <div class="item"><strong>Labor:</strong> <?=moneyUGX($totals['total_labor'])?></div>
        <div class="item"><strong>Records:</strong> <?=$total?></div>
      </div>
    </div>

    <div class="card">
      <div style="overflow:auto">
        <table>
          <thead>
            <tr>
              <th style="min-width:150px;">Date & Time</th>
              <th>Investor</th>
              <th>Account</th>
              <th>Type</th>
              <th style="text-align:right;min-width:120px;">Amount</th>
              <th>Receipt</th>
              <th>TXN</th>
              <th style="min-width:220px;">Actions</th>
            </tr>
          </thead>
          <tbody>
          <?php if(!$rows): ?>
            <tr><td colspan="8" style="text-align:center;color:#6b7280;background:transparent;border:none;box-shadow:none">No investments found.</td></tr>
          <?php else: foreach($rows as $r): ?>
            <tr>
              <td><?=htmlspecialchars($r['investment_date'])?></td>
              <td><?=htmlspecialchars($r['first_name'].' '.$r['last_name'])?></td>
              <td><span class="badge"><?=htmlspecialchars($r['account_number'])?></span></td>
              <td><span class="badge"><?=typeIcon($r['investment_type'],14)?> <?=strtoupper(htmlspecialchars($r['investment_type']))?></span></td>
              <td style="text-align:right;"><?=moneyUGX((float)$r['amount'])?></td>
              <td><?=htmlspecialchars($r['receipt_number'])?></td>
              <td><?=htmlspecialchars($r['transaction_id'])?></td>
              <td class="row-actions">
                <!-- Print receipt -->
                 
                <a class="btn btn-compact btn-linklike"
                  href="../print_receipt.php?investment_id=<?= (int)$r['id'] ?>&action=download"
                  target="_blank" rel="noopener">
                  Receipt
                </a>



                <!-- Edit (opens modal) -->
                <button
                  class="btn btn-primary btn-compact edit-btn"
                  type="button"
                  data-id="<?=$r['id']?>"
                  data-date="<?=htmlspecialchars($r['investment_date'])?>"
                  data-type="<?=htmlspecialchars($r['investment_type'])?>"
                  data-amount="<?=htmlspecialchars((string)$r['amount'])?>"
                  data-receipt="<?=htmlspecialchars($r['receipt_number'])?>"
                  data-txn="<?=htmlspecialchars($r['transaction_id'])?>"
                >Edit</button>

                <!-- Delete -->
                <form method="post" onsubmit="return confirm('Delete this investment? This cannot be undone.');">
                  <input type="hidden" name="csrf" value="<?=htmlspecialchars(generateCSRFToken())?>">
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="id" value="<?=$r['id']?>">
                  <button class="btn btn-danger btn-compact" type="submit">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Pagination -->
      <div class="pagination">
        <?php
          $qs=$_GET; unset($qs['page']); $base='?'.http_build_query($qs);
          echo $page>1 ? '<a href="'.$base.'&page='.($page-1).'">« Prev</a>' : '<span>« Prev</span>';
          $window=5; $start=max(1,$page-$window); $end=min($pages,$page+$window);
          for($i=$start;$i<=$end;$i++){
            echo $i===$page ? '<span class="active">'.$i.'</span>' : '<a href="'.$base.'&page='.$i.'">'.$i.'</a>';
          }
          echo $page<$pages ? '<a href="'.$base.'&page='.($page+1).'">Next »</a>' : '<span>Next »</span>';
        ?>
      </div>
    </div>

  </div>
</div>

<!-- EDIT MODAL -->
<div id="editBackdrop" class="modal-backdrop"></div>
<div id="editModal" class="modal" role="dialog" aria-modal="true" aria-labelledby="editTitle">
  <div class="modal-header">
    <h3 id="editTitle" style="margin:0;font-size:1.1rem;">Edit Investment</h3>
    <button class="close-x" type="button" aria-label="Close" onclick="closeEditModal()">×</button>
  </div>
  <form id="editForm" method="post" class="modal-body">
    <input type="hidden" name="csrf" value="<?=htmlspecialchars(generateCSRFToken())?>">
    <input type="hidden" name="action" value="update">
    <input type="hidden" name="id" id="edit_id">

    <div class="grid-2">
      <div>
        <label>Investment Type</label>
        <select name="investment_type" id="edit_type" required>
          <option value="cash">Cash</option>
          <option value="material">Material</option>
          <option value="labor">Labor</option>
        </select>
      </div>
      <div>
        <label>Amount (UGX)</label>
        <input type="number" step="0.01" min="0" name="amount" id="edit_amount" required>
      </div>
      <div>
        <label>Receipt #</label>
        <input name="receipt_number" id="edit_receipt">
      </div>
      <div>
        <label>Transaction #</label>
        <input name="transaction_id" id="edit_txn">
      </div>
      <div>
        <label>Date & Time</label>
        <input type="datetime-local" name="investment_date" id="edit_date" required>
      </div>
    </div>
  </form>
  <div class="modal-actions">
    <button class="btn btn-secondary btn-compact" type="button" onclick="closeEditModal()">Cancel</button>
    <button class="btn btn-primary btn-compact" type="submit" form="editForm">Save Changes</button>
  </div>
</div>

<script>
  // Modal controls
  const modal = document.getElementById('editModal');
  const backdrop = document.getElementById('editBackdrop');

  function openEditModal() {
    modal.style.display='block';
    backdrop.style.display='block';
    document.body.style.overflow='hidden';
  }
  function closeEditModal() {
    modal.style.display='none';
    backdrop.style.display='none';
    document.body.style.overflow='';
  }
  backdrop.addEventListener('click', closeEditModal);
  document.addEventListener('keydown', (e)=>{ if(e.key==='Escape') closeEditModal(); });

  // Attach to Edit buttons
  document.querySelectorAll('.edit-btn').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const id = btn.dataset.id;
      const type = (btn.dataset.type || '').toLowerCase();
      const amount = btn.dataset.amount || '';
      const receipt = btn.dataset.receipt || '';
      const txn = btn.dataset.txn || '';
      const rawDate = btn.dataset.date || ''; // "YYYY-MM-DD HH:MM:SS"

      // Convert "YYYY-MM-DD HH:MM:SS" -> "YYYY-MM-DDTHH:MM"
      let dtLocal = '';
      if (rawDate) {
        const t = rawDate.replace(' ', 'T').slice(0,16);
        dtLocal = t; // browser expects "YYYY-MM-DDTHH:MM"
      }

      document.getElementById('edit_id').value = id;
      document.getElementById('edit_type').value = (['cash','material','labor'].includes(type)?type:'cash');
      document.getElementById('edit_amount').value = amount;
      document.getElementById('edit_receipt').value = receipt;
      document.getElementById('edit_txn').value = txn;
      document.getElementById('edit_date').value = dtLocal;

      openEditModal();
    });
  });
</script>

<?php include 'includes/footer.php'; ?>
