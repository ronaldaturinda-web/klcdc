<?php
// admin/settings.php
declare(strict_types=1);
session_start();

/**
 * Admin Settings
 * - Uses standard admin header/sidebar (includes/header.php & includes/footer.php)
 * - Auto-creates `settings` table (key/value)
 * - Sections: Organization, Branding, Formatting, Receipts
 * - Secure logo upload to /uploads/branding/
 * - CSRF protection + prepared statements
 *
 * Requires: /config/database.php
 */

require_once __DIR__ . '/../config/database.php';

/** Resolve PDO from common patterns */
function resolvePDO(): PDO {
    if (class_exists('Database')) {
        $db = new Database();
        if (method_exists($db, 'connect'))      { $pdo = $db->connect();      if ($pdo instanceof PDO) return $pdo; }
        if (method_exists($db, 'getConnection')){ $pdo = $db->getConnection(); if ($pdo instanceof PDO) return $pdo; }
    }
    if (function_exists('getDbConnection')) { $pdo = getDbConnection(); if ($pdo instanceof PDO) return $pdo; }
    if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) return $GLOBALS['pdo'];
    throw new RuntimeException('Could not obtain a PDO connection from config/database.php');
}

try {
    $pdo = resolvePDO();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    http_response_code(500);
    die('Database connection error: ' . htmlspecialchars($e->getMessage()));
}

/** Bootstrap: create settings table */
$pdo->exec("
CREATE TABLE IF NOT EXISTS settings (
  `key`        VARCHAR(100) PRIMARY KEY,
  `value`      TEXT NOT NULL,
  `updated_by` INT NULL,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

/** Defaults */
$defaults = [
  // Organization
  'org.name'           => 'National Agro Business Support Initiative',
  'org.tagline'        => 'Empowering Agro Investment',
  'org.email'          => 'info@example.com',
  'org.phone'          => '+256 700 000 000',
  'org.address'        => "Kampala, Uganda",
  'org.website'        => 'https://example.com',

  // Branding
  'brand.color_primary'=> '#2c5530',
  'brand.color_secondary'=> '#4a7c59',
  'brand.logo'         => '',  // e.g. uploads/branding/logo.png

  // Formatting
  'format.currency_code'=> 'UGX',
  'format.symbol'       => 'UGX',
  'format.symbol_pos'   => 'prefix', // prefix|suffix
  'format.thousand_sep' => ',',
  'format.decimal_sep'  => '.',
  'format.decimals'     => '0',
  'format.date_format'  => 'Y-m-d',
  'format.timezone'     => 'Africa/Kampala',

  // Receipts
  'receipt.prefix'      => 'RCP',
  'receipt.txn_prefix'  => 'TXN',
  'receipt.qr_enabled'  => '1',
  'receipt.signature_name'  => '',
  'receipt.signature_title' => '',
  'receipt.footer'      => 'Thank you for your investment.',
];

/** Load settings from DB */
function getAllSettings(PDO $pdo, array $defaults): array {
    $rows = $pdo->query("SELECT `key`,`value` FROM settings")->fetchAll();
    $map = $defaults;
    foreach ($rows as $r) { $map[$r['key']] = $r['value']; }
    return $map;
}

/** Save (upsert) settings */
function saveSettings(PDO $pdo, array $pairs, ?int $userId): void {
    $st = $pdo->prepare("
        INSERT INTO settings (`key`,`value`,`updated_by`)
        VALUES (?,?,?)
        ON DUPLICATE KEY UPDATE `value`=VALUES(`value`), `updated_by`=VALUES(`updated_by`)
    ");
    foreach ($pairs as $k => $v) {
        $st->execute([$k, (string)$v, $userId]);
    }
}

/** Helpers */
function h(?string $s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function isValidHexColor(string $c): bool { return (bool)preg_match('/^#([0-9a-fA-F]{6})$/', $c); }
function ensureDir(string $path): void { if (!is_dir($path)) @mkdir($path, 0775, true); }

/** CSRF */
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

$errors = [];
$notice = null;
$updated = false;

$settings = getAllSettings($pdo, $defaults);

/** Handle POST */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid security token. Please reload the page.';
    } else {
        $userId = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;

        // Collect inputs
        $incoming = [
            // Organization
            'org.name'    => trim($_POST['org_name'] ?? ''),
            'org.tagline' => trim($_POST['org_tagline'] ?? ''),
            'org.email'   => trim($_POST['org_email'] ?? ''),
            'org.phone'   => trim($_POST['org_phone'] ?? ''),
            'org.address' => trim($_POST['org_address'] ?? ''),
            'org.website' => trim($_POST['org_website'] ?? ''),

            // Branding
            'brand.color_primary'   => strtoupper(trim($_POST['brand_color_primary'] ?? '')),
            'brand.color_secondary' => strtoupper(trim($_POST['brand_color_secondary'] ?? '')),

            // Formatting
            'format.currency_code' => strtoupper(trim($_POST['currency_code'] ?? 'UGX')),
            'format.symbol'        => trim($_POST['currency_symbol'] ?? 'UGX'),
            'format.symbol_pos'    => in_array($_POST['symbol_pos'] ?? 'prefix', ['prefix','suffix'], true) ? $_POST['symbol_pos'] : 'prefix',
            'format.thousand_sep'  => $_POST['thousand_sep'] ?? ',',
            'format.decimal_sep'   => $_POST['decimal_sep'] ?? '.',
            'format.decimals'      => (string)max(0, min(2, (int)($_POST['decimals'] ?? 0))),
            'format.date_format'   => in_array($_POST['date_format'] ?? 'Y-m-d', ['Y-m-d','d/m/Y','d M Y'], true) ? $_POST['date_format'] : 'Y-m-d',
            'format.timezone'      => trim($_POST['timezone'] ?? 'Africa/Kampala'),

            // Receipts
            'receipt.prefix'         => strtoupper(trim($_POST['receipt_prefix'] ?? 'RCP')),
            'receipt.txn_prefix'     => strtoupper(trim($_POST['txn_prefix'] ?? 'TXN')),
            'receipt.qr_enabled'     => isset($_POST['qr_enabled']) ? '1' : '0',
            'receipt.signature_name' => trim($_POST['signature_name'] ?? ''),
            'receipt.signature_title'=> trim($_POST['signature_title'] ?? ''),
            'receipt.footer'         => trim($_POST['receipt_footer'] ?? ''),
        ];

        // Validate basics
        if ($incoming['org.name'] === '')   $errors[] = 'Organization name is required.';
        if ($incoming['org.email'] !== '' && !filter_var($incoming['org.email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid organization email.';
        if (!isValidHexColor($incoming['brand.color_primary']))   $errors[] = 'Primary color must be a hex like #2C5530.';
        if (!isValidHexColor($incoming['brand.color_secondary'])) $errors[] = 'Secondary color must be a hex like #4A7C59.';
        if ($incoming['format.decimal_sep'] === $incoming['format.thousand_sep']) $errors[] = 'Thousand and decimal separators must be different.';

        // Handle logo upload
        $uploadDir = realpath(__DIR__ . '/../uploads') ?: (__DIR__ . '/../uploads');
        $brandDir  = $uploadDir . '/branding';
        ensureDir($brandDir);

        if (!empty($_FILES['brand_logo']['name'])) {
            $f = $_FILES['brand_logo'];
            if ($f['error'] === UPLOAD_ERR_OK) {
                $tmp = $f['tmp_name'];
                $size = (int)$f['size'];
                if ($size > 2 * 1024 * 1024) {
                    $errors[] = 'Logo is too large (max 2MB).';
                } else {
                    $fi = new finfo(FILEINFO_MIME_TYPE);
                    $mime = $fi->file($tmp) ?: '';
                    $allowed = [
                        'image/png'  => 'png',
                        'image/jpeg' => 'jpg',
                        'image/webp' => 'webp',
                        'image/svg+xml' => 'svg',
                    ];
                    if (!isset($allowed[$mime])) {
                        $errors[] = 'Unsupported logo format. Use PNG, JPG, WEBP or SVG.';
                    } else {
                        $ext = $allowed[$mime];
                        $dest = $brandDir . '/logo.' . $ext;
                        foreach (glob($brandDir . '/logo.*') as $old) { @unlink($old); }
                        if (!move_uploaded_file($tmp, $dest)) {
                            $errors[] = 'Failed to save uploaded logo.';
                        } else {
                            $incoming['brand.logo'] = 'uploads/branding/logo.' . $ext;
                            $notice = 'Logo updated successfully.';
                        }
                    }
                }
            } elseif ($f['error'] !== UPLOAD_ERR_NO_FILE) {
                $errors[] = 'Logo upload error (code ' . (int)$f['error'] . ').';
            }
        } else {
            $incoming['brand.logo'] = $settings['brand.logo'] ?? '';
        }

        if (!$errors) {
            saveSettings($pdo, $incoming, $userId);
            $updated = true;
            $settings = getAllSettings($pdo, $defaults);
            $notice = $notice ? $notice . ' Settings saved.' : 'Settings saved.';
        }
    }
}

$csrf = $_SESSION['csrf_token'] ?? '';
$brandLogo = $settings['brand.logo'] ?? '';
$primary = $settings['brand.color_primary'] ?? $defaults['brand.color_primary'];
$secondary = $settings['brand.color_secondary'] ?? $defaults['brand.color_secondary'];

/** Use the standard admin chrome */
$page_title = 'Settings';
include 'includes/header.php';
?>

<style>
  /* Scope to main-content so global theme stays intact */
  .main-content{
    --brand: <?=h($primary)?>;
    --brand-2: <?=h($secondary)?>;
    --bg:#f6f8f6; --text:#1f2937; --muted:#6b7280;
    --card:#ffffff; --border:#e8edf1; --ring:#d1fae5;
    --shadow:0 12px 32px rgba(0,0,0,.08); --shadow-soft:0 3px 10px rgba(0,0,0,.06);
  }
  .main-content .wrap{max-width:1100px;margin:28px auto;padding:0 16px}
  .main-content .card{background:var(--card);border-radius:16px;box-shadow:var(--shadow);border:1px solid var(--border);padding:18px}
  .main-content .row{display:grid;grid-template-columns:repeat(12,1fr);gap:14px}
  .main-content h1{margin:0;font-size:1.5rem}
  .main-content h2{margin:0 0 10px;font-size:1.1rem}
  .main-content label{display:block;font-size:.9rem;color:var(--muted);margin-bottom:6px}
  .main-content input,.main-content select,.main-content textarea{
    width:100%;padding:12px 14px;border:1px solid var(--border);border-radius:12px;background:#fff;font-size:1rem;outline:none
  }
  .main-content input:focus,.main-content select:focus,.main-content textarea:focus{
    box-shadow:0 0 0 4px var(--ring);border-color:var(--brand-2)
  }
  .main-content textarea{min-height:90px;resize:vertical}
  .main-content .section{margin-bottom:14px}
  .main-content .grid-2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
  .main-content .grid-3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}
  .main-content .actions{display:flex;gap:12px;justify-content:flex-end;margin-top:14px}
  .main-content .btn{appearance:none;border:0;border-radius:12px;padding:12px 16px;font-weight:700;cursor:pointer;box-shadow:var(--shadow-soft);text-decoration:none}
  .main-content .btn-primary{background:var(--brand);color:#fff}
  .main-content .btn-secondary{background:#eef2f7;color:#111827}
  .main-content .alert{padding:12px 14px;border-radius:12px;margin-bottom:12px;border:1px solid var(--border);box-shadow:var(--shadow-soft)}
  .main-content .alert-danger{background:#fff5f5;color:#7f1d1d}
  .main-content .alert-success{background:#eefaf1;color:#14532d}
  .main-content .preview{display:flex;align-items:center;gap:12px;padding:10px;border:1px dashed var(--border);border-radius:12px;background:#fafcfa}
  .main-content .brandbar{height:40px;border-radius:10px;background:linear-gradient(90deg,var(--brand),var(--brand-2));box-shadow:var(--shadow-soft)}
  .main-content .note{font-size:.85rem;color:#6b7280}
  @media (max-width:900px){
    .main-content .grid-3{grid-template-columns:1fr}
    .main-content .grid-2{grid-template-columns:1fr}
  }
</style>

<div class="main-content">
  <div class="wrap">
    <div class="card" style="margin-bottom:12px;">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;">
        <h1>Settings</h1>
        <div style="display:flex;gap:8px;">
          <a class="btn btn-secondary" href="dashboard.php">← Back to Dashboard</a>
        </div>
      </div>

      <?php if ($errors): ?>
        <div class="alert alert-danger">
          <strong>There were problems:</strong>
          <ul><?php foreach($errors as $e) echo '<li>'.h($e).'</li>'; ?></ul>
        </div>
      <?php elseif ($updated || $notice): ?>
        <div class="alert alert-success"><?=h($notice ?? 'Settings saved.')?></div>
      <?php endif; ?>

      <form method="post" enctype="multipart/form-data" novalidate>
        <input type="hidden" name="csrf_token" value="<?=h($csrf)?>">

        <!-- Organization -->
        <div class="section card">
          <h2>Organization</h2>
          <div class="grid-2">
            <div>
              <label>Organization Name</label>
              <input name="org_name" value="<?=h($settings['org.name'])?>" required>
            </div>
            <div>
              <label>Tagline</label>
              <input name="org_tagline" value="<?=h($settings['org.tagline'])?>">
            </div>
            <div>
              <label>Email</label>
              <input type="email" name="org_email" value="<?=h($settings['org.email'])?>">
            </div>
            <div>
              <label>Phone</label>
              <input name="org_phone" value="<?=h($settings['org.phone'])?>">
            </div>
            <div>
              <label>Website</label>
              <input name="org_website" value="<?=h($settings['org.website'])?>">
            </div>
            <div>
              <label>Address</label>
              <textarea name="org_address"><?=h($settings['org.address'])?></textarea>
            </div>
          </div>
        </div>

        <!-- Branding -->
        <div class="section card">
          <h2>Branding</h2>
          <div class="grid-3">
            <div>
              <label>Primary Color</label>
              <input name="brand_color_primary" value="<?=h($settings['brand.color_primary'])?>" placeholder="#2C5530" required>
            </div>
            <div>
              <label>Secondary Color</label>
              <input name="brand_color_secondary" value="<?=h($settings['brand.color_secondary'])?>" placeholder="#4A7C59" required>
            </div>
            <div>
              <label>Logo (PNG/JPG/WEBP/SVG, max 2MB)</label>
              <input type="file" name="brand_logo" accept=".png,.jpg,.jpeg,.webp,.svg">
            </div>
          </div>

          <div class="grid-2" style="margin-top:12px;">
            <div>
              <label>Current Logo</label>
              <div class="preview">
                <?php if ($brandLogo): ?>
                  <img src="<?=h('../' . $brandLogo)?>" alt="Logo" style="max-height:60px">
                  <span class="note"><?=h($brandLogo)?></span>
                <?php else: ?>
                  <span class="note">No logo uploaded yet.</span>
                <?php endif; ?>
              </div>
            </div>
            <div>
              <label>Brand Header Preview</label>
              <div class="brandbar"></div>
              <div class="note" style="margin-top:6px;">This gradient uses your primary and secondary colors.</div>
            </div>
          </div>
        </div>

        <!-- Formatting -->
        <div class="section card">
          <h2>Formatting</h2>
          <div class="grid-3">
            <div>
              <label>Currency Code</label>
              <input name="currency_code" value="<?=h($settings['format.currency_code'])?>" placeholder="UGX">
            </div>
            <div>
              <label>Currency Symbol</label>
              <input name="currency_symbol" value="<?=h($settings['format.symbol'])?>" placeholder="UGX">
            </div>
            <div>
              <label>Symbol Position</label>
              <select name="symbol_pos">
                <option value="prefix" <?=($settings['format.symbol_pos']==='prefix'?'selected':'')?>>Prefix (UGX 10,000)</option>
                <option value="suffix" <?=($settings['format.symbol_pos']==='suffix'?'selected':'')?>>Suffix (10,000 UGX)</option>
              </select>
            </div>
            <div>
              <label>Thousand Separator</label>
              <select name="thousand_sep">
                <option value="," <?=($settings['format.thousand_sep']===','?'selected':'')?>>, (comma)</option>
                <option value="." <?=($settings['format.thousand_sep']==='.'?'selected':'')?>>. (dot)</option>
                <option value=" " <?=($settings['format.thousand_sep']===' '?'selected':'')?>>(space)</option>
              </select>
            </div>
            <div>
              <label>Decimal Separator</label>
              <select name="decimal_sep">
                <option value="." <?=($settings['format.decimal_sep']==='.'?'selected':'')?>>. (dot)</option>
                <option value="," <?=($settings['format.decimal_sep']===','?'selected':'')?>>, (comma)</option>
              </select>
            </div>
            <div>
              <label>Decimals</label>
              <select name="decimals">
                <?php foreach ([0,1,2] as $d): ?>
                <option value="<?=$d?>" <?=((int)$settings['format.decimals']===$d?'selected':'')?>><?=$d?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div>
              <label>Date Format</label>
              <select name="date_format">
                <?php
                  $opts = ['Y-m-d'=>'2025-08-13','d/m/Y'=>'13/08/2025','d M Y'=>'13 Aug 2025'];
                  foreach ($opts as $fmt => $example):
                ?>
                  <option value="<?=$fmt?>" <?=($settings['format.date_format']===$fmt?'selected':'')?>><?=$fmt?> (<?=$example?>)</option>
                <?php endforeach; ?>
              </select>
            </div>
            <div>
              <label>Timezone</label>
              <input name="timezone" value="<?=h($settings['format.timezone'])?>" placeholder="Africa/Kampala">
            </div>
          </div>
        </div>

        <!-- Receipts -->
        <div class="section card">
          <h2>Receipts</h2>
          <div class="grid-3">
            <div>
              <label>Receipt Prefix</label>
              <input name="receipt_prefix" value="<?=h($settings['receipt.prefix'])?>" placeholder="RCP">
            </div>
            <div>
              <label>Transaction Prefix</label>
              <input name="txn_prefix" value="<?=h($settings['receipt.txn_prefix'])?>" placeholder="TXN">
            </div>
            <div>
              <label>QR Code on Receipts</label>
              <div style="display:flex;align-items:center;gap:8px;">
                <input type="checkbox" name="qr_enabled" value="1" <?=($settings['receipt.qr_enabled']==='1'?'checked':'')?>>
                <span class="note">Include QR (receipt & txn info)</span>
              </div>
            </div>
            <div>
              <label>Signature Name</label>
              <input name="signature_name" value="<?=h($settings['receipt.signature_name'])?>">
            </div>
            <div>
              <label>Signature Title</label>
              <input name="signature_title" value="<?=h($settings['receipt.signature_title'])?>">
            </div>
            <div>
              <label>Footer Text</label>
              <textarea name="receipt_footer"><?=h($settings['receipt.footer'])?></textarea>
            </div>
          </div>
        </div>

        <div class="actions">
          <a class="btn btn-secondary" href="dashboard.php">Cancel</a>
          <button class="btn btn-primary" type="submit">Save Settings</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
