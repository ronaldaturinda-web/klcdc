<?php
// admin/investor_details.php
declare(strict_types=1);

require_once '../config/config.php';
require_once '../classes/Auth.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect('../index.php');
}

$auth = new Auth();
if (!$auth->validateSession()) {
    redirect('../index.php');
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    redirect('investors.php');
}

/** Try to use PDO from config */
/** Resolve a PDO from common patterns in your config */
function resolvePDO(): PDO {
    // 1) Global variables
    if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) return $GLOBALS['pdo'];
    if (isset($GLOBALS['conn']) && $GLOBALS['conn'] instanceof PDO) return $GLOBALS['conn'];
    if (isset($GLOBALS['db'])  && $GLOBALS['db']  instanceof PDO) return $GLOBALS['db'];

    // 2) Helper functions
    if (function_exists('getDbConnection')) { $p = getDbConnection(); if ($p instanceof PDO) return $p; }
    if (function_exists('getPDO'))          { $p = getPDO();          if ($p instanceof PDO) return $p; }
    if (function_exists('db'))              { $p = db();              if ($p instanceof PDO) return $p; }

    // 3) Database class (connect/getConnection)
    if (class_exists('Database')) {
        $db = new Database();
        if (method_exists($db,'connect'))       { $p = $db->connect();       if ($p instanceof PDO) return $p; }
        if (method_exists($db,'getConnection')) { $p = $db->getConnection(); if ($p instanceof PDO) return $p; }
    }

    throw new RuntimeException('Database connection not available.');
}

try {
    $pdo = resolvePDO();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    http_response_code(500);
    exit('Database connection not available.');
}


/** Fetch investor + user email */
$st = $pdo->prepare("
    SELECT i.*, u.email, u.username
    FROM investors i
    JOIN users u ON u.id = i.user_id
    WHERE i.id = ?
    LIMIT 1
");
$st->execute([$id]);
$inv = $st->fetch(PDO::FETCH_ASSOC);
if (!$inv) {
    redirect('investors.php');
}

/** Totals and recent investments */
$sum = $pdo->prepare("SELECT COUNT(*) AS tx_count, COALESCE(SUM(amount),0) AS total_amount FROM investments WHERE investor_id = ?");
$sum->execute([$id]);
$agg = $sum->fetch(PDO::FETCH_ASSOC);

// Replace your existing recent-transactions query with THIS:

/** Quick helper to check if a column exists (uses SHOW COLUMNS for portability) */
function hasCol(PDO $pdo, string $table, string $col): bool {
    $st = $pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?");
    $st->execute([$col]);
    return (bool)$st->fetch();
}

$table = 'investments';

// Detect optional columns safely
$hasTxn  = hasCol($pdo, $table, 'txn_code');

$colType = null;
foreach (['investment_type','type','category'] as $c) {
    if (hasCol($pdo, $table, $c)) { $colType = $c; break; }
}

$colDate = null;
foreach (['created_at','investment_date','date','created_on','timestamp'] as $c) {
    if (hasCol($pdo, $table, $c)) { $colDate = $c; break; }
}

// Build a SELECT that always returns: id, amount, investment_type, created_at, txn_code
$fields = "id, amount";
$fields .= $colType ? ", `$colType` AS investment_type" : ", 'cash' AS investment_type";
$fields .= $colDate ? ", `$colDate` AS created_at"       : ", NOW() AS created_at";
$fields .= $hasTxn  ? ", txn_code"                       : ", CONCAT('TXN-', LPAD(id,6,'0')) AS txn_code";

$sqlRecent = "SELECT $fields
              FROM `$table`
              WHERE investor_id = ?
              ORDER BY id DESC
              LIMIT 10";

$recent = $pdo->prepare($sqlRecent);
$recent->execute([$id]);
$recentRows = $recent->fetchAll(PDO::FETCH_ASSOC);


$page_title = 'Investor Details';
include 'includes/header.php';
?>
<div class="main-content">
  <div class="page-header">
    <h1><i class="fas fa-id-card"></i> Investor Details</h1>
    <p class="text-muted">Profile and recent investments</p>
  </div>

  <div class="card">
    <div class="card-body">
      <div class="d-flex justify-content-between align-items-start flex-wrap gap-3">
        <div>
          <h3 class="mb-1">
            <?php echo htmlspecialchars($inv['first_name'] . ' ' . $inv['last_name']); ?>
            <small class="text-muted">(@<?php echo htmlspecialchars($inv['username']); ?>)</small>
          </h3>
          <div class="text-muted">
            <i class="fas fa-hashtag"></i>
            <strong><?php echo htmlspecialchars($inv['account_number']); ?></strong>
          </div>
          <div class="mt-2">
            <i class="fas fa-envelope"></i>
            <a href="mailto:<?php echo htmlspecialchars($inv['email']); ?>"><?php echo htmlspecialchars($inv['email']); ?></a>
            &nbsp;&nbsp;
            <i class="fas fa-phone"></i>
            <?php echo htmlspecialchars($inv['phone']); ?>
          </div>
          <div class="text-muted mt-1">
            <i class="fas fa-map-marker-alt"></i>
            <?php echo htmlspecialchars($inv['city'] . ', ' . $inv['state'] . ' • ' . $inv['country']); ?>
          </div>
          <div class="text-muted mt-1">
            <i class="fas fa-calendar"></i>
            Joined: <?php echo formatDate($inv['date_joined'], 'd M Y'); ?>
          </div>
        </div>

        <div class="text-end">
          <a href="add_investment.php?investor_id=<?php echo $inv['id']; ?>" class="btn btn-primary">
            <i class="fas fa-plus-circle"></i> Record Investment
          </a>
          <a href="investments.php?investor_id=<?php echo $inv['id']; ?>" class="btn btn-info">
            <i class="fas fa-list"></i> View All Transactions
          </a>
          <a href="edit_investor.php?id=<?php echo $inv['id']; ?>" class="btn btn-warning">
            <i class="fas fa-edit"></i> Edit Profile
          </a>
          <a href="investors.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back
          </a>
        </div>
      </div>

      <hr>

      <div class="row">
        <div class="col-md-3">
          <div class="stat-card success">
            <div class="stat-number"><?php echo number_format((int)($agg['tx_count'] ?? 0)); ?></div>
            <div class="stat-label">Total Investments</div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="stat-card">
            <div class="stat-number"><?php echo formatCurrency((float)($agg['total_amount'] ?? 0)); ?></div>
            <div class="stat-label">Total Amount</div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="stat-card <?php echo $inv['status']==='active'?'success':($inv['status']==='inactive'?'warning':'danger'); ?>">
            <div class="stat-number"><?php echo ucfirst($inv['status']); ?></div>
            <div class="stat-label">Status</div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="stat-card">
            <div class="stat-number"><?php echo htmlspecialchars($inv['city']); ?></div>
            <div class="stat-label">City</div>
          </div>
        </div>
      </div>

      <h4 class="mt-4 mb-2"><i class="fas fa-history"></i> Recent Transactions</h4>
      <?php if ($recentRows): ?>
        <div class="table-responsive">
          <table class="table data-table">
            <thead>
              <tr>
                <th>Txn Code</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Date</th>
                <th>Receipt</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($recentRows as $r): ?>
                <tr>
                  <td><?php echo htmlspecialchars($r['txn_code']); ?></td>
                  <td><span class="badge badge-info"><?php echo htmlspecialchars(ucfirst($r['investment_type'])); ?></span></td>
                  <td><strong><?php echo formatCurrency((float)$r['amount']); ?></strong></td>
                  <td><?php echo formatDate($r['created_at'], 'd M Y H:i'); ?></td>
                  <td>
                    <a class="btn btn-sm btn-outline-primary" href="print_receipt.php?id=<?php echo (int)$r['id']; ?>">
                      <i class="fas fa-print"></i> Print
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <div class="text-muted">No recent transactions.</div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
