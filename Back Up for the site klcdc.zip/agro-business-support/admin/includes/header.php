<?php
// admin/includes/header.php
if (session_status() === PHP_SESSION_NONE) session_start();

/** Robustly include config so helpers/constants exist */
$tried = [];
$paths = [
    __DIR__ . '/../../config/config.php', // typical from admin/includes/
    __DIR__ . '/../config/config.php',    // fallback
    __DIR__ . '/config.php',              // last resort
];
foreach ($paths as $p) {
    if (is_readable($p)) { require_once $p; break; }
    $tried[] = $p;
}
if (!function_exists('isLoggedIn') || !function_exists('isAdmin')) {
    // Fail clearly instead of fatal later
    header('Content-Type: text/plain; charset=utf-8');
    echo "Config not loaded (tried:\n- " . implode("\n- ", $tried) . ")\n\n".
         "Ensure config.php is readable and defines isLoggedIn()/isAdmin().";
    exit;
}

if (!isset($page_title)) $page_title = 'Dashboard';

/** Gate: only admins */
if (!isLoggedIn() || !isAdmin()) {
    redirect('../index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?> - <?= defined('APP_NAME') ? APP_NAME : 'Admin' ?></title>

    <!-- Your global theme -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Font Awesome (existing dependency) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="icon" type="image/x-icon" href="../assets/images/favicon.ico">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">


    <style>
        /* ====== existing utility grid from your file ====== */
        .row { display:flex; flex-wrap:wrap; margin:-0.75rem; }
        .col-md-3, .col-md-4, .col-md-6, .col-md-8, .col-md-12 { padding:0.75rem; }
        .col-md-3 { flex:0 0 25%; max-width:25%; }
        .col-md-4 { flex:0 0 33.333333%; max-width:33.333333%; }
        .col-md-6 { flex:0 0 50%; max-width:50%; }
        .col-md-8 { flex:0 0 66.666667%; max-width:66.666667%; }
        .col-md-12{ flex:0 0 100%; max-width:100%; }

        @media (max-width: 768px) {
            .col-md-3, .col-md-4, .col-md-6, .col-md-8 { flex:0 0 100%; max-width:100%; }
        }

        .page-header { margin-bottom:2rem; padding-bottom:1rem; border-bottom:1px solid var(--border-color); }
        .page-header h1 { margin-bottom:0.5rem; color:var(--primary-color); }

        /* ====== Mobile header (kept, no icon) ====== */
        .mobile-header {
            display:none; background-color:var(--primary-color); color:#fff;
            padding:1rem; position:fixed; top:0; left:0; right:0; z-index:1001;
        }
        .mobile-header .navbar-brand { font-size:1.1rem; font-weight:700; letter-spacing:.3px; }
        .mobile-header .sidebar-toggle { background:none; border:none; color:#fff; font-size:1.25rem; cursor:pointer; }
        .sidebar-overlay { display:none; position:fixed; inset:0; background-color:rgba(0,0,0,.5); z-index:999; }

        @media (max-width: 768px) {
            .mobile-header { display:flex; justify-content:space-between; align-items:center; }
            .main-content { padding-top:4rem; }
        }

        /* ====== NEW: Full-width brand block in sidebar header ====== */
        .sidebar .sidebar-header {
            padding:16px 18px;
            border-bottom:1px solid var(--border-color);
        }
        .sidebar .brand-block { display:block; width:100%; }
        .sidebar .brand-title {
            font-weight:800; font-size:26px; line-height:1.15; letter-spacing:.5px;
            color:#1f2937; word-break:break-word;
        }
        .sidebar .brand-sub {
            margin-top:4px; font-weight:600; font-size:13px; line-height:1.25; letter-spacing:.2px;
            color:#374151; white-space:normal; word-break:break-word;
        }
        .sidebar .brand-meta {
            margin-top:6px; font-weight:600; font-size:12px; letter-spacing:.2px; color:#4b5563;
        }
        @media (max-width: 768px) {
            .sidebar .brand-title { font-size:22px; }
            .sidebar .brand-sub   { font-size:12px; }
            .sidebar .brand-meta  { font-size:11px; }
        }

        /* Off-white brand text in the sidebar header */
.sidebar .brand-title,
.sidebar .brand-sub,
.sidebar .brand-meta {
  color: #f9fafb;   /* soft off-white */
}
.sidebar .brand-meta { color: rgba(155, 155, 155, 0.88); }

/* === Make the sidebar itself scrollable === */
.sidebar{
  position: fixed;          /* keeps it pinned */
  top: 0;
  left: 0;
  bottom: 0;
  width: 260px;             /* whatever your current width is */
  height: 100vh;            /* full viewport height */
  overflow-y: auto;         /* <<< SCROLLS! */
  -webkit-overflow-scrolling: touch; /* smooth on iOS */
  overscroll-behavior: contain;
  z-index: 1000;            /* sits above content */
}

/* Keep header/footer visible but allow the menu list to scroll independently if you prefer */
.sidebar .sidebar-header{
  position: sticky; top: 0; z-index: 1;
}
.sidebar .sidebar-footer{
  position: sticky; bottom: 0; z-index: 1; background: inherit;
}

/* If you want ONLY the list to scroll (optional):
   uncomment and the header/footer stay pinned while the list scrolls
*/
/*
.sidebar{
  overflow: hidden;
}
.sidebar .sidebar-menu{
  max-height: calc(100vh - 160px);  /* adjust 160px if your header/footer are taller */
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}
*/

/* Off-canvas behavior you already use; ensure mobile transform doesn’t block scrolling */
@media (max-width: 768px){
  .sidebar{
    transform: translateX(-100%);
    transition: transform .25s ease;
  }
  .sidebar.active{
    transform: translateX(0); /* script.js toggles this */
  }

  /* when the sidebar is open, allow page behind to stay put */
  body.sidebar-open{
    overflow: hidden;
    touch-action: none;
  }
}


    </style>
</head>
<body>
    <!-- Mobile Header (kept; no icon) -->
<div class="mobile-header">
  <div class="navbar-brand">
    NABSI
  </div>
  <button class="sidebar-toggle" id="sidebarToggle">
    <i class="fas fa-bars"></i>
  </button>
</div>

    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <!-- No icon; full-width text block -->
            <div class="brand-block">
                <div class="brand-title">KLCDC</div>
                <div class="brand-sub">Kaliro Lord's Community Development Corporation</div>
                <div class="brand-meta">ADMIN PANEL</div>
            </div>
        </div>

        <ul class="sidebar-menu">
            <li>
                <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : '' ?>">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </li>
            <li>
                <a href="investors.php" class="<?= basename($_SERVER['PHP_SELF']) === 'investors.php' ? 'active' : '' ?>">
                    <i class="fas fa-users"></i> Investors
                </a>
            </li>
            <li>
                <a href="add_investor.php" class="<?= basename($_SERVER['PHP_SELF']) === 'add_investor.php' ? 'active' : '' ?>">
                    <i class="fas fa-user-plus"></i> Add Investor
                </a>
            </li>
            <li>
                <a href="investments.php" class="<?= basename($_SERVER['PHP_SELF']) === 'investments.php' ? 'active' : '' ?>">
                    <i class="fas fa-money-bill-wave"></i> Investments
                </a>
            </li>
            <li>
                <a href="add_investment.php" class="<?= basename($_SERVER['PHP_SELF']) === 'add_investment.php' ? 'active' : '' ?>">
                    <i class="fas fa-plus-circle"></i> Record Investment
                </a>
            </li>
            <li>
                <a href="reports.php" class="<?= basename($_SERVER['PHP_SELF']) === 'reports.php' ? 'active' : '' ?>">
                    <i class="fas fa-chart-line"></i> Reports
                </a>
            </li>
            <li>
                <a href="users.php" class="<?= basename($_SERVER['PHP_SELF']) === 'users.php' ? 'active' : '' ?>">
                    <i class="fas fa-users-cog"></i> User Management
                </a>
            </li>
            <li>
                <a href="settings.php" class="<?= basename($_SERVER['PHP_SELF']) === 'settings.php' ? 'active' : '' ?>">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </li>
            <li>
                <a href="../investor/dashboard.php">
                    <i class="fas fa-exchange-alt"></i> Investor View
                </a>
            </li>
            <li>
                <a href="logout.php" data-confirm="Are you sure you want to logout?">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </li>
        </ul>

        <div class="sidebar-footer" style="padding:1rem; text-align:center; color:#6c757d; font-size:.875rem; margin-top:auto;">
            <p>Logged in as:<br><strong><?= htmlspecialchars($_SESSION['username'] ?? '') ?></strong></p>
            <p>&copy; <?= date('Y') ?> AgriSupport</p>
        </div>
    </div>

    <!-- Alert Container -->
    <div id="alertContainer"></div>

    <!-- Your existing sidebar/menu JS -->
    <script src="../assets/js/script.js"></script>
