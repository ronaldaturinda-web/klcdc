<?php
/**
 * Drop-in Admin Sidebar
 * - Include this on pages that don't already have a sidebar.
 * - No functionality changed; purely UI + links.
 * - Uses your existing auth helpers if available.
 */

if (!defined('APP_NAME')) {
  // If config not already loaded on this page, try to load it.
  $cfg = __DIR__ . '/../config.php';
  if (is_readable($cfg)) require_once $cfg;
}

$current = basename($_SERVER['PHP_SELF'] ?? '');
$makeActive = function(string $file) use ($current) {
  return $current === $file ? ' is-active' : '';
};

// Menu items (adjust or reorder if you like)
$items = [
  ['dashboard.php',       'fas fa-tachometer-alt', 'Dashboard'],
  ['investors.php',       'fas fa-users',          'Investors'],
  ['add_investor.php',    'fas fa-user-plus',      'Add Investor'],
  ['add_investment.php',  'fas fa-coins',          'Record Investment'],
  ['investments.php',     'fas fa-list',           'Transactions'],
  ['reports.php',         'fas fa-chart-bar',      'Reports'],
  ['users.php',           'fas fa-user-cog',       'Users'],
  ['settings.php',        'fas fa-cog',            'Settings'],
  ['logout.php',          'fas fa-sign-out-alt',   'Logout'],
];
?>
<style>
/* --- Drop-in Sidebar (scoped classes to avoid collisions) --- */
.app-aside{ position:fixed; inset:0 auto 0 0; width:240px; background:#ffffff;
  border-right:1px solid #e8edf1; box-shadow:0 12px 32px rgba(0,0,0,.08);
  z-index:1000; transform:translateX(0); transition:transform .25s ease; }
.app-aside__brand{ display:flex; align-items:center; gap:.5rem; padding:14px 14px; border-bottom:1px solid #eef2f7; }
.app-aside__dot{ width:10px; height:10px; border-radius:50%; background:#2c5530; box-shadow:0 0 0 4px rgba(44,85,48,.15); }
.app-aside__title{ font-weight:700; color:#2c5530; }
.app-aside__nav{ padding:8px; }
.app-aside__link{ display:flex; align-items:center; gap:.75rem; padding:10px 12px; border-radius:10px; color:#1f2937; text-decoration:none; }
.app-aside__link:hover{ background:#f3f6f4; }
.app-aside__link i{ width:18px; text-align:center; color:#4a7c59; }
.app-aside__link.is-active{ background:#eef5ef; border:1px solid #dce9de; }
.app-aside__footer{ margin-top:auto; padding:10px 12px; color:#6b7280; font-size:.85rem; border-top:1px solid #eef2f7; }

.app-aside__toggle{ position:fixed; left:12px; top:12px; z-index:1100;
  background:#2c5530; color:#fff; border:0; border-radius:10px; padding:8px 10px; cursor:pointer;
  box-shadow:0 6px 18px rgba(0,0,0,.18); }
.app-aside__toggle i{ pointer-events:none; }

html.app-has-aside body{ padding-left:260px; } /* give space so content isn't hidden */
@media (max-width: 992px){
  .app-aside{ transform:translateX(-100%); }
  html.app-aside-open .app-aside{ transform:translateX(0); }
  html.app-has-aside body{ padding-left:0; }
}
</style>

<!-- Toggle button (mobile) -->
<button type="button" class="app-aside__toggle" aria-label="Menu" onclick="
  const h=document.documentElement;
  h.classList.toggle('app-aside-open');
" title="Menu">
  <i class="fas fa-bars"></i>
</button>

<!-- Sidebar -->
<aside class="app-aside" role="navigation" aria-label="Sidebar">
  <div class="app-aside__brand">
    <span class="app-aside__dot"></span>
    <div class="app-aside__title">NABSI</div>
  </div>
  <nav class="app-aside__nav">
    <?php foreach ($items as [$href,$icon,$label]): ?>
      <a class="app-aside__link<?php echo $makeActive($href); ?>" href="<?php echo htmlspecialchars($href); ?>">
        <i class="<?php echo htmlspecialchars($icon); ?>"></i>
        <span><?php echo htmlspecialchars($label); ?></span>
      </a>
    <?php endforeach; ?>
  </nav>
  <div class="app-aside__footer">
    <div><?php echo defined('APP_NAME') ? APP_NAME : 'National Agro Business Support Initiative'; ?></div>
    <div style="font-size:.8rem;">© <?php echo date('Y'); ?></div>
  </div>
</aside>

<script>
// mark that this page has the aside (adds body padding on desktop)
document.documentElement.classList.add('app-has-aside');
// close on ESC (mobile)
document.addEventListener('keydown', e => {
  if(e.key==='Escape') document.documentElement.classList.remove('app-aside-open');
});
// close when clicking outside (mobile)
document.addEventListener('click', e => {
  if (!document.documentElement.classList.contains('app-aside-open')) return;
  const aside = document.querySelector('.app-aside');
  const toggle = document.querySelector('.app-aside__toggle');
  if (!aside.contains(e.target) && e.target !== toggle) {
    document.documentElement.classList.remove('app-aside-open');
  }
});
</script>
