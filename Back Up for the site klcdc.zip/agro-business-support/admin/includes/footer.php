<?php
/**
 * Admin Footer Include
 * National Agro Business Support Initiative
 */
?>

    <!-- Footer -->
    <footer style="margin-left: 250px; padding: 1rem 2rem; background-color: var(--light-color); border-top: 1px solid var(--border-color); margin-top: 2rem;">
        <div class="d-flex justify-content-between align-items-center">
            <p class="mb-0 text-muted">
                &copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?>. All rights reserved.
            </p>
            <p class="mb-0 text-muted">
                Version <?php echo APP_VERSION; ?> |
                <a href="mailto:<?php echo COMPANY_EMAIL; ?>">Support</a>
            </p>
        </div>
    </footer>

    <style>
        @media (max-width: 768px) {
            footer {
                margin-left: 0 !important;
                padding: 1rem !important;
            }

            footer .d-flex {
                flex-direction: column;
                text-align: center;
                gap: 0.5rem;
            }
        }
    </style>

</body>
</html>
