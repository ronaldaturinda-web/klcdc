<?php
// admin/users.php
declare(strict_types=1);
session_start();

/**
 * Users Management (Admin)
 * - Uses standard admin chrome (includes/header.php + includes/footer.php)
 * - Add Admin/Staff users (Investors should be created via Add Investor page)
 * - Edit user fields: username, email, role, status
 * - Toggle status (activate/deactivate)
 * - Reset password (shows once)
 * - Search, filter by role/status, pagination
 * - Export CSV / PDF (TCPDF)
 */

require_once __DIR__ . '/../config/config.php'; // brings database + helpers
require_once __DIR__ . '/../classes/Auth.php';

/* ---- Auth ---- */
if (!isLoggedIn() || !isAdmin()) {
    redirect('../index.php');
}
$auth = new Auth();
if (!$auth->validateSession()) {
    redirect('../index.php');
}

/* ---- PDO resolver ---- */
function resolvePDO(): PDO {
    if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) return $GLOBALS['pdo'];
    if (function_exists('getDbConnection')) { $p = getDbConnection(); if ($p instanceof PDO) return $p; }
    if (class_exists('Database')) {
        $db = new Database();
        if (method_exists($db, 'connect'))      { $p = $db->connect();      if ($p instanceof PDO) return $p; }
        if (method_exists($db, 'getConnection')){ $p = $db->getConnection(); if ($p instanceof PDO) return $p; }
    }
    throw new RuntimeException('Could not obtain a PDO connection from config/database.php');
}
try {
    $pdo = resolvePDO();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    http_response_code(500);
    die('Database connection error: ' . htmlspecialchars($e->getMessage()));
}

/* ---- TCPDF loader (for PDF export) ---- */
function tryIncludeTCPDF(): bool {
    $candidates = [
        __DIR__ . '/../vendor/tcpdf/tcpdf.php',
        __DIR__ . '/../tcpdf_min/tcpdf.php',
        __DIR__ . '/../tcpdf.php',
    ];
    foreach ($candidates as $p) {
        if (is_readable($p)) {
            if (!defined('K_PATH_CACHE')) {
                $cache = realpath(__DIR__ . '/../temp');
                if (!$cache) { @mkdir(__DIR__ . '/../temp', 0775, true); $cache = __DIR__ . '/../temp'; }
                define('K_PATH_CACHE', rtrim($cache, '/\\') . DIRECTORY_SEPARATOR);
            }
            require_once $p;
            return true;
        }
    }
    return false;
}

/* ---- Helpers ---- */
function h(?string $s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function randomPassword(int $len = 10): string {
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%';
    $pw = ''; for ($i=0; $i<$len; $i++) $pw .= $alphabet[random_int(0, strlen($alphabet)-1)]; return $pw;
}
function validRole(string $r): bool { return in_array($r, ['admin','staff','investor'], true); }
function validStatus(string $s): bool { return in_array($s, ['active','inactive'], true); }

/* ---- CSRF (use project helper if available) ---- */
$csrf = function_exists('generateCSRFToken') ? generateCSRFToken() : ($_SESSION['csrf_token'] ??= bin2hex(random_bytes(32)));

/* ---- Filters ---- */
$q      = trim($_GET['q']     ?? '');
$role   = trim($_GET['role']  ?? '');
$status = trim($_GET['status']?? '');
$per    = max(10, (int)($_GET['per'] ?? 25));
$page   = max(1,  (int)($_GET['page'] ?? 1));

/* ---- WHERE builder ---- */
function buildWhere(array $filters, array &$params): string {
    $w = [];
    if ($filters['q'] !== '') {
        $w[] = "(u.username LIKE :q OR u.email LIKE :q OR i.account_number LIKE :q OR i.first_name LIKE :q OR i.last_name LIKE :q)";
        $params[':q'] = '%'.$filters['q'].'%';
    }
    if ($filters['role'] !== '' && in_array($filters['role'], ['admin','staff','investor'], true)) {
        $w[] = "u.role = :r"; $params[':r'] = $filters['role'];
    }
    if ($filters['status'] !== '' && in_array($filters['status'], ['active','inactive'], true)) {
        $w[] = "u.status = :s"; $params[':s'] = $filters['status'];
    }
    return $w ? ('WHERE ' . implode(' AND ', $w)) : '';
}

/* ---- Data access ---- */
function countUsers(PDO $pdo, array $filters): int {
    $params=[]; $where=buildWhere($filters,$params);
    $sql="SELECT COUNT(*) AS c FROM users u LEFT JOIN investors i ON i.user_id = u.id $where";
    $st=$pdo->prepare($sql); $st->execute($params); $row=$st->fetch();
    return (int)($row['c'] ?? 0);
}
function fetchUsers(PDO $pdo, array $filters, int $limit, int $offset): array {
    $params=[]; $where=buildWhere($filters,$params);
    $sql="SELECT u.id, u.username, u.email, u.role, u.status,
                 i.account_number, i.first_name, i.last_name
          FROM users u
          LEFT JOIN investors i ON i.user_id = u.id
          $where
          ORDER BY u.role='admin' DESC, u.id DESC
          LIMIT $limit OFFSET $offset";
    $st=$pdo->prepare($sql); $st->execute($params); return $st->fetchAll();
}

/* ---- Exports ---- */
function exportCSV(PDO $pdo, array $filters): void {
    $params=[]; $where=buildWhere($filters,$params);
    $sql="SELECT u.username, u.email, u.role, u.status,
                 i.account_number, CONCAT(i.first_name,' ',i.last_name) AS investor
          FROM users u
          LEFT JOIN investors i ON i.user_id = u.id
          $where
          ORDER BY u.id DESC";
    $st=$pdo->prepare($sql); $st->execute($params); $rows=$st->fetchAll();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=users_export.csv');
    $out=fopen('php://output','w');
    fputcsv($out,['Username','Email','Role','Status','Account','Investor Name']);
    foreach ($rows as $r) {
        fputcsv($out, [$r['username'],$r['email'],strtoupper($r['role']),ucfirst($r['status']),$r['account_number'],$r['investor']]);
    }
    fclose($out); exit;
}
function exportPDF(PDO $pdo, array $filters): void {
    if (!tryIncludeTCPDF()) { header('Content-Type: text/plain'); echo 'TCPDF not found.'; exit; }
    while (ob_get_level()) { ob_end_clean(); }
    $params=[]; $where=buildWhere($filters,$params);
    $sql="SELECT u.username, u.email, u.role, u.status,
                 i.account_number, CONCAT(i.first_name,' ',i.last_name) AS investor
          FROM users u
          LEFT JOIN investors i ON i.user_id = u.id
          $where
          ORDER BY u.id DESC";
    $st=$pdo->prepare($sql); $st->execute($params); $rows=$st->fetchAll();

    $pdf=new TCPDF('P','mm','A4',true,'UTF-8',false);
    $pdf->SetTitle('Users Report'); $pdf->SetMargins(12,12,12); $pdf->AddPage();
    $pdf->SetFillColor(44,85,48); $pdf->Rect(12,12,186,14,'F');
    $pdf->SetTextColor(255,255,255); $pdf->SetFont('helvetica','B',13);
    $pdf->SetXY(16,14); $pdf->Write(8,'National Agro Business Support Initiative — Users Report');
    $pdf->Ln(18); $pdf->SetTextColor(0,0,0); $pdf->SetFont('helvetica','',11);

    $fQ=h($filters['q']); $fR=h($filters['role'] ?: 'All'); $fS=h($filters['status'] ?: 'All');
    $pdf->writeHTML("<table cellpadding='4' style='font-size:11px;'>
      <tr><td><b>Search:</b> $fQ</td><td><b>Role:</b> ".strtoupper($fR)."</td><td><b>Status:</b> ".ucfirst($fS)."</td></tr>
    </table><hr>", true,false,true,false,'');

    $tbl="<table border='1' cellpadding='5' cellspacing='0' style='font-size:10.5px;'>
      <thead><tr style='background:#eef5ef;'>
        <th width='20%'>Username</th><th width='26%'>Email</th><th width='12%'>Role</th><th width='12%'>Status</th><th width='30%'>Investor (Acct)</th>
      </tr></thead><tbody>";
    foreach($rows as $r){
        $tbl.="<tr>
          <td>".h($r['username'])."</td>
          <td>".h($r['email'])."</td>
          <td>".strtoupper(h($r['role']))."</td>
          <td>".ucfirst(h($r['status']))."</td>
          <td>".($r['investor'] ? h($r['investor']).' ('.h($r['account_number']).')' : '—')."</td>
        </tr>";
    }
    $tbl.="</tbody></table>";
    $pdf->writeHTML($tbl,true,false,true,false,'');
    $pdf->Output('users_report.pdf','I'); exit;
}

/* ---- Handle actions (POST) ---- */
$errors = [];
$successMsg = null;
$newPasswordShown = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tokenIn = $_POST['csrf'] ?? $_POST['csrf_token'] ?? '';
    $valid = function_exists('verifyCSRFToken') ? verifyCSRFToken($tokenIn) : hash_equals($csrf, $tokenIn);
    if (!$valid) {
        $errors[] = 'Invalid security token.';
    } else {
        $action = $_POST['action'] ?? '';
        try {
            if ($action === 'create') {
                $username = trim($_POST['username'] ?? '');
                $email    = trim($_POST['email'] ?? '');
                $roleIn   = trim($_POST['role'] ?? 'staff');
                $statusIn = trim($_POST['status'] ?? 'active');
                $pwIn     = trim($_POST['password'] ?? '');

                if ($username==='') $errors[]='Username is required.';
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[]='Valid email is required.';
                if (!validRole($roleIn))   $errors[]='Invalid role.';
                if (!validStatus($statusIn)) $errors[]='Invalid status.';
                if (!$errors) {
                    $username = strtolower($username);
                    $plain = $pwIn !== '' ? $pwIn : randomPassword(10);
                    $hash  = password_hash($plain, PASSWORD_DEFAULT);
                    $st = $pdo->prepare("INSERT INTO users (username, email, password, role, status) VALUES (?,?,?,?,?)");
                    $st->execute([$username,$email,$hash,$roleIn,$statusIn]);
                    $successMsg = 'User created successfully.';
                    $newPasswordShown = $plain; // show once
                }
            }
            if ($action === 'update') {
                $id     = (int)($_POST['id'] ?? 0);
                $username = trim($_POST['username'] ?? '');
                $email    = trim($_POST['email'] ?? '');
                $roleIn   = trim($_POST['role'] ?? '');
                $statusIn = trim($_POST['status'] ?? '');

                if ($id<=0) $errors[]='Invalid user ID.';
                if ($username==='') $errors[]='Username is required.';
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[]='Valid email is required.';
                if (!validRole($roleIn)) $errors[]='Invalid role.';
                if (!validStatus($statusIn)) $errors[]='Invalid status.';
                if (!$errors) {
                    $username = strtolower($username);
                    $st = $pdo->prepare("UPDATE users SET username=?, email=?, role=?, status=? WHERE id=?");
                    $st->execute([$username,$email,$roleIn,$statusIn,$id]);
                    $successMsg='User updated.';
                }
            }
            if ($action === 'toggle') {
                $id = (int)($_POST['id'] ?? 0);
                $to = trim($_POST['to'] ?? '');
                if ($id<=0 || !validStatus($to)) $errors[]='Invalid toggle request.';
                if (!$errors) {
                    $st = $pdo->prepare("UPDATE users SET status=? WHERE id=?");
                    $st->execute([$to,$id]);
                    $successMsg = 'Status updated.';
                }
            }
            if ($action === 'reset_pw') {
                $id = (int)($_POST['id'] ?? 0);
                if ($id<=0) $errors[]='Invalid user.';
                if (!$errors) {
                    $plain = randomPassword(10);
                    $hash = password_hash($plain, PASSWORD_DEFAULT);
                    $st = $pdo->prepare("UPDATE users SET password=? WHERE id=?");
                    $st->execute([$hash,$id]);
                    $successMsg = 'Password reset successfully.';
                    $newPasswordShown = $plain;
                }
            }
        } catch (Throwable $e) {
            $msg = $e->getMessage();
            if (stripos($msg,'duplicate')!==false) {
                if (stripos($msg,'username')!==false) $msg='Username already exists.';
                if (stripos($msg,'email')!==false)    $msg='Email already exists.';
            }
            $errors[] = 'Operation failed: ' . h($msg);
        }
    }
}

/* ---- Exports ---- */
if (($_GET['export'] ?? '') === 'csv') exportCSV($pdo, ['q'=>$q,'role'=>$role,'status'=>$status]);
if (($_GET['export'] ?? '') === 'pdf') exportPDF($pdo, ['q'=>$q,'role'=>$role,'status'=>$status]);

/* ---- Pagination + data ---- */
$total  = countUsers($pdo, ['q'=>$q,'role'=>$role,'status'=>$status]);
$pages  = max(1, (int)ceil($total / $per));
$page   = min($page, $pages);
$offset = ($page - 1)*$per;
$rows   = fetchUsers($pdo, ['q'=>$q,'role'=>$role,'status'=>$status], $per, $offset);

/* ---- Edit panel toggle ---- */
$editId = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$editRow = null;
if ($editId > 0) {
    foreach ($rows as $r) if ((int)$r['id'] === $editId) { $editRow = $r; break; }
}

/* ---- Header include & scoped styles ---- */
$page_title = 'Users';
include 'includes/header.php';
?>
<style>
  /* Scope to main-content so global theme stays intact */
  .main-content :root{
    --brand:#2c5530; --brand-2:#4a7c59; --bg:#f6f8f6; --text:#1f2937; --muted:#6b7280;
    --card:#ffffff; --border:#e8edf1; --ring:#d1fae5; --shadow:0 12px 32px rgba(0,0,0,.08); --shadow-soft:0 3px 10px rgba(0,0,0,.06);
  }
  .main-content .wrap{max-width:1120px;margin:28px auto;padding:0 16px}
  .main-content .card{background:var(--card);border-radius:16px;box-shadow:var(--shadow);border:1px solid var(--border);padding:18px}
  .main-content h1{margin:0;font-size:1.5rem}
  .main-content .toolbar{display:flex;gap:10px;flex-wrap:wrap;align-items:end;margin-top:12px}
  .main-content .toolbar .field{display:flex;flex-direction:column;gap:4px}
  .main-content .toolbar input,.main-content .toolbar select{padding:10px 12px;border:1px solid var(--border);border-radius:12px;background:#fff;outline:none}
  .main-content .toolbar input:focus,.main-content .toolbar select:focus{box-shadow:0 0 0 4px var(--ring);border-color:var(--brand-2)}
  
  .main-content label{display:block;font-size:.9rem;color:var(--muted);margin-bottom:6px}
  .main-content input,.main-content select{width:100%;padding:12px 14px;border:1px solid var(--border);border-radius:12px;background:#fff;font-size:1rem;outline:none}
  .main-content input:focus,.main-content select:focus{box-shadow:0 0 0 4px var(--ring);border-color:var(--brand-2)}
  .main-content .alert{padding:12px 14px;border-radius:12px;margin-bottom:12px;border:1px solid var(--border);box-shadow:var(--shadow-soft)}
  .main-content .alert-danger{background:#fff5f5;color:#7f1d1d}
  .main-content .alert-success{background:#eefaf1;color:#14532d}
  .main-content .note{font-size:.9rem;color:#6b7280}
  .main-content .grid-2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
  @media (max-width:900px){.main-content .grid-2{grid-template-columns:1fr}}

  .main-content table{width:100%;border-collapse:separate;border-spacing:0 8px}
  .main-content th{font-size:.9rem;color:#374151;text-align:left;padding:0 10px}
  .main-content td{background:#fff;border:1px solid var(--border);border-left:none;border-right:none;padding:12px 10px}
  .main-content tr{box-shadow:0 4px 12px rgba(0,0,0,.04);border-radius:12px}
  .main-content tr td:first-child{border-top-left-radius:12px;border-bottom-left-radius:12px;border-left:1px solid var(--border)}
  .main-content tr td:last-child{border-top-right-radius:12px;border-bottom-right-radius:12px;border-right:1px solid var(--border)}
  .main-content .badge{display:inline-flex;align-items:center;gap:6px;background:#eef5ef;color:#2c5530;border-radius:999px;padding:4px 10px;font-size:.8rem;border:1px solid #dce9de}
  .main-content .status-dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:#9ca3af;margin-right:6px}
  .main-content .status-active .status-dot{background:#16a34a}
  .main-content .status-inactive .status-dot{background:#9ca3af}
  .main-content .row-actions{display:flex;gap:8px;flex-wrap:wrap}


/* === Actions column: compact text-only buttons === */
.row-actions{
  display:flex;
  gap:6px;
  flex-wrap:wrap;
  align-items:center;
  white-space:nowrap; /* keep on one line when possible */
}

.row-actions form{ display:inline; margin:0; }

.row-actions .btn{
  /* compact + legible */
  display:inline-flex;
  align-items:center;
  justify-content:center;
  min-height:32px;
  padding:6px 12px;
  font-size:.85rem;
  font-weight:600;
  line-height:1;
  border-radius:10px;
  border:1px solid var(--border, #e8edf1);
  background:#fff;
  color:#1f2937;
  text-decoration:none;
  cursor:pointer;
  transition:background .15s ease, color .15s ease, border-color .15s ease, box-shadow .15s ease;
}

/* Colors (text-only) */
.row-actions .btn-primary{
  background:var(--brand, #2c5530);
  color:#fff;
  border-color:var(--brand, #2c5530);
}
.row-actions .btn-primary:hover{
  filter:brightness(0.96);
  box-shadow:0 0 0 3px var(--ring, #d1fae5);
}

.row-actions .btn-secondary{
  background:#fff;
  color:var(--brand, #2c5530);
  border-color:var(--brand, #2c5530);
}
.row-actions .btn-secondary:hover{
  background:#f6fff7;
}

.row-actions .btn-danger{
  background:#fee2e2;
  color:#7f1d1d;
  border-color:#fecaca;
}
.row-actions .btn-danger:hover{
  background:#fecaca;
}

/* If any icons slipped in, hide them for this row only */
.row-actions .btn svg,
.row-actions .btn i{
  display:none;
}

</style>

<div class="main-content">
  <div class="wrap">

    <!-- Top bar -->
    <div class="card" style="margin-bottom:12px;">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;">
        <h1>Users</h1>
        <div style="display:flex;gap:8px;">
          <a class="btn btn-secondary" href="dashboard.php">← Dashboard</a>
          <a class="btn btn-secondary" href="add_investor.php">+ Add Investor</a>
        </div>
      </div>

      <!-- Notifications -->
      <?php if ($errors): ?>
        <div class="alert alert-danger">
          <strong>There were problems:</strong>
          <ul><?php foreach($errors as $e) echo '<li>'.h($e).'</li>'; ?></ul>
        </div>
      <?php elseif ($successMsg): ?>
        <div class="alert alert-success">
          <?=h($successMsg)?>
          <?php if ($newPasswordShown): ?>
            <div class="note" style="margin-top:6px;">
              <strong>New Password:</strong>
              <code style="background:#eef2ff;border-radius:6px;padding:2px 6px"><?=h($newPasswordShown)?></code>
              <div>Share it now — it won’t be shown again.</div>
            </div>
          <?php endif; ?>
        </div>
      <?php endif; ?>

      <!-- Filters -->
      <form class="toolbar" method="get">
        <div class="field">
          <label>Search</label>
          <input type="text" name="q" value="<?=h($q)?>" placeholder="username, email, investor, account">
        </div>
        <div class="field">
          <label>Role</label>
          <select name="role">
            <option value="">All</option>
            <option value="admin"    <?=$role==='admin'?'selected':''?>>Admin</option>
            <option value="staff"    <?=$role==='staff'?'selected':''?>>Staff</option>
            <option value="investor" <?=$role==='investor'?'selected':''?>>Investor</option>
          </select>
        </div>
        <div class="field">
          <label>Status</label>
          <select name="status">
            <option value="">All</option>
            <option value="active"   <?=$status==='active'?'selected':''?>>Active</option>
            <option value="inactive" <?=$status==='inactive'?'selected':''?>>Inactive</option>
          </select>
        </div>
        <div class="field">
          <label>Per page</label>
          <select name="per">
            <?php foreach([10,25,50,100] as $opt): ?>
              <option value="<?=$opt?>" <?=$per===$opt?'selected':''?>><?=$opt?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field" style="gap:8px;flex-direction:row;align-items:center;">
          <button class="btn btn-primary" type="submit">Apply</button>
          <a class="btn btn-secondary" href="users.php">Reset</a>
          <a class="btn btn-secondary" href="?<?=http_build_query(array_merge($_GET,['export'=>'csv','page'=>null]))?>">Export CSV</a>
          <a class="btn btn-secondary" href="?<?=http_build_query(array_merge($_GET,['export'=>'pdf','page'=>null]))?>">PDF Report</a>
        </div>
      </form>
    </div>

    <!-- Add User -->
    <div class="card" style="margin-bottom:12px;">
      <h2 style="margin:0 0 10px;font-size:1.2rem">Add User</h2>
      <div class="note" style="margin-bottom:8px;">Use this to add <strong>Admin/Staff</strong> accounts. To add an <strong>Investor</strong>, please use the <em>Add Investor</em> page so their profile is created correctly.</div>
      <form method="post" class="grid-2" novalidate>
        <input type="hidden" name="csrf_token" value="<?=h($csrf)?>">
        <input type="hidden" name="action" value="create">
        <div>
          <label>Username</label>
          <input name="username" placeholder="e.g. admin.kato" required>
        </div>
        <div>
          <label>Email</label>
          <input type="email" name="email" placeholder="name@example.com" required>
        </div>
        <div>
          <label>Role</label>
          <select name="role" required>
            <option value="staff">Staff</option>
            <option value="admin">Admin</option>
            <option value="investor">Investor (not recommended here)</option>
          </select>
        </div>
        <div>
          <label>Status</label>
          <select name="status" required>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
        <div>
          <label>Password</label>
          <input name="password" placeholder="Leave empty to auto-generate">
        </div>
        <div style="display:flex;align-items:flex-end;justify-content:flex-end">
          <button class="btn btn-primary" type="submit">Create User</button>
        </div>
      </form>
    </div>

    <!-- Edit User (inline panel when ?edit=ID) -->
    <?php if ($editRow): ?>
    <div class="card" style="margin-bottom:12px;">
      <h2 style="margin:0 0 10px;font-size:1.2rem">Edit User: <?=h($editRow['username'])?></h2>
      <form method="post" class="grid-2" novalidate>
        <input type="hidden" name="csrf_token" value="<?=h($csrf)?>">
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="id" value="<?=$editRow['id']?>">
        <div>
          <label>Username</label>
          <input name="username" value="<?=h($editRow['username'])?>" required>
        </div>
        <div>
          <label>Email</label>
          <input type="email" name="email" value="<?=h($editRow['email'])?>" required>
        </div>
        <div>
          <label>Role</label>
          <select name="role" required>
            <option value="admin"    <?=$editRow['role']==='admin'?'selected':''?>>Admin</option>
            <option value="staff"    <?=$editRow['role']==='staff'?'selected':''?>>Staff</option>
            <option value="investor" <?=$editRow['role']==='investor'?'selected':''?>>Investor</option>
          </select>
        </div>
        <div>
          <label>Status</label>
          <select name="status" required>
            <option value="active"   <?=$editRow['status']==='active'?'selected':''?>>Active</option>
            <option value="inactive" <?=$editRow['status']==='inactive'?'selected':''?>>Inactive</option>
          </select>
        </div>
        <div style="display:flex;align-items:flex-end;justify-content:flex-end">
          <a class="btn btn-secondary" href="users.php">Cancel</a>
          <button class="btn btn-primary" type="submit" style="margin-left:8px;">Save Changes</button>
        </div>
      </form>
    </div>
    <?php endif; ?>

    <!-- Users Table -->
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
        <strong>All Users</strong>
        <div class="note">Total: <?=$total?></div>
      </div>
      <div style="overflow:auto">
        <table>
          <thead>
            <tr>
              <th>Username</th>
              <th>Email</th>
              <th>Role</th>
              <th>Status</th>
              <th>Investor</th>
              <th style="min-width:220px;">Actions</th>
            </tr>
          </thead>
          <tbody>
          <?php if (!$rows): ?>
            <tr><td colspan="6" style="text-align:center;color:#6b7280;background:transparent;border:none;box-shadow:none">No users found.</td></tr>
          <?php else: foreach ($rows as $r): ?>
            <tr>
              <td><?=h($r['username'])?></td>
              <td><?=h($r['email'])?></td>
              <td>
                <span class="badge"><?=roleIcon($r['role'],14)?> <?=strtoupper(h($r['role']))?></span>
              </td>
              <td class="status-<?=h($r['status'])?>">
                <span class="badge"><span class="status-dot"></span><?=ucfirst(h($r['status']))?></span>
              </td>
              <td>
                <?php if ($r['account_number']): ?>
                  <span class="badge"><?=h($r['first_name'].' '.$r['last_name'])?> (<?=h($r['account_number'])?>)</span>
                <?php else: ?>—<?php endif; ?>
              </td>
              <td>
                <div class="row-actions">
                  <a class="btn btn-secondary" href="?<?=http_build_query(array_merge($_GET,['edit'=>$r['id']]))?>">Edit</a>

                  <!-- Toggle status -->
                  <form method="post" style="display:inline">
                    <input type="hidden" name="csrf_token" value="<?=$csrf?>">
                    <input type="hidden" name="action" value="toggle">
                    <input type="hidden" name="id" value="<?=$r['id']?>">
                    <input type="hidden" name="to" value="<?=$r['status']==='active'?'inactive':'active'?>">
                    <button class="btn <?=($r['status']==='active'?'btn-danger':'btn-primary')?>" type="submit">
                      <?=$r['status']==='active'?'Deactivate':'Activate'?>
                    </button>
                  </form>

                  <!-- Reset password -->
                  <form method="post" style="display:inline" onsubmit="return confirm('Reset password for <?=h($r['username'])?>?');">
                    <input type="hidden" name="csrf_token" value="<?=$csrf?>">
                    <input type="hidden" name="action" value="reset_pw">
                    <input type="hidden" name="id" value="<?=$r['id']?>">
                    <button class="btn btn-secondary" type="submit">Reset Password</button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Pagination -->
      <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px">
        <?php
          $qs=$_GET; unset($qs['page']); $base='?'.http_build_query($qs);
          echo $page>1 ? '<a class="btn btn-secondary" href="'.$base.'&page='.($page-1).'">« Prev</a>' : '<span class="btn btn-secondary" style="opacity:.6">« Prev</span>';
          $window=5; $start=max(1,$page-$window); $end=min($pages,$page+$window);
          for($i=$start;$i<=$end;$i++){
            if ($i===$page) echo '<span class="btn btn-primary">'.$i.'</span>';
            else echo '<a class="btn btn-secondary" href="'.$base.'&page='.$i.'">'.$i.'</a>';
          }
          echo $page<$pages ? '<a class="btn btn-secondary" href="'.$base.'&page='.($page+1).'">Next »</a>' : '<span class="btn btn-secondary" style="opacity:.6">Next »</span>';
        ?>
      </div>
    </div>

  </div>
</div>

<?php
/* Inline SVG role icons */
function roleIcon(string $role, int $size=16): string {
    $s = $size;
    switch (strtolower($role)) {
        case 'admin': // shield
            return "<svg width='{$s}' height='{$s}' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'>
              <path d='M12 3l7 3v6c0 4-3 7-7 9-4-2-7-5-7-9V6l7-3z' stroke='#2c5530' stroke-width='1.7' fill='none'/></svg>";
        case 'staff': // cog
            return "<svg width='{$s}' height='{$s}' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'>
              <circle cx='12' cy='12' r='3' stroke='#2c5530' stroke-width='1.7'/>
              <path d='M19 12a7 7 0 0 0-.2-1.6l2.1-1.6-2-3.4-2.6 1A7 7 0 0 0 14 4h-4a7 7 0 0 0-1.3 1.4l-2.6-1-2 3.4 2.1 1.6A7 7 0 0 0 5 12a7 7 0 0 0 .2 1.6L3 15.2l2 3.4 2.6-1A7 7 0 0 0 10 20h4a7 7 0 0 0 1.3-1.4l2.6 1 2-3.4-2.1-1.6c.1-.5.2-1 .2-1.6z' stroke='#2c5530' stroke-width='1.2' fill='none'/></svg>";
        default: // investor leaf
            return "<svg width='{$s}' height='{$s}' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'>
              <path d='M4 13c5-9 12-8 16-7-1 7-7 12-12 12-2 0-4-1-4-5z' stroke='#2c5530' stroke-width='1.7' fill='none'/></svg>";
    }
}
include 'includes/footer.php';
