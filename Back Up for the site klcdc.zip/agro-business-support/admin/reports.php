<?php
// admin/reports.php
declare(strict_types=1);
session_start();

/**
 * Reports (Admin) – styled like dashboard, robust charts, scrollable sections
 * - Filters + CSV/PDF export (unchanged)
 * - KPI cards using .stats-grid
 * - Donut & Bar charts (pure SVG, no libs)
 * - Scrollable "Top Investors" and "Transactions"
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../classes/Auth.php';

if (!isLoggedIn() || !isAdmin()) {
  redirect('../index.php');
}
$auth = new Auth();
if (!$auth->validateSession()) {
  redirect('../index.php');
}

/** Resolve PDO similar to other pages */
function resolvePDO(): PDO {
  if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) return $GLOBALS['pdo'];
  if (function_exists('getDbConnection')) { $p = getDbConnection(); if ($p instanceof PDO) return $p; }
  if (class_exists('Database')) {
    $db = new Database();
    if (method_exists($db,'connect'))       { $p = $db->connect();       if ($p instanceof PDO) return $p; }
    if (method_exists($db,'getConnection')) { $p = $db->getConnection(); if ($p instanceof PDO) return $p; }
  }
  throw new RuntimeException('Could not obtain PDO from config/database.php');
}

try {
  $pdo = resolvePDO();
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (Throwable $e) {
  http_response_code(500);
  die('Database connection error: ' . htmlspecialchars($e->getMessage()));
}

/** TCPDF loader (for PDF export) */
function tryIncludeTCPDF(): bool {
  $candidates = [
    __DIR__ . '/../vendor/tcpdf/tcpdf.php',
    __DIR__ . '/../tcpdf_min/tcpdf.php',
    __DIR__ . '/../tcpdf.php',
  ];
  foreach ($candidates as $p) {
    if (is_readable($p)) {
      if (!defined('K_PATH_CACHE')) {
        $cache = realpath(__DIR__ . '/../temp');
        if (!$cache) { @mkdir(__DIR__ . '/../temp', 0775, true); $cache = __DIR__ . '/../temp'; }
        define('K_PATH_CACHE', rtrim($cache, '/\\') . DIRECTORY_SEPARATOR);
      }
      require_once $p;
      return true;
    }
  }
  return false;
}

/** Helpers */
function moneyUGX(float $amount): string { return 'UGX ' . number_format($amount, 0, '.', ','); }
function validType(?string $t): ?string { $t = $t ? strtolower($t) : null; return in_array($t, ['cash','material','labor'], true) ? $t : null; }
function parseDate(?string $s, string $eod = '00:00:00'): ?string { if(!$s) return null; $ts = strtotime($s); if(!$ts) return null; return date('Y-m-d', $ts).' '.$eod; }

function typeIcon(string $type, int $size = 16): string {
  $s = $size;
  switch (strtolower($type)) {
    case 'cash':
      return "<svg width='{$s}' height='{$s}' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'>
        <rect x='3' y='6' width='18' height='12' rx='2' stroke='#2c5530' stroke-width='1.7'/>
        <circle cx='12' cy='12' r='3' stroke='#2c5530' stroke-width='1.7'/>
      </svg>";
    case 'material':
      return "<svg width='{$s}' height='{$s}' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'>
        <path d='M12 3L3 9l9 6 9-6-9-6Z' stroke='#2c5530' stroke-width='1.7'/>
        <path d='M3 15l9 6 9-6' stroke='#2c5530' stroke-width='1.7'/>
      </svg>";
    default: // labor
      return "<svg width='{$s}' height='{$s}' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'>
        <path d='M7 7l10 10M7 17L17 7' stroke='#2c5530' stroke-width='1.7'/>
        <circle cx='6' cy='6' r='2' stroke='#2c5530' stroke-width='1.7'/>
        <circle cx='18' cy='18' r='2' stroke='#2c5530' stroke-width='1.7'/>
      </svg>";
  }
}

/** WHERE builder reused by queries */
function buildWhere(array $filters, array &$params): string {
  $w = [];
  if (!empty($filters['q'])) {
    $w[] = "(i.first_name LIKE :q OR i.last_name LIKE :q OR i.account_number LIKE :q OR inv.transaction_id LIKE :q OR inv.receipt_number LIKE :q)";
    $params[':q'] = '%'.$filters['q'].'%';
  }
  if (!empty($filters['type'])) { $w[] = "inv.investment_type = :t"; $params[':t'] = $filters['type']; }
  if (!empty($filters['from'])) { $w[] = "inv.investment_date >= :from"; $params[':from'] = $filters['from']; }
  if (!empty($filters['to']))   { $w[] = "inv.investment_date <= :to";   $params[':to']   = $filters['to']; }
  return $w ? ('WHERE ' . implode(' AND ', $w)) : '';
}

/** Totals (all + by type) */
function totalsInvestments(PDO $pdo, array $filters): array {
    $params=[]; $where=buildWhere($filters,$params);
    $sql="SELECT
            COALESCE(SUM(inv.amount),0) AS total,
            COALESCE(SUM(CASE WHEN inv.investment_type='cash'     THEN inv.amount ELSE 0 END),0) AS cash,
            COALESCE(SUM(CASE WHEN inv.investment_type='material' THEN inv.amount ELSE 0 END),0) AS material,
            COALESCE(SUM(CASE WHEN inv.investment_type='labor'    THEN inv.amount ELSE 0 END),0) AS labor
          FROM investments inv
          JOIN investors i ON inv.investor_id=i.id
          $where";
    $st=$pdo->prepare($sql); $st->execute($params);
    $r=$st->fetch() ?: ['total'=>0,'cash'=>0,'material'=>0,'labor'=>0];
    return [
        'total'=>(float)$r['total'],
        'cash'=>(float)$r['cash'],
        'material'=>(float)$r['material'],
        'labor'=>(float)$r['labor'],
    ];
}


/** Monthly totals (YYYY-MM) */
function monthlyTotals(PDO $pdo, array $filters): array {
  $params=[]; $where=buildWhere($filters,$params);
  $sql="SELECT DATE_FORMAT(inv.investment_date, '%Y-%m') AS ym, SUM(inv.amount) AS total
        FROM investments inv
        JOIN investors i ON inv.investor_id=i.id
        $where
        GROUP BY ym
        ORDER BY ym ASC";
  $st=$pdo->prepare($sql); $st->execute($params);
  $rows=$st->fetchAll();

  $labels=[]; $data=[];
  if (empty($filters['from']) && empty($filters['to'])) {
    $map=[]; foreach($rows as $r){ $map[$r['ym']]=(float)$r['total']; }
    $start=new DateTime('first day of -11 months');
    for($i=0;$i<12;$i++){
      $key=$start->format('Y-m'); $labels[]=$key; $data[]=(float)($map[$key]??0);
      $start->modify('+1 month');
    }
  } else {
    foreach($rows as $r){ $labels[]=$r['ym']; $data[]=(float)$r['total']; }
  }
  return ['labels'=>$labels,'data'=>$data];
}

/** Top investors */
function topInvestors(PDO $pdo, array $filters, int $limit=5): array {
  $params=[]; $where=buildWhere($filters,$params);
  $sql="SELECT i.id, i.account_number, CONCAT(i.first_name,' ',i.last_name) AS name, SUM(inv.amount) AS total
        FROM investments inv
        JOIN investors i ON inv.investor_id=i.id
        $where
        GROUP BY i.id, i.account_number, name
        ORDER BY total DESC
        LIMIT {$limit}";
  $st=$pdo->prepare($sql); $st->execute($params);
  return $st->fetchAll();
}

/** Table data + pagination */
function countInvestments(PDO $pdo, array $filters): int {
  $params=[]; $where=buildWhere($filters,$params);
  $st=$pdo->prepare("SELECT COUNT(*) AS c
                     FROM investments inv
                     JOIN investors i ON inv.investor_id=i.id
                     $where"); $st->execute($params); $row=$st->fetch();
  return (int)($row['c']??0);
}
function fetchInvestments(PDO $pdo, array $filters, int $limit, int $offset): array {
  $params=[]; $where=buildWhere($filters,$params);
  $sql="SELECT inv.id, inv.investment_date, inv.transaction_id, inv.receipt_number, inv.investment_type, inv.amount,
               i.account_number, i.first_name, i.last_name
        FROM investments inv
        JOIN investors i ON inv.investor_id=i.id
        $where
        ORDER BY inv.investment_date DESC, inv.id DESC
        LIMIT $limit OFFSET $offset";
  $st=$pdo->prepare($sql); $st->execute($params);
  return $st->fetchAll();
}

/** Exports */
function exportCSV(PDO $pdo, array $filters): void {
  $params=[]; $where=buildWhere($filters,$params);
  $sql="SELECT inv.investment_date, inv.transaction_id, inv.receipt_number, inv.investment_type, inv.amount,
               i.account_number, CONCAT(i.first_name,' ',i.last_name) AS investor
        FROM investments inv
        JOIN investors i ON inv.investor_id=i.id
        $where
        ORDER BY inv.investment_date DESC, inv.id DESC";
  $st=$pdo->prepare($sql); $st->execute($params); $rows=$st->fetchAll();

  header('Content-Type: text/csv; charset=utf-8');
  header('Content-Disposition: attachment; filename=report_investments.csv');
  $out=fopen('php://output','w');
  fputcsv($out, ['Date','TXN','Receipt','Type','Amount(UGX)','Account','Investor']);
  foreach($rows as $r){
    fputcsv($out, [
      $r['investment_date'],
      $r['transaction_id'],
      $r['receipt_number'],
      strtoupper($r['investment_type']),
      number_format((float)$r['amount'],0,'.',','),
      $r['account_number'],
      $r['investor'],
    ]);
  }
  fclose($out); exit;
}

function exportPDF(PDO $pdo, array $filters): void {
    if (!tryIncludeTCPDF()) {
        header('Content-Type: text/plain; charset=utf-8');
        echo "TCPDF not found. Put it in vendor/tcpdf/ (or tcpdf_min/).";
        exit;
    }
    while (ob_get_level()) { ob_end_clean(); }

    $params=[]; $where=buildWhere($filters,$params);
    $sql="SELECT inv.investment_date, inv.transaction_id, inv.receipt_number, inv.investment_type, inv.amount,
                 i.account_number, CONCAT(i.first_name,' ',i.last_name) AS investor
          FROM investments inv
          JOIN investors i ON inv.investor_id=i.id
          $where
          ORDER BY inv.investment_date DESC, inv.id DESC";
    $st=$pdo->prepare($sql); $st->execute($params); $rows=$st->fetchAll();

    $tot = totalsInvestments($pdo, $filters);
    $mon = monthlyTotals($pdo, $filters);
    $top = topInvestors($pdo, $filters, 5);

    $pdf=new TCPDF('P','mm','A4',true,'UTF-8',false);
    $pdf->SetCreator('Kaliro Lords Community Development Corporation');
    $pdf->SetTitle('Investment Report');
    $pdf->SetMargins(12,12,12);
    $pdf->AddPage();
    $pdf->SetFont('helvetica','',11);

    // Header bar
    $pdf->SetFillColor(44,85,48);
    $pdf->Rect(12,12,186,14,'F');
    $pdf->SetTextColor(255,255,255);
    $pdf->SetFont('helvetica','B',13);
    $pdf->SetXY(16,14);
    $pdf->Write(8,'Investment Report');
    $pdf->Ln(18);
    $pdf->SetTextColor(0,0,0);

    $fQ=htmlspecialchars($filters['q']??''); $fT=htmlspecialchars($filters['type']??'All');
    $fF=htmlspecialchars($filters['from_raw']??''); $fT0=htmlspecialchars($filters['to_raw']??'');

    $pdf->writeHTML("<table cellpadding='4' style='font-size:11px;'>
      <tr><td><b>Search:</b> $fQ</td><td><b>Type:</b> ".strtoupper($fT)."</td><td><b>From:</b> $fF</td><td><b>To:</b> $fT0</td></tr>
    </table><hr>", true,false,true,false,'');

    // Totals
    $pdf->writeHTML("<table cellpadding='5' style='font-size:11px;'>
      <tr>
        <td><b>Total:</b> ".moneyUGX($tot['total'])."</td>
        <td><b>Cash:</b> ".moneyUGX($tot['cash'])."</td>
        <td><b>Material:</b> ".moneyUGX($tot['material'])."</td>
        <td><b>Labor:</b> ".moneyUGX($tot['labor'])."</td>
      </tr>
    </table>", true,false,true,false,'');

    // Monthly table
    if ($mon['labels']) {
      $tbl="<br><b>Monthly Totals</b><table border='1' cellpadding='4' cellspacing='0' style='font-size:10.5px;'><thead><tr>
            <th>Month</th><th>Total</th></tr></thead><tbody>";
      foreach ($mon['labels'] as $i=>$m) {
        $tbl.="<tr><td>$m</td><td>".moneyUGX((float)$mon['data'][$i])."</td></tr>";
      }
      $tbl.="</tbody></table>";
      $pdf->writeHTML($tbl,true,false,true,false,'');
    }

    // Top investors
    if ($top) {
      $tbl="<br><b>Top Investors</b><table border='1' cellpadding='4' cellspacing='0' style='font-size:10.5px;'><thead><tr>
            <th>Investor (Account)</th><th>Total</th></tr></thead><tbody>";
      foreach ($top as $ti) {
        $tbl.="<tr><td>".htmlspecialchars($ti['name'])." (".htmlspecialchars($ti['account_number']).")</td><td>".moneyUGX((float)$ti['total'])."</td></tr>";
      }
      $tbl.="</tbody></table>";
      $pdf->writeHTML($tbl,true,false,true,false,'');
    }

    // Detail table – USE investor alias (no first_name/last_name here)
    $tbl="<br><b>Transactions</b><table border='1' cellpadding='5' cellspacing='0' style='font-size:10.5px;'>
      <thead><tr style='background-color:#eef5ef;'>
        <th width='18%'>Date</th><th width='14%'>Receipt</th><th width='14%'>TXN</th>
        <th width='12%'>Type</th><th width='14%'>Amount</th><th width='28%'>Investor (Acct)</th>
      </tr></thead><tbody>";
    foreach ($rows as $r) {
      $investor = isset($r['investor']) ? $r['investor'] : '';
      $acct     = isset($r['account_number']) ? $r['account_number'] : '';
      $tbl.="<tr>
        <td>".htmlspecialchars($r['investment_date'])."</td>
        <td>".htmlspecialchars($r['receipt_number'])."</td>
        <td>".htmlspecialchars($r['transaction_id'])."</td>
        <td>".strtoupper(htmlspecialchars($r['investment_type']))."</td>
        <td>".moneyUGX((float)$r['amount'])."</td>
        <td>".htmlspecialchars($investor)." (".htmlspecialchars($acct).")</td>
      </tr>";
    }
    $tbl.="</tbody></table>";
    $pdf->writeHTML($tbl,true,false,true,false,'');

    $pdf->Output('investment_report.pdf','I'); exit;
}


/* ---------- Read filters ---------- */
$qRaw = trim($_GET['q'] ?? '');
$type = validType($_GET['type'] ?? null);
$fromR= trim($_GET['from'] ?? '');
$toR  = trim($_GET['to'] ?? '');
$from = $fromR ? parseDate($fromR,'00:00:00') : null;
$to   = $toR   ? parseDate($toR,'23:59:59')  : null;

$filters = [
  'q'        => $qRaw ?: null,
  'type'     => $type,
  'from'     => $from,
  'to'       => $to,
  'from_raw' => $fromR,
  'to_raw'   => $toR,
];

/* ---------- Exports (before HTML) ---------- */
if (($_GET['export'] ?? '') === 'csv') exportCSV($pdo, $filters);
if (($_GET['export'] ?? '') === 'pdf') exportPDF($pdo, $filters);

/* ---------- Pagination & Data ---------- */
$perPage = max(10, (int)($_GET['per'] ?? 25));
$page    = max(1, (int)($_GET['page'] ?? 1));
$total   = countInvestments($pdo, $filters);
$pages   = max(1, (int)ceil($total / $perPage));
$page    = min($page, $pages);
$offset  = ($page - 1) * $perPage;

$totals   = totalsInvestments($pdo, $filters);
$monthly  = monthlyTotals($pdo, $filters);
$leaders  = topInvestors($pdo, $filters, 10);
$rows     = fetchInvestments($pdo, $filters, $perPage, $offset);

/* ---------- JSON for charts ---------- */
$chartMonthlyLabels = json_encode($monthly['labels'], JSON_UNESCAPED_UNICODE);
$chartMonthlyData   = json_encode($monthly['data'], JSON_UNESCAPED_UNICODE);
$chartTypeData      = json_encode([
  'cash'     => (float)$totals['cash'],
  'material' => (float)$totals['material'],
  'labor'    => (float)$totals['labor'],
], JSON_UNESCAPED_UNICODE);

/* ---------- Header include ---------- */
$page_title = 'Reports';
include 'includes/header.php';
?>
<style>
  /* ==== Reports layout tuned to your style.css tokens ==== */
  .cards-grid {
    display:grid;
    grid-template-columns: 2fr 1fr;
    gap:1.5rem;
  }
  @media (max-width: 1100px){ .cards-grid{ grid-template-columns:1fr; } }

  .chart-box { height: 300px; }
  .chart-body { padding: 1rem; }

  /* Donut chart polish (same feel as dashboard) */
  #pieChart { padding: 12px; }
  .donut { position: relative; height: 240px; display:flex; align-items:center; justify-content:center; }
  .donut svg { display:block; }
  .donut .center { position:absolute; text-align:center; line-height:1.15; transform: translateY(2px); }
  .donut .center .label { font-size:12px; color:#6b7280; letter-spacing:.03em; font-weight:700; }
  .donut .center .value { font-size:16px; font-weight:800; color:#111827; margin-top:2px; }
  .legend { display:flex; flex-wrap:wrap; gap:8px 14px; justify-content:center; margin-top:8px; }
  .legend .item { display:flex; align-items:center; gap:8px; font-size:12px; color:#374151; }
  .legend .sw { width:12px; height:12px; border-radius:3px; }

  /* Scrollable sections */
  .scroll-y { max-height: 420px; overflow: auto; }
  .scroll-y::-webkit-scrollbar { width: 8px; height: 8px; }
  .scroll-y::-webkit-scrollbar-thumb { background:#d1d5db; border-radius: 6px; }

  .kpi-card { text-align:center; }
  .kpi-card .stat-number { font-size:1.75rem; }

  .toolbar-compact { display:flex; gap:1rem; flex-wrap:wrap; align-items:flex-end; }
  .toolbar-compact .form-group { margin-bottom: 0.5rem; }

  /* Responsive charts grid + sizing */
.charts-grid{
  display:grid;
  grid-template-columns: 1fr;
  gap:14px;
}
@media (min-width: 900px){
  .charts-grid{ grid-template-columns: 1fr 1fr; align-items: stretch; }
  .charts-grid .span-2{ grid-column: 1 / -1; }
}
.chart-body{ padding:0; }
.chart-box{ width:100%; min-height:320px; }
.chart-legend{ display:flex; gap:10px; flex-wrap:wrap; padding:0 1rem 1rem; color:#374151; font-size:.92rem; }
.chart-legend .chart-swatch{ width:10px; height:10px; border-radius:2px; display:inline-block; margin-right:6px; }
.scroll-y{ overflow:auto; }



</style>

<div class="main-content">
  <!-- Page header -->
  <div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
      <span>Reports</span>
      <div>
        <a class="btn btn-light btn-sm" href="dashboard.php">← Dashboard</a>
        <a class="btn btn-light btn-sm" href="investments.php">Investments</a>
        <a class="btn btn-primary btn-sm" href="add_investment.php">+ Add Investment</a>
      </div>
    </div>
    <div class="card-body">
      <form method="get" class="toolbar-compact">
        <div class="form-group" style="min-width:220px;">
          <label>Search</label>
          <input type="text" name="q" value="<?=htmlspecialchars($qRaw)?>" placeholder="name, account, receipt, TXN">
        </div>
        <div class="form-group">
          <label>Type</label>
          <select name="type">
            <option value="">All</option>
            <option value="cash"     <?=$type==='cash'?'selected':''?>>Cash</option>
            <option value="material" <?=$type==='material'?'selected':''?>>Material</option>
            <option value="labor"    <?=$type==='labor'?'selected':''?>>Labor</option>
          </select>
        </div>
        <div class="form-group">
          <label>From</label>
          <input type="date" name="from" value="<?=htmlspecialchars($fromR)?>">
        </div>
        <div class="form-group">
          <label>To</label>
          <input type="date" name="to" value="<?=htmlspecialchars($toR)?>">
        </div>
        <div class="form-group">
          <label>Per page</label>
          <select name="per">
            <?php foreach([10,25,50,100] as $opt): ?>
              <option value="<?=$opt?>" <?=$perPage===$opt?'selected':''?>><?=$opt?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group d-flex" style="gap:.5rem;">
          <button class="btn btn-primary">Apply</button>
          <a class="btn btn-light" href="reports.php">Reset</a>
          <a class="btn btn-light" href="?<?=http_build_query(array_merge($_GET,['export'=>'csv','page'=>null]))?>">Export CSV</a>
          <a class="btn btn-light" href="?<?=http_build_query(array_merge($_GET,['export'=>'pdf','page'=>null]))?>">PDF Report</a>
          <button type="button" class="btn btn-light" onclick="window.print()">Print Page</button>
        </div>
      </form>
    </div>
  </div>

<!-- Transactions table -->
  <div class="card">
<div class="card-header" id="txns">Transactions</div>
    <div class="card-body">
      <div class="table-responsive scroll-y">
        <table class="table">
          <thead>
            <tr>
              <th>Date & Time</th>
              <th>Investor</th>
              <th>Account</th>
              <th>Type</th>
              <th class="text-right">Amount</th>
              <th>Receipt</th>
              <th>TXN</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
          <?php if (!$rows): ?>
            <tr><td colspan="8" class="text-center text-muted">No records.</td></tr>
          <?php else: foreach ($rows as $r): ?>
            <tr>
              <td><?=htmlspecialchars($r['investment_date'])?></td>
              <td><?=htmlspecialchars($r['first_name'].' '.$r['last_name'])?></td>
              <td><span class="badge badge-secondary"><?=htmlspecialchars($r['account_number'])?></span></td>
              <td><span class="badge badge-secondary"><?=strtoupper(htmlspecialchars($r['investment_type']))?></span></td>
              <td class="text-right"><?=moneyUGX((float)$r['amount'])?></td>
              <td><?=htmlspecialchars($r['receipt_number'])?></td>
              <td><?=htmlspecialchars($r['transaction_id'])?></td>
              <td><a href="../print_receipt.php?investment_id=<?= (int)$r['id'] ?>&action=download" target="_blank" rel="noopener">Print Receipt</a></td>
            </tr>
          <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
      

      <!-- Pagination -->
  <div class="pagination">
  <?php
    // keep all current filters in the URL, only change the page number
    $qs = $_GET;
    unset($qs['page']);
    $base   = '?'.http_build_query($qs);
    $anchor = '#txns';

    echo $page>1
      ? '<a href="'.$base.'&page='.($page-1).$anchor.'">« Prev</a>'
      : '<span>« Prev</span>';

    $window = 5;
    $start  = max(1, $page - $window);
    $end    = min($pages, $page + $window);

    for ($i = $start; $i <= $end; $i++) {
      echo $i === $page
        ? '<span class="active">'.$i.'</span>'
        : '<a href="'.$base.'&page='.$i.$anchor.'">'.$i.'</a>';
    }

    echo $page < $pages
      ? '<a href="'.$base.'&page='.($page+1).$anchor.'">Next »</a>'
      : '<span>Next »</span>';
  ?>
</div>



  <!-- KPI cards -->
  <div class="stats-grid">
    <div class="stat-card kpi-card">
      <div class="stat-number"><?=moneyUGX($totals['total'])?></div>
      <div class="stat-label">Total</div>
    </div>
    <div class="stat-card kpi-card">
      <div class="stat-number"><?=moneyUGX($totals['cash'])?></div>
      <div class="stat-label">Cash</div>
    </div>
    <div class="stat-card kpi-card">
      <div class="stat-number"><?=moneyUGX($totals['material'])?></div>
      <div class="stat-label">Material</div>
    </div>
    <div class="stat-card kpi-card">
      <div class="stat-number"><?=moneyUGX($totals['labor'])?></div>
      <div class="stat-label">Labor</div>
    </div>
  </div>

  <!-- Charts (responsive) -->
<div class="charts-grid">
  <div class="card">
    <div class="card-header">Monthly Totals</div>
    <div class="card-body chart-body">
      <div id="barChart" class="chart-box" aria-label="Monthly totals chart"></div>
    </div>
  </div>

  <div class="card">
    <div class="card-header">By Type</div>
    <div class="card-body chart-body">
      <div id="pieChart" class="chart-box" aria-label="Totals by type"></div>
      <div id="typeLegend" class="chart-legend" aria-hidden="true"></div>
    </div>
  </div>

  <?php if ($leaders): ?>
  <div class="card span-2">
    <div class="card-header">Top Investors</div>
    <div class="card-body scroll-y" style="max-height:280px;padding-top:.75rem;">
      <?php foreach ($leaders as $ti): ?>
        <div class="card" style="margin-bottom:.75rem;">
          <div class="card-body d-flex justify-content-between align-items-center">
            <div>
              <div style="font-weight:700;"><?=htmlspecialchars($ti['name'])?></div>
              <div class="text-muted">Acct: <?=htmlspecialchars($ti['account_number'])?></div>
            </div>
            <div style="font-weight:800;"><?=moneyUGX((float)$ti['total'])?></div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>
</div>


  

<?php include 'includes/footer.php'; ?>

<script>
(() => {
  const monthlyLabels = <?=$chartMonthlyLabels?>;
  const monthlyData   = <?=$chartMonthlyData?>;
  const typeData      = <?=$chartTypeData?>;

  const colors = ['#2c5530', '#4a7c59', '#a7c4a0'];

  function fmtUGX(n){ return 'UGX ' + Number(n||0).toLocaleString('en-UG',{maximumFractionDigits:0}); }

  function renderBar(){
    const el = document.getElementById('barChart');
    if(!el) return;
    const W = Math.max(320, el.clientWidth || 600);
    const H = 320, pad = {t:30,r:20,b:40,l:56};
    const innerW = W - pad.l - pad.r, innerH = H - pad.t - pad.b;
    const max = Math.max(1, ...monthlyData);

    const NS='http://www.w3.org/2000/svg';
    const svg=document.createElementNS(NS,'svg'); svg.setAttribute('width',W); svg.setAttribute('height',H);

    const x0=pad.l, y0=pad.t+innerH;
    const xAxis=document.createElementNS(NS,'line');
    xAxis.setAttribute('x1',x0); xAxis.setAttribute('y1',y0);
    xAxis.setAttribute('x2',x0+innerW); xAxis.setAttribute('y2',y0);
    xAxis.setAttribute('stroke','#e5e9ee'); svg.appendChild(xAxis);

    for(let i=0;i<=4;i++){
      const v=max*i/4, y=y0-(v/max)*innerH;
      const grid=document.createElementNS(NS,'line');
      grid.setAttribute('x1',x0); grid.setAttribute('y1',y);
      grid.setAttribute('x2',x0+innerW); grid.setAttribute('y2',y);
      grid.setAttribute('stroke','#f2f5f7'); svg.appendChild(grid);

      const lbl=document.createElementNS(NS,'text');
      lbl.setAttribute('x',10); lbl.setAttribute('y',y+4);
      lbl.setAttribute('fill','#6b7280'); lbl.setAttribute('font-size','11');
      lbl.textContent = fmtUGX(v); svg.appendChild(lbl);
    }

    const step = innerW/(monthlyData.length||1);
    const bw = Math.max(6, step*0.7);
    monthlyData.forEach((v,i)=>{
      const x = x0 + i*step + (step-bw)/2;
      const h = (v/max)*innerH, y = y0 - h;
      const r=document.createElementNS(NS,'rect');
      r.setAttribute('x',x); r.setAttribute('y',y);
      r.setAttribute('width',bw); r.setAttribute('height',h);
      r.setAttribute('rx','6'); r.setAttribute('fill',colors[0]); r.setAttribute('opacity','0.9');
      svg.appendChild(r);

      const t=document.createElementNS(NS,'text');
      t.setAttribute('x',x+bw/2); t.setAttribute('y',y0+14);
      t.setAttribute('text-anchor','middle'); t.setAttribute('fill','#6b7280'); t.setAttribute('font-size','11');
      t.textContent=(monthlyLabels[i]||'').slice(2); svg.appendChild(t);
    });

    el.innerHTML=''; el.appendChild(svg);
  }

  function renderPie(){
    const el = document.getElementById('pieChart');
    if(!el) return;
    const W = Math.max(260, el.clientWidth || 560), H = 320;
    const R = Math.min(W,H)*0.40, cx=W/2, cy=H/2;

    const values=[typeData.cash||0, typeData.material||0, typeData.labor||0];
    const names =['Cash','Material','Labor'];
    const total = values.reduce((a,b)=>a+b,0);

    const NS='http://www.w3.org/2000/svg';
    const svg=document.createElementNS(NS,'svg'); svg.setAttribute('width',W); svg.setAttribute('height',H);

    let start=-Math.PI/2;
    values.forEach((val,i)=>{
      const angle= total ? (val/total)*Math.PI*2 : 0, end=start+angle;
      const x1=cx+R*Math.cos(start), y1=cy+R*Math.sin(start);
      const x2=cx+R*Math.cos(end),   y2=cy+R*Math.sin(end);
      const large = angle>Math.PI?1:0;

      const p=document.createElementNS(NS,'path');
      p.setAttribute('d',`M ${cx} ${cy} L ${x1} ${y1} A ${R} ${R} 0 ${large} 1 ${x2} ${y2} Z`);
      p.setAttribute('fill',colors[i]); p.setAttribute('opacity','0.9'); svg.appendChild(p);
      start=end;
    });

    const hole=document.createElementNS(NS,'circle');
    hole.setAttribute('cx',cx); hole.setAttribute('cy',cy); hole.setAttribute('r',R*0.58);
    hole.setAttribute('fill','#fff'); svg.appendChild(hole);

    const center=document.createElementNS(NS,'text');
    center.setAttribute('x',cx); center.setAttribute('y',cy);
    center.setAttribute('text-anchor','middle'); center.setAttribute('dominant-baseline','middle');
    center.setAttribute('fill','#111'); center.setAttribute('font-size','13'); center.setAttribute('font-weight','700');
    center.textContent='TOTAL: ' + fmtUGX(total); svg.appendChild(center);

    el.innerHTML=''; el.appendChild(svg);

    const legend=document.getElementById('typeLegend');
    if(legend){
      legend.innerHTML = names.map((n,i)=>(
        `<span><span class="chart-swatch" style="background:${colors[i]}"></span>${n} (${fmtUGX(values[i])})</span>`
      )).join('');
    }
  }

  function rerender(){ renderBar(); renderPie(); }
  window.addEventListener('resize', ()=>{ clearTimeout(window.__rpt); window.__rpt=setTimeout(rerender,120); });
  rerender();
})();
</script>
