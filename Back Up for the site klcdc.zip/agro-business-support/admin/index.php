<?php
// admin/index.php — admin front controller

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../classes/Auth.php';

if (!isLoggedIn() || !isAdmin()) {
  redirect(rtrim(APP_URL,'/').'/');
  exit;
}

$route = isset($_GET['route']) ? trim($_GET['route'], '/') : '';

// helper to include from admin/includes/*
function admin_include($file) {
  $path = __DIR__ . '/includes/' . ltrim($file, '/');
  if (is_file($path)) { require $path; return true; }
  return false;
}

$page_title = 'Admin';
require __DIR__ . '/includes/header.php';

switch ($route) {
  case '':                           admin_include('dashboard.php'); break;
  case 'investors':                  admin_include('investors.php'); break;
  case 'investors/add':              admin_include('add_investor.php'); break; // <-- your new page
  case 'logout':                     require __DIR__ . '/logout.php'; break;
  default:
    http_response_code(404);
    echo '<div class="container" style="padding:1.2rem"><h2>404</h2><p>Unknown route: '
         . htmlspecialchars($route) . '</p></div>';
}

require __DIR__ . '/includes/footer.php';
