<?php
// admin/add_investor.php
declare(strict_types=1);
session_start();

/**
 * Add Investor
 * - Creates BOTH: users row (role='investor') and investors profile row.
 * - Admin can set username/password or leave password blank to auto-generate.
 * - Uses transaction + password_hash()
 * - Now uses standard admin header + sidebar + footer.
 */

require_once __DIR__ . '/../config/config.php';   // includes database.php + helpers
require_once __DIR__ . '/../classes/Auth.php';

// Gate like other admin pages
if (!isLoggedIn() || !isAdmin()) {
    redirect('../index.php');
}
$auth = new Auth();
if (!$auth->validateSession()) {
    redirect('../index.php');
}

/** Resolve a PDO from various common patterns */
function resolvePDO(): PDO {
    if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) return $GLOBALS['pdo'];
    if (function_exists('getDbConnection')) { $p = getDbConnection(); if ($p instanceof PDO) return $p; }
    if (class_exists('Database')) {
        $db = new Database();
        if (method_exists($db,'connect'))       { $p = $db->connect();       if ($p instanceof PDO) return $p; }
        if (method_exists($db,'getConnection')) { $p = $db->getConnection(); if ($p instanceof PDO) return $p; }
    }
    throw new RuntimeException('Could not obtain a PDO connection from config/database.php');
}

try {
    $pdo = resolvePDO();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    http_response_code(500);
    die('Database connection error: ' . htmlspecialchars($e->getMessage()));
}

/** Generate AGR### account number */
function nextAccountNo(PDO $pdo): string {
    $stmt = $pdo->query("SELECT COUNT(*) AS c FROM investors");
    $n = (int)$stmt->fetch()['c'] + 1;
    return 'AGR' . str_pad((string)$n, 3, '0', STR_PAD_LEFT);
}

/** Generate a strong random password */
function randomPassword(int $length = 10): string {
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%';
    $pw = '';
    for ($i = 0; $i < $length; $i++) {
        $pw .= $alphabet[random_int(0, strlen($alphabet)-1)];
    }
    return $pw;
}

$errors = [];
$success = null;

// Handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize inputs
    $first       = trim($_POST['first_name'] ?? '');
    $last        = trim($_POST['last_name'] ?? '');
    $email       = trim($_POST['email'] ?? '');
    $phone       = trim($_POST['phone'] ?? '');
    $address     = trim($_POST['address'] ?? '');
    $city        = trim($_POST['city'] ?? '');
    $state       = trim($_POST['state'] ?? '');
    $country     = 'Uganda';
    $date_joined = $_POST['date_joined'] ?? date('Y-m-d');

    // Optional username & password provided by Admin
    $username_in = trim($_POST['username'] ?? '');
    $password_in = trim($_POST['password'] ?? '');

    // Validate basics
    if ($first === '') $errors[] = 'First name is required.';
    if ($last === '')  $errors[] = 'Last name is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
    if ($phone === '') $errors[] = 'Phone is required.';
    if ($address === '') $errors[] = 'Address is required.';
    if ($city === '') $errors[] = 'City is required.';
    if ($state === '') $state = '—';

    // Pre-check email unique
    if (!$errors) {
        $chkEmail = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
        $chkEmail->execute([$email]);
        if ($chkEmail->fetch()) {
            $errors[] = 'Email already exists on another account.';
        }
    }

    if (!$errors) {
        try {
            $pdo->beginTransaction();

            // 1) Username: supplied or auto-unique "first.last"
            if ($username_in !== '') {
                $check = $pdo->prepare("SELECT 1 FROM users WHERE username = ? LIMIT 1");
                $check->execute([$username_in]);
                if ($check->fetch()) {
                    throw new RuntimeException('The username you entered is already taken.');
                }
                $username = $username_in;
            } else {
                $base = strtolower(preg_replace('/\s+/', '', $first)) . '.' . strtolower(preg_replace('/\s+/', '', $last));
                $username = $base;
                $i = 1;
                $check = $pdo->prepare("SELECT 1 FROM users WHERE username = ? LIMIT 1");
                while (true) {
                    $check->execute([$username]);
                    if (!$check->fetch()) break;
                    $username = $base . $i++;
                }
            }

            // 2) Password: given or generated
            $plainPassword = ($password_in !== '') ? $password_in : randomPassword(10);
            $passwordHash  = password_hash($plainPassword, PASSWORD_DEFAULT);

            // 3) Insert into users (role=investor, active)
            $insUser = $pdo->prepare("
                INSERT INTO users (username, email, password, role, status)
                VALUES (?, ?, ?, 'investor', 'active')
            ");
            $insUser->execute([$username, $email, $passwordHash]);
            $userId = (int)$pdo->lastInsertId();

            // 4) Insert into investors, link user_id
            $account = nextAccountNo($pdo);
            $insInv = $pdo->prepare("
                INSERT INTO investors (user_id, account_number, first_name, last_name, phone, address, city, state, country, date_joined, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
            ");
            $insInv->execute([$userId, $account, $first, $last, $phone, $address, $city, $state, $country, $date_joined]);

            $pdo->commit();

            $success = [
                'account_number' => $account,
                'username'       => $username,
                'password'       => $plainPassword, // show once; investor should change after first login
            ];
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $msg = $e->getMessage();
            if (stripos($msg, 'Duplicate') !== false) {
                if (stripos($msg, 'username') !== false) $msg = 'Username already exists.';
                if (stripos($msg, 'email') !== false)    $msg = 'Email already exists.';
                if (stripos($msg, 'account_number') !== false) $msg = 'Account number conflict. Try again.';
            }
            $errors[] = 'Failed to save investor: ' . htmlspecialchars($msg);
        }
    }
}

/* ---------- Header / Layout ---------- */
$page_title = 'Add Investor';
include 'includes/header.php';
?>
<style>
  /* Scoped to this page so your global theme stays in control */
  .main-content :root{
    --brand:#2c5530; --brand-2:#4a7c59; --bg:#f5f7f5; --text:#1f2937; --muted:#6b7280;
    --card:#ffffff; --ring:#d1fae5;
  }
  .main-content .wrap{max-width:900px;margin:40px auto;padding:0 16px;}
  .main-content .card{background:var(--card);border-radius:14px;box-shadow:0 6px 24px rgba(0,0,0,.06);padding:24px;}
  .main-content h1{margin:0 0 16px;font-size:1.6rem}
  .main-content .grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
  .main-content label{display:block;font-size:.9rem;color:var(--muted);margin-bottom:6px}
  .main-content input,.main-content select,.main-content textarea{
    width:100%;padding:12px 14px;border:1px solid #e5e7eb;border-radius:10px;font-size:1rem;background:#fff;outline:none;
  }
  .main-content input:focus,.main-content select:focus,.main-content textarea:focus{box-shadow:0 0 0 4px var(--ring);border-color:var(--brand-2)}
  .main-content textarea{min-height:90px;resize:vertical}
  .main-content .actions{display:flex;gap:12px;justify-content:flex-end;margin-top:16px}
  .main-content .alert{padding:12px 14px;border-radius:10px;margin-bottom:12px}
  .main-content .alert-danger{background:#fee2e2;color:#7f1d1d}
  .main-content .alert-success{background:#dcfce7;color:#14532d}
  .main-content .badge{display:inline-block;background:var(--brand-2);color:gray;border-radius:999px;padding:4px 10px;font-size:.8rem}
  .main-content code{background:#eef2ff;border-radius:6px;padding:2px 6px}
  .main-content small{color:#374151}
  @media (max-width:720px){.main-content .grid{grid-template-columns:1fr}}
</style>

<div class="main-content">
  <div class="wrap">
    <div class="card">
      <h1>Add Investor</h1>

      <?php if ($errors): ?>
        <div class="alert alert-danger">
          <strong>There were problems:</strong>
          <ul><?php foreach($errors as $e) echo '<li>'.htmlspecialchars($e).'</li>'; ?></ul>
        </div>
      <?php endif; ?>

      <?php if ($success): ?>
        <div class="alert alert-success">
          <strong>Investor created successfully.</strong><br>
          <span class="badge">Account: <?=htmlspecialchars($success['account_number'])?></span><br><br>
          <strong>Login credentials (share with investor now):</strong><br>
          Username: <code><?=htmlspecialchars($success['username'])?></code><br>
          Password: <code><?=htmlspecialchars($success['password'])?></code><br>
          <small>Advise the investor to change the password after first login.</small>
        </div>

        <!-- Back links -->
        <div style="display:flex; gap:10px; margin-bottom:15px; flex-wrap:wrap;">
          <a href="dashboard.php" class="btn btn-secondary">← Back to Dashboard</a>
          <a href="investors.php" class="btn btn-primary">View Investors</a>
          <a href="add_investment.php" class="btn btn-primary">Record Investment</a>
        </div>
      <?php endif; ?>

      <form method="post" novalidate>
        <div class="grid">
          <div>
            <label>First name</label>
            <input name="first_name" required>
          </div>
          <div>
            <label>Last name</label>
            <input name="last_name" required>
          </div>
          <div>
            <label>Email</label>
            <input type="email" name="email" required>
          </div>
          <div>
            <label>Phone</label>
            <input name="phone" required>
          </div>

          <div>
            <label>City</label>
            <input name="city" required>
          </div>
          <div>
            <label>State/Region</label>
            <input name="state">
          </div>

          <div>
            <label>Date Joined</label>
            <input type="date" name="date_joined" value="<?=date('Y-m-d')?>" required>
          </div>
          <div>
            <label>Country</label>
            <span class="badge">UGANDA</span>
          </div>

          <div style="grid-column:1/-1">
            <label>Address</label>
            <textarea name="address" required></textarea>
          </div>

          <div style="grid-column:1/-1;border-top:1px dashed #e5e7eb;margin-top:6px;padding-top:12px">
            <strong>Login Details</strong> <small>(optional ! leave password empty to auto-generate)</small>
          </div>

          <div>
            <label>Username</label>
            <input name="username" placeholder="e.g. Aturinda Ronald">
          </div>
          <div>
            <label>Password</label>
            <input name="password" placeholder="Leave empty to auto-generate">
          </div>
        </div>

        <div class="actions">
          <button class="btn btn-secondary" type="reset">Clear</button>
          <button class="btn btn-primary" type="submit">Save Investor</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
