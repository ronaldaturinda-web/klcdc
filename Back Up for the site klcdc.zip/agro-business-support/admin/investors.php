<?php
// admin/investors.php
declare(strict_types=1);

/**
 * Investor Management (Admin)
 * National Agro Business Support Initiative
 * - Fixes PHP 8 number_format() type error (casts to float)
 * - Status modal: updates investor.status and mirrors to users.status (active/ inactive)
 * - Delete modal: deletes investments -> investor -> user in a single transaction
 * - Preserves your UI/markup
 */

require_once '../config/config.php';
require_once '../classes/Auth.php';
require_once '../classes/Investor.php';

// Auth gate
if (!isLoggedIn() || !isAdmin()) {
    redirect('../index.php');
}

$auth     = new Auth();
$investor = new Investor();

// Validate session
if (!$auth->validateSession()) {
    redirect('../index.php');
}

/** Try to obtain a PDO handle from your app — works with common patterns */
function resolvePDO(): ?PDO {
    if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) return $GLOBALS['pdo'];
    if (function_exists('getDbConnection')) { $p = getDbConnection(); if ($p instanceof PDO) return $p; }
    if (class_exists('Database')) {
        $db = new Database();
        if (method_exists($db, 'connect'))       { $p = $db->connect();       if ($p instanceof PDO) return $p; }
        if (method_exists($db, 'getConnection')) { $p = $db->getConnection(); if ($p instanceof PDO) return $p; }
    }
    return null; // safe fallback; actions still work via class methods
}

$pdo = resolvePDO();
if ($pdo instanceof PDO) {
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
}

/** Mirror investor.status -> users.status (active|inactive) when possible */
function mirror_user_status_if_possible(int $investor_id, string $investor_status): array {
    if (!isset($GLOBALS['pdo']) || !($GLOBALS['pdo'] instanceof PDO)) {
        // No direct DB access here, but the main update still succeeded.
        return ['success' => true, 'message' => '']; 
    }
    /** @var PDO $pdo */
    $pdo = $GLOBALS['pdo'];

    // Map anything not 'active' to 'inactive' to block login
    $userStatus = ($investor_status === 'active') ? 'active' : 'inactive';

    try {
        $q = $pdo->prepare("SELECT user_id FROM investors WHERE id = ? LIMIT 1");
        $q->execute([$investor_id]);
        $row = $q->fetch();
        if (!$row || empty($row['user_id'])) {
            return ['success' => true, 'message' => ''];
        }
        $uid = (int)$row['user_id'];

        $u = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
        $u->execute([$userStatus, $uid]);

        return ['success' => true, 'message' => ''];
    } catch (Throwable $e) {
        return ['success' => false, 'message' => ' (User status mirror failed)'];
    }
}

/** Transactional delete: investments -> investor -> user */
function transactional_delete_investor(int $investor_id): array {
    if (!isset($GLOBALS['pdo']) || !($GLOBALS['pdo'] instanceof PDO)) {
        return ['success' => false, 'message' => 'Database connection not available.'];
    }
    /** @var PDO $pdo */
    $pdo = $GLOBALS['pdo'];

    try {
        $pdo->beginTransaction();

        // Find linked user_id
        $q = $pdo->prepare("SELECT user_id FROM investors WHERE id = ? LIMIT 1");
        $q->execute([$investor_id]);
        $row = $q->fetch();
        if (!$row) {
            $pdo->rollBack();
            return ['success' => false, 'message' => 'Investor not found.'];
        }
        $uid = (int)$row['user_id'];

        // Delete child investments first (in case of RESTRICT FKs)
        $d1 = $pdo->prepare("DELETE FROM investments WHERE investor_id = ?");
        $d1->execute([$investor_id]);

        // Delete investor
        $d2 = $pdo->prepare("DELETE FROM investors WHERE id = ?");
        $d2->execute([$investor_id]);

        // Delete user
        $d3 = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $d3->execute([$uid]);

        $pdo->commit();
        return ['success' => true, 'message' => 'Investor deleted successfully.'];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        return ['success' => false, 'message' => 'Delete failed: ' . htmlspecialchars($e->getMessage())];
    }
}

/* ----------------------------- Actions ----------------------------- */
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $message = 'Invalid request. Please try again.';
        $message_type = 'error';
    } else {
        // Change Status action (modal)
        if (isset($_POST['update_status'])) {
            $investor_id = (int)($_POST['investor_id'] ?? 0);
            $status = sanitize_input($_POST['status'] ?? 'inactive'); // active | inactive | suspended

            // Update via your class method first
            $r = $investor->updateInvestorStatus($investor_id, $status);

            // Mirror to users.status when we can
            $m = mirror_user_status_if_possible($investor_id, $status);

            $ok = $r['success'] && $m['success'];
            $message = $r['message'] . (!$m['success'] ? ' (user mirror skipped)' : '');
            $message_type = $ok ? 'success' : 'error';
        }

        // Delete Investor action (modal)
        if (isset($_POST['delete_investor'])) {
            $investor_id = (int)($_POST['investor_id'] ?? 0);

            // Prefer our safe transactional delete (covers user + investments)
            $r = transactional_delete_investor($investor_id);

            $message = $r['message'];
            $message_type = $r['success'] ? 'success' : 'error';
        }
    }
}

/* ---------------------- Pagination + Search ------------------------ */
$page   = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$limit  = 20;
$offset = ($page - 1) * $limit;
$search = isset($_GET['search']) ? sanitize_input($_GET['search']) : '';

$investors        = $investor->getAllInvestors($limit, $offset, $search);
$total_investors  = $investor->getTotalInvestorsCount($search);
$total_pages      = (int)ceil(($total_investors ?: 0) / $limit);

$page_title = 'Investor Management';
include 'includes/header.php';
?>

<div class="main-content">
    <div class="page-header">
        <h1><i class="fas fa-users"></i> Investor Management</h1>
        <p class="text-muted">Manage all investor accounts and profiles</p>
    </div>

    <?php if (!empty($message)): ?>
        <div class="alert alert-<?php echo $message_type; ?>">
            <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <!-- Search and Actions -->
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div class="search-form" style="flex: 1; max-width: 400px;">
                    <form method="GET" action="">
                        <div class="form-group">
                            <div style="display: flex; gap: 0.5rem;">
                                <input type="text" name="search" class="form-control"
                                       placeholder="Search investors..."
                                       value="<?php echo htmlspecialchars($search); ?>">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search"></i>
                                </button>
                                <?php if (!empty($search)): ?>
                                    <a href="investors.php" class="btn btn-secondary" title="Clear">
                                        <i class="fas fa-times"></i>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="action-buttons">
                    <a href="add_investor.php" class="btn btn-success">
                        <i class="fas fa-user-plus"></i> Add New Investor
                    </a>
                    <button onclick="exportTableToCSV('investorsTable', 'investors.csv')" class="btn btn-info">
                        <i class="fas fa-download"></i> Export CSV
                    </button>
                </div>
            </div>

            <!-- Statistics -->
            <div class="row">
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="stat-number"><?php echo number_format((float)$total_investors); ?></div>
                        <div class="stat-label">Total Investors</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card success">
                        <div class="stat-number">
                            <?php
                            $active_count = 0;
                            foreach ($investors as $inv) { if (($inv['status'] ?? '') === 'active') $active_count++; }
                            echo number_format((float)$active_count);
                            ?>
                        </div>
                        <div class="stat-label">Active</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card warning">
                        <div class="stat-number">
                            <?php
                            $inactive_count = 0;
                            foreach ($investors as $inv) { if (($inv['status'] ?? '') === 'inactive') $inactive_count++; }
                            echo number_format((float)$inactive_count);
                            ?>
                        </div>
                        <div class="stat-label">Inactive</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card danger">
                        <div class="stat-number">
                            <?php
                            $suspended_count = 0;
                            foreach ($investors as $inv) { if (($inv['status'] ?? '') === 'suspended') $suspended_count++; }
                            echo number_format((float)$suspended_count);
                            ?>
                        </div>
                        <div class="stat-label">Suspended</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Investors Table -->
    <div class="card">
        <div class="card-body">
            <?php if (!empty($investors)): ?>
                <div class="table-responsive">
                    <table class="table data-table" id="investorsTable">
                        <thead>
                        <tr>
                            <th data-sortable="true">Account No.</th>
                            <th data-sortable="true">Name</th>
                            <th data-sortable="true">Phone</th>
                            <th data-sortable="true">Email</th>
                            <th>Location</th>
                            <th data-sortable="true">Investments</th>
                            <th data-sortable="true">Total Amount</th>
                            <th data-sortable="true">Status</th>
                            <th data-sortable="true">Date Joined</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($investors as $inv): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars((string)$inv['account_number']); ?></strong>
                                </td>
                                <td>
                                    <div>
                                        <strong><?php echo htmlspecialchars((string)$inv['first_name'] . ' ' . (string)$inv['last_name']); ?></strong><br>
                                        <small class="text-muted">@<?php echo htmlspecialchars((string)$inv['username']); ?></small>
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars((string)$inv['phone']); ?></td>
                                <td>
                                    <a href="mailto:<?php echo htmlspecialchars((string)$inv['email']); ?>">
                                        <?php echo htmlspecialchars((string)$inv['email']); ?>
                                    </a>
                                </td>
                                <td><?php echo htmlspecialchars((string)$inv['city'] . ', ' . (string)$inv['state']); ?></td>
                                <td>
                                    <span class="badge badge-info">
                                        <?php echo number_format((float)$inv['total_investments']); ?>
                                    </span>
                                </td>
                                <td>
                                    <strong><?php echo formatCurrency((float)$inv['total_amount']); ?></strong>
                                </td>
                                <td>
                                    <span class="badge badge-<?php
                                        $st = (string)($inv['status'] ?? 'inactive');
                                        echo $st === 'active' ? 'success' : ($st === 'inactive' ? 'warning' : 'danger');
                                    ?>">
                                        <?php echo ucfirst($st); ?>
                                    </span>
                                </td>
                                <td><?php echo formatDate((string)$inv['date_joined'], 'd/m/Y'); ?></td>
                                <td>
                                    <div class="btn-group">
                                        <a href="investor_details.php?id=<?php echo (int)$inv['id']; ?>"
                                           class="btn btn-sm btn-info" title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="edit_investor.php?id=<?php echo (int)$inv['id']; ?>"
                                           class="btn btn-sm btn-warning" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button type="button" class="btn btn-sm btn-secondary"
                                                onclick="showStatusModal(<?php echo (int)$inv['id']; ?>, '<?php echo htmlspecialchars($st); ?>')"
                                                title="Change Status">
                                            <i class="fas fa-toggle-on"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-danger"
                                                onclick="showDeleteModal(<?php echo (int)$inv['id']; ?>, '<?php echo htmlspecialchars((string)$inv['first_name'] . ' ' . (string)$inv['last_name']); ?>')"
                                                title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <nav aria-label="Investors pagination">
                        <ul class="pagination">
                            <?php if ($page > 1): ?>
                                <li><a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>">&laquo; Previous</a></li>
                            <?php endif; ?>

                            <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                                <li class="<?php echo $i === $page ? 'active' : ''; ?>">
                                    <?php if ($i === $page): ?>
                                        <span><?php echo $i; ?></span>
                                    <?php else: ?>
                                        <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
                                    <?php endif; ?>
                                </li>
                            <?php endfor; ?>

                            <?php if ($page < $total_pages): ?>
                                <li><a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>">Next &raquo;</a></li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>

            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-users fa-4x text-muted mb-3"></i>
                    <h4>No investors found</h4>
                    <?php if (!empty($search)): ?>
                        <p class="text-muted">No investors match your search criteria.</p>
                        <a href="investors.php" class="btn btn-secondary">Clear Search</a>
                    <?php else: ?>
                        <p class="text-muted">Start by adding your first investor.</p>
                        <a href="add_investor.php" class="btn btn-primary">
                            <i class="fas fa-user-plus"></i> Add First Investor
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Status Modal -->
<div id="statusModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:1000;">
    <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);background:#fff;padding:2rem;border-radius:.5rem;min-width:400px;">
        <h4>Change Investor Status</h4>
        <form method="POST" action="">
            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
            <input type="hidden" name="investor_id" id="statusInvestorId">

            <div class="form-group">
                <label for="status">Status:</label>
                <select name="status" id="statusSelect" class="form-control" required>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                    <option value="suspended">Suspended</option>
                </select>
            </div>

            <div class="d-flex justify-content-end gap-2">
                <button type="button" onclick="hideStatusModal()" class="btn btn-secondary">Cancel</button>
                <button type="submit" name="update_status" class="btn btn-primary">Update Status</button>
            </div>
        </form>
    </div>
</div>

<!-- Delete Modal -->
<div id="deleteModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:1000;">
    <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);background:#fff;padding:2rem;border-radius:.5rem;min-width:400px;">
        <h4 class="text-danger">Delete Investor</h4>
        <p>Are you sure you want to delete <strong id="deleteInvestorName"></strong>?</p>
        <p class="text-warning"><i class="fas fa-exclamation-triangle"></i> This action cannot be undone and will also delete their user account.</p>

        <form method="POST" action="">
            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
            <input type="hidden" name="investor_id" id="deleteInvestorId">

            <div class="d-flex justify-content-end gap-2">
                <button type="button" onclick="hideDeleteModal()" class="btn btn-secondary">Cancel</button>
                <button type="submit" name="delete_investor" class="btn btn-danger">
                    <i class="fas fa-trash"></i> Delete Investor
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Status modal
function showStatusModal(investorId, currentStatus) {
    document.getElementById('statusInvestorId').value = investorId;
    document.getElementById('statusSelect').value = currentStatus || 'inactive';
    document.getElementById('statusModal').style.display = 'block';
}
function hideStatusModal() {
    document.getElementById('statusModal').style.display = 'none';
}

// Delete modal
function showDeleteModal(investorId, investorName) {
    document.getElementById('deleteInvestorId').value = investorId;
    document.getElementById('deleteInvestorName').textContent = investorName || '';
    document.getElementById('deleteModal').style.display = 'block';
}
function hideDeleteModal() {
    document.getElementById('deleteModal').style.display = 'none';
}

// Click outside closes
document.getElementById('statusModal').addEventListener('click', function(e) {
    if (e.target === this) hideStatusModal();
});
document.getElementById('deleteModal').addEventListener('click', function(e) {
    if (e.target === this) hideDeleteModal();
});
// Escape closes
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') { hideStatusModal(); hideDeleteModal(); }
});

// CSV export (kept simple)
function exportTableToCSV(tableId, filename) {
    const rows = Array.from(document.querySelectorAll('#' + tableId + ' tr'));
    const csv = rows.map(row => {
        const cells = Array.from(row.querySelectorAll('th,td'));
        return cells.map(c => {
            const t = (c.innerText || '').replace(/\s+\n/g,' ').replace(/\n/g,' ').trim();
            const needsQuotes = /[",\n]/.test(t);
            return needsQuotes ? '"' + t.replace(/"/g,'""') + '"' : t;
        }).join(',');
    }).join('\n');

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename || 'export.csv');
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}
</script>

<?php include 'includes/footer.php'; ?>
