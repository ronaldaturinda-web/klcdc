<?php
/**
 * Admin Logout
 * National Agro Business Support Initiative
 */

require_once '../config/config.php';
require_once '../classes/Auth.php';

$auth = new Auth();

// Logout user
$auth->logout();

// Redirect to login page
redirect('../index.php');
?>
