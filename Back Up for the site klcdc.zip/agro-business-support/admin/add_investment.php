<?php
// admin/add_investment.php
declare(strict_types=1);
session_start();

/**
 * Record Investment (Admin) — same functionality, themed with header + left menu + footer
 * - Select investor, enter type/amount/notes/date
 * - Saves to DB, then shows Download Receipt (PDF) + Back links
 * - Receipt (TCPDF) has brand header bar, neat info blocks, QR code, and signature line
 */

require_once __DIR__ . '/../config/config.php';   // brings helpers + includes database.php
require_once __DIR__ . '/../classes/Auth.php';

// Gate (consistent with other admin pages)
if (!isLoggedIn() || !isAdmin()) {
    redirect('../index.php');
}
$auth = new Auth();
if (!$auth->validateSession()) {
    redirect('../index.php');
}

/** Resolve PDO from the patterns your project uses */
function resolvePDO(): PDO {
    if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) return $GLOBALS['pdo'];
    if (function_exists('getDbConnection')) { $p = getDbConnection(); if ($p instanceof PDO) return $p; }
    if (class_exists('Database')) {
        $db = new Database();
        if (method_exists($db,'connect'))       { $p = $db->connect();       if ($p instanceof PDO) return $p; }
        if (method_exists($db,'getConnection')) { $p = $db->getConnection(); if ($p instanceof PDO) return $p; }
    }
    throw new RuntimeException('Could not obtain a PDO connection from config/database.php');
}

try {
    $pdo = resolvePDO();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    http_response_code(500);
    die('Database connection error: ' . htmlspecialchars($e->getMessage()));
}

/** TCPDF loader (robust) */
function tryIncludeTCPDF(): bool {
    $candidates = [
        __DIR__ . '/../vendor/tcpdf/tcpdf.php',
        __DIR__ . '/../tcpdf_min/tcpdf.php',
        __DIR__ . '/../tcpdf.php',
    ];
    foreach ($candidates as $p) {
        if (is_readable($p)) {
            if (!defined('K_PATH_CACHE')) {
                $cache = realpath(__DIR__ . '/../temp');
                if (!$cache) { @mkdir(__DIR__ . '/../temp', 0775, true); $cache = __DIR__ . '/../temp'; }
                define('K_PATH_CACHE', rtrim($cache, '/\\') . DIRECTORY_SEPARATOR);
            }
            require_once $p;
            return true;
        }
    }
    return false;
}

/** Helpers */
function genId(string $prefix): string {
    // e.g., TXN20250813-102530-4831
    return sprintf('%s%s-%s-%04d', $prefix, date('Ymd'), date('His'), random_int(1000, 9999));
}
function moneyUGX(float $amount): string { return 'UGX ' . number_format($amount, 0, '.', ','); }
function loadInvestors(PDO $pdo): array {
    $sql = "SELECT id, account_number, first_name, last_name
            FROM investors
            WHERE status='active'
            ORDER BY first_name, last_name";
    return $pdo->query($sql)->fetchAll();
}
function fetchInvestment(PDO $pdo, int $id): ?array {
    $sql = "SELECT inv.id, inv.transaction_id, inv.receipt_number, inv.investment_type, inv.amount, inv.description,
                   inv.investment_date, inv.recorded_by,
                   i.account_number, i.first_name, i.last_name, i.phone,
                   u.email
            FROM investments inv
            JOIN investors i ON inv.investor_id = i.id
            LEFT JOIN users u ON inv.recorded_by = u.id
            WHERE inv.id = ?";
    $st = $pdo->prepare($sql);
    $st->execute([$id]);
    $row = $st->fetch();
    return $row ?: null;
}

/** Inline SVG icons for types (used in success badges) */
function typeIcon(string $type, int $size = 18): string {
    $s = $size;
    switch (strtolower($type)) {
        case 'cash':
            return "<svg width='{$s}' height='{$s}' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'>
                <rect x='3' y='6' width='18' height='12' rx='2' stroke='#2c5530' stroke-width='1.7'/>
                <circle cx='12' cy='12' r='3' stroke='#2c5530' stroke-width='1.7'/>
            </svg>";
        case 'material':
            return "<svg width='{$s}' height='{$s}' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'>
                <path d='M12 3L3 9l9 6 9-6-9-6Z' stroke='#2c5530' stroke-width='1.7'/>
                <path d='M3 15l9 6 9-6' stroke='#2c5530' stroke-width='1.7'/>
            </svg>";
        case 'labor':
        default:
            return "<svg width='{$s}' height='{$s}' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'>
                <path d='M7 7l10 10M7 17L17 7' stroke='#2c5530' stroke-width='1.7'/>
                <circle cx='6' cy='6' r='2' stroke='#2c5530' stroke-width='1.7'/>
                <circle cx='18' cy='18' r='2' stroke='#2c5530' stroke-width='1.7'/>
            </svg>";
    }
}

/** Professional-looking receipt (brand bar, info blocks, QR, signature) */
function outputReceiptPDF(array $data): void {
    if (!tryIncludeTCPDF()) {
        header('Content-Type: text/plain; charset=utf-8');
        echo "TCPDF not found. Put it in vendor/tcpdf/ (or tcpdf_min/).";
        exit;
    }
    while (ob_get_level()) { ob_end_clean(); }

    $receiptNo = $data['receipt_number'];
    $pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);
    $pdf->SetCreator('National Agro Business Support Initiative');
    $pdf->SetAuthor('National Agro Business Support Initiative');
    $pdf->SetTitle("Receipt {$receiptNo}");
    $pdf->SetMargins(12, 12, 12);
    $pdf->SetAutoPageBreak(true, 14);
    $pdf->AddPage();
    $pdf->SetFont('helvetica', '', 11);

    // Brand header bar
    $pdf->SetFillColor(44, 85, 48); // #2c5530
    $pdf->Rect(12, 12, 186, 16, 'F');
    $pdf->SetTextColor(255,255,255);
    $pdf->SetFont('helvetica', 'B', 14);
    $pdf->SetXY(16, 15);
    $pdf->Write(8, 'National Agro Business Support Initiative');

    $pdf->SetFont('helvetica', '', 11);
    $pdf->SetXY(16, 23);
    $pdf->Write(6, 'Investment Receipt');

    $pdf->Ln(14);
    $pdf->SetTextColor(0,0,0);

    $fullName = $data['first_name'] . ' ' . $data['last_name'];
    $account  = $data['account_number'];
    $type     = strtoupper($data['investment_type']);
    $amount   = moneyUGX((float)$data['amount']);
    $dt       = date('d M Y, H:i', strtotime($data['investment_date']));
    $txn      = $data['transaction_id'];
    $desc     = (string)$data['description'];

    $html = <<<HTML
<style>
  .box { border:1px solid #e6e8ec; border-radius:8px; padding:10px; }
  .label { color:#666; font-size:10px; text-transform:uppercase; letter-spacing:.02em; }
  .value { font-size:12px; }
</style>
<table cellspacing="4" cellpadding="0" width="100%">
  <tr>
    <td width="60%" class="box">
      <div class="label">Investor</div>
      <div class="value"><strong>{$fullName}</strong></div>
      <div class="label" style="margin-top:6px;">Account Number</div>
      <div class="value">{$account}</div>
      <div class="label" style="margin-top:6px;">Type</div>
      <div class="value">{$type}</div>
    </td>
    <td width="40%" class="box">
      <div class="label">Receipt No.</div>
      <div class="value"><strong>{$receiptNo}</strong></div>
      <div class="label" style="margin-top:6px;">Transaction ID</div>
      <div class="value">{$txn}</div>
      <div class="label" style="margin-top:6px;">Date</div>
      <div class="value">{$dt}</div>
    </td>
  </tr>
</table>
HTML;
    $pdf->writeHTML($html, true, false, true, false, '');

    $html2 = <<<HTML
<table cellspacing="4" cellpadding="0" width="100%" style="margin-top:4px;">
  <tr>
    <td class="box" width="60%">
      <div class="label">Amount</div>
      <div class="value" style="font-size:14px;"><strong>{$amount}</strong></div>
    </td>
    <td class="box" width="40%">
      <div class="label">Recorded By (User ID)</div>
      <div class="value">{$data['recorded_by']}</div>
    </td>
  </tr>
</table>

<div class="box" style="margin-top:6px;">
  <div class="label">Description</div>
  <div class="value">{$desc}</div>
</div>
HTML;
    $pdf->writeHTML($html2, true, false, true, false, '');

    // QR
    $qrData = "Receipt: {$receiptNo}\nTXN: {$txn}\nAcct: {$account}\nInvestor: {$fullName}\nAmount: {$amount}\nDate: {$dt}\nType: {$type}";
    $x = 150; $y = $pdf->GetY() + 4;
    $pdf->write2DBarcode($qrData, 'QRCODE,H', $x, $y, 40, 40);

    // Signature
    $pdf->Ln(44);
    $pdf->writeHTML('<br><br><div style="width:50%;border-top:1px solid #444;padding-top:4px;">Authorized Signature</div>', true, false, true, false, '');

    // Footer note
    $pdf->Ln(2);
    $pdf->SetTextColor(90,90,90);
    $pdf->SetFont('helvetica', '', 9);
    $pdf->writeHTML('<div style="text-align:right;">Thank you for your investment.</div>', true, false, true, false, '');

    $pdf->Output("Receipt_{$receiptNo}.pdf", 'I');
    exit;
}

/* ---------- Handle "Download Receipt" (before any HTML output) ---------- */
if (isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'receipt') {
    $id = (int)$_GET['id'];
    $investment = fetchInvestment($pdo, $id);
    if (!$investment) { http_response_code(404); echo "Receipt not found."; exit; }
    outputReceiptPDF($investment);
}

/* ---------- Handle POST (create investment) ---------- */
$errors = [];
$success = null;
$investors = loadInvestors($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $investorId = (int)($_POST['investor_id'] ?? 0);
    $type       = strtolower(trim($_POST['investment_type'] ?? ''));
    $amountRaw  = trim($_POST['amount'] ?? '');
    $amount     = is_numeric($amountRaw) ? (float)$amountRaw : -1;
    $desc       = trim($_POST['description'] ?? '');
    $dateStr    = trim($_POST['investment_date'] ?? '');
    $recordedBy = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 1;

    if ($investorId <= 0) $errors[] = 'Please select an investor.';
    if (!in_array($type, ['cash','material','labor'], true)) $errors[] = 'Choose a valid investment type.';
    if ($amount <= 0) $errors[] = 'Enter a valid amount above 0 (for material/labor, use estimated UGX value).';
    if ($dateStr === '') $dateStr = date('Y-m-d\TH:i');
    $dt = date('Y-m-d H:i:s', strtotime($dateStr));

    if (!$errors) {
        try {
            $pdo->beginTransaction();
            $txnId = genId('TXN');
            $rcpNo = genId('RCP');
            $sql = "INSERT INTO investments
                        (investor_id, transaction_id, investment_type, amount, description, investment_date, receipt_number, recorded_by, status)
                    VALUES
                        (?,?,?,?,?,?,?,?, 'confirmed')";
            $st = $pdo->prepare($sql);
            $st->execute([$investorId, $txnId, $type, $amount, $desc, $dt, $rcpNo, $recordedBy]);
            $newId = (int)$pdo->lastInsertId();
            $pdo->commit();

            $success = [
                'id' => $newId,
                'transaction_id' => $txnId,
                'receipt_number' => $rcpNo,
                'amount' => $amount,
                'type' => $type
            ];
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $msg = $e->getMessage();
            if (stripos($msg,'Duplicate')!==false) {
                if (stripos($msg,'transaction_id')!==false) $msg = 'Duplicate Transaction ID. Please submit again.';
                if (stripos($msg,'receipt_number')!==false)  $msg = 'Duplicate Receipt Number. Please submit again.';
            }
            $errors[] = 'Failed to record investment: ' . htmlspecialchars($msg);
        }
    }
}

/* ---------- Header / Layout (standard admin chrome) ---------- */
$page_title = 'Record Investment';
include 'includes/header.php';
?>
<style>
  /* Scoped styles so they don’t override your global theme */
  .main-content :root{
    --brand:#2c5530; --brand-2:#4a7c59; --bg:#f6f8f6; --text:#1f2937; --muted:#6b7280;
    --card:#ffffff; --border:#e8edf1; --ring:#d1fae5; --shadow:0 10px 30px rgba(0,0,0,.08);
  }
  .main-content .wrap{max-width:980px;margin:28px auto;padding:0 16px}
  .main-content .card{background:var(--card);border-radius:16px;box-shadow:var(--shadow);border:1px solid var(--border);padding:22px}
  .main-content h1{margin:0 0 14px;font-size:1.5rem}
  .main-content .grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
  .main-content label{display:block;font-size:.9rem;color:var(--muted);margin-bottom:6px}
  .main-content input,.main-content select,.main-content textarea{width:100%;padding:12px 14px;border:1px solid var(--border);border-radius:12px;background:#fff;font-size:1rem;outline:none}
  .main-content input:focus,.main-content select:focus,.main-content textarea:focus{box-shadow:0 0 0 4px var(--ring);border-color:var(--brand-2)}
  .main-content textarea{min-height:90px;resize:vertical}
  .main-content .actions{display:flex;gap:12px;justify-content:flex-end;margin-top:16px}
  
  .main-content .alert{padding:12px 14px;border-radius:12px;margin-bottom:12px;border:1px solid var(--border);box-shadow:0 1px 4px rgba(0,0,0,.06)}
  .main-content .alert-danger{background:#fff5f5;color:#7f1d1d}
  .main-content .alert-success{background:#eefaf1;color:#14532d}
  .main-content .badge{display:inline-flex;align-items:center;gap:6px;background:#eef5ef;color:#2c5530;border-radius:999px;padding:4px 10px;font-size:.8rem;border:1px solid #dce9de}
  .main-content .row-actions{display:flex;gap:12px;margin-bottom:15px}
  @media (max-width:720px){.main-content .grid{grid-template-columns:1fr}}
</style>

<div class="main-content">
  <div class="wrap">
    <div class="card">
      <h1>Record Investment</h1>

      <?php if ($errors): ?>
        <div class="alert alert-danger">
          <strong>There were problems:</strong>
          <ul><?php foreach($errors as $e) echo '<li>'.htmlspecialchars($e).'</li>'; ?></ul>
        </div>
      <?php endif; ?>

      <?php if ($success): ?>
        <div class="alert alert-success">
          <strong>Investment recorded successfully.</strong><br>
          <span class="badge"><?=typeIcon($success['type'],14)?> <?=strtoupper(htmlspecialchars($success['type']))?></span>
          <span class="badge"><?=moneyUGX((float)$success['amount'])?></span>
          <span class="badge">Receipt: <?=htmlspecialchars($success['receipt_number'])?></span>
          <span class="badge">TXN: <?=htmlspecialchars($success['transaction_id'])?></span>
        </div>
        <div class="row-actions">
<a class="btn btn-primary"
   href="../print_receipt.php?investment_id=<?= (int)$success['id'] ?>&action=download"
   target="_blank" rel="noopener">
  Download Receipt (PDF)
</a>

          <a class="btn btn-secondary" href="dashboard.php">← Back to Dashboard</a>
          <a class="btn btn-secondary" href="investments.php">View All Investments</a>
        </div>
      <?php endif; ?>

      <form method="post" novalidate>
        <div class="grid">
          <div>
            <label>Investor</label>
            <select name="investor_id" required>
              <option value="">-- Select investor --</option>
              <?php foreach ($investors as $inv): ?>
              <option value="<?=$inv['id']?>">
                <?=htmlspecialchars($inv['account_number'])?> — <?=htmlspecialchars($inv['first_name'].' '.$inv['last_name'])?>
              </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div>
            <label>Investment Type</label>
            <select name="investment_type" required>
              <option value="">-- Select type --</option>
              <option value="cash">Cash</option>
              <option value="material">Material</option>
              <option value="labor">Labor</option>
            </select>
          </div>

          <div>
            <label>Amount (UGX)</label>
            <input type="number" name="amount" min="1" step="1" placeholder="e.g. 250000" required>
          </div>

          <div>
            <label>Investment Date & Time</label>
            <input type="datetime-local" name="investment_date" value="<?=date('Y-m-d\TH:i')?>" required>
          </div>

          <div style="grid-column:1 / -1">
            <label>Description (optional)</label>
            <textarea name="description" placeholder="Short note (e.g., cash deposit, equipment provided, man-hours, etc.)"></textarea>
          </div>
        </div>

        <div class="actions">
          <a class="btn btn-secondary" href="dashboard.php">Cancel</a>
          <button class="btn btn-primary" type="submit">Save Investment</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
