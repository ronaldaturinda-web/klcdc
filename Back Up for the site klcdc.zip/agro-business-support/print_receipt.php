<?php
// print_receipt.php — KLCDC receipt (logo watermark, credit row, no-outline description,
// dashed "Received by / Signature" lines). Place this at the project root.
declare(strict_types=1);
session_start();

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/classes/Auth.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect('index.php');
}
$auth = new Auth();
if (!$auth->validateSession()) {
    redirect('index.php');
}

/* ---------- DB Connection (compatible with your project) ---------- */
function resolvePDO(): PDO {
    if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) return $GLOBALS['pdo'];
    if (function_exists('getDbConnection')) { $p = getDbConnection(); if ($p instanceof PDO) return $p; }
    if (class_exists('Database')) {
        $db = new Database();
        if (method_exists($db,'connect'))       { $p = $db->connect();       if ($p instanceof PDO) return $p; }
        if (method_exists($db,'getConnection')) { $p = $db->getConnection(); if ($p instanceof PDO) return $p; }
    }
    throw new RuntimeException('Could not obtain a PDO connection from config/database.php');
}
$pdo = resolvePDO();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

/* ---------- TCPDF ---------- */
function tryIncludeTCPDF(): bool {
    $candidates = [
        __DIR__ . '/vendor/tcpdf/tcpdf.php',
        __DIR__ . '/tcpdf_min/tcpdf.php',
        __DIR__ . '/tcpdf.php',
    ];
    foreach ($candidates as $p) {
        if (is_readable($p)) {
            if (!defined('K_PATH_CACHE')) {
                $cache = realpath(__DIR__ . '/temp');
                if (!$cache) { @mkdir(__DIR__ . '/temp', 0775, true); $cache = __DIR__ . '/temp'; }
                define('K_PATH_CACHE', rtrim($cache, '/\\') . DIRECTORY_SEPARATOR);
            }
            require_once $p;
            return true;
        }
    }
    return false;
}

/* ---------- Helpers ---------- */
function moneyUGX(float $amount): string {
    return 'UGX.' . number_format($amount, 0, '.', ',');
}
function fetchReceiptData(PDO $pdo, array $where): ?array {
    $sql = "SELECT inv.id, inv.transaction_id, inv.receipt_number, inv.investment_type, inv.amount,
                   inv.description, inv.investment_date, inv.recorded_by, inv.investor_id,
                   i.account_number, i.first_name, i.last_name, i.phone, i.address, i.city, i.state
            FROM investments inv
            JOIN investors i ON inv.investor_id = i.id
            WHERE {$where['clause']}
            LIMIT 1";
    $st = $pdo->prepare($sql);
    $st->execute($where['params']);
    $row = $st->fetch();
    return $row ?: null;
}
/* Resolve logo from root (supports image files; also tries logo.php URL if present) */
function resolveLogoSrc(): ?string {
    $cands = ['logo.png','logo.jpeg','logo.jpg','logo.ico','logo.php'];
    foreach ($cands as $fn) {
        $path = __DIR__ . '/' . $fn;
        if (@is_file($path)) {
            $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
            if ($ext === 'php') {
                $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
                $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
                return $scheme . '://' . $host . '/' . $fn; // only works if logo.php outputs an image
            }
            return $path;
        }
    }
    return null;
}

/* ---------- Inputs ---------- */
$investmentId  = isset($_GET['investment_id']) ? (int)$_GET['investment_id'] : 0;
$receiptNumber = isset($_GET['receipt_number']) ? trim((string)$_GET['receipt_number']) : '';
$action        = strtolower($_GET['action'] ?? 'download'); // 'download' | 'inline'

if ($investmentId > 0) {
    $where = ['clause' => 'inv.id = ?', 'params' => [$investmentId]];
} elseif ($receiptNumber !== '') {
    $where = ['clause' => 'inv.receipt_number = ?', 'params' => [$receiptNumber]];
} else {
    http_response_code(400);
    exit('Missing investment_id or receipt_number');
}

$data = fetchReceiptData($pdo, $where);
if (!$data) {
    http_response_code(404);
    exit('Receipt not found');
}

/* ---------- Organization meta ---------- */
$ORG_NAME  = "KLCDC - Kaliro Lords' Community Development Corporation";
$ORG_ADDR  = "Kaliro District, Uganda";
$ORG_PHONE = "+256-777-XXXXXXX";
$ORG_EMAIL = "info@klcdc.or.ug";
$LOGO_SRC  = resolveLogoSrc();

/* ---------- Build PDF ---------- */
if (!tryIncludeTCPDF()) {
    header('Content-Type: text/plain; charset=utf-8');
    exit("TCPDF not found. Put it in vendor/tcpdf/ (or tcpdf_min/).");
}

/* Clean any prior output to avoid header issues */
while (ob_get_level()) { ob_end_clean(); }

$pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);
$pdf->SetCreator($ORG_NAME);
$pdf->SetAuthor($ORG_NAME);
$pdf->SetTitle("Receipt " . $data['receipt_number']);
$pdf->SetMargins(12, 20, 12);
$pdf->SetAutoPageBreak(true, 18);
$pdf->AddPage();
$pdf->SetFont('helvetica', '', 11);

/* ---------- LOGO WATERMARK (large, centered, soft) ---------- */
if ($LOGO_SRC) {
    $pageW = $pdf->getPageWidth()  - 24;      // 12mm margins each side
    $wmW   = $pageW * 0.62;                   // balanced scale
    $wmX   = ($pdf->getPageWidth()  - $wmW) / 2;
    $wmY   = ($pdf->getPageHeight() - ($wmW * 0.9)) / 2; // visually centered

    $pdf->SetAlpha(0.06);
    $pdf->Image($LOGO_SRC, $wmX, $wmY, $wmW, 0, '', '', '', false, 300, '', false, false, 0, false, false, false);
    $pdf->SetAlpha(1);
}

/* ---------- Header strip with small logo + org name ---------- */
$barY = 12;
$pdf->SetFillColor(44, 85, 48); // #2c5530
$pdf->Rect(12, $barY, 186, 14, 'F');
if ($LOGO_SRC) {
    $pdf->Image($LOGO_SRC, 14, $barY + 1.5, 10, 0, '', '', '', false, 300);
}
$pdf->SetTextColor(255,255,255);
$pdf->SetFont('helvetica', 'B', 12);
$pdf->SetXY(27, $barY + 3.5);
$pdf->Cell(0, 6, $ORG_NAME, 0, 1, 'L');

$pdf->Ln(6);
$pdf->SetTextColor(0,0,0);

/* ---------- Vars ---------- */
$fullName = trim($data['first_name'] . ' ' . $data['last_name']);
$account  = $data['account_number'];
$type     = ucfirst((string)$data['investment_type']);
$amount   = (float)$data['amount'];
$amountTx = moneyUGX($amount);
$dt       = date('d M Y H:i', strtotime($data['investment_date']));
$txn      = $data['transaction_id'];
$rcp      = $data['receipt_number'];

/* ---------- Left contact, right meta ---------- */
$leftX = 12;
$y     = $pdf->GetY();
$pdf->SetXY($leftX, $y);
$pdf->SetFont('helvetica', '', 10);
$pdf->MultiCell(90, 5, implode("\n", [
    $ORG_ADDR,
    $ORG_PHONE,
    $ORG_EMAIL,
]), 0, 'L', false, 1);

$pdf->SetFont('helvetica', '', 9);
$rightX = 110; $y0 = $y;
$meta = [
    ['Receipt No:', $rcp],
    ['Date:', $dt],
    ['Account #:', $account],
    ['Type:', $type],
];
foreach ($meta as $i => [$label, $val]) {
    $pdf->SetXY($rightX, $y0 + ($i * 6));
    $pdf->Cell(28, 6, $label, 0, 0, 'L');
    $pdf->SetFont('helvetica', 'B', 10);
    $pdf->Cell(0, 6, $val, 0, 1, 'L');
    $pdf->SetFont('helvetica', '', 9);
}
$pdf->Ln(3);

/* ---------- Table: Investor | Amount ---------- */
$pdf->SetFillColor(230, 241, 235);
$pdf->SetDrawColor(120, 130, 120);
$pdf->SetLineWidth(0.3);
$pdf->SetFont('helvetica', 'B', 10);

$colInvestorW = 120;
$colAmountW   = 66;

$pdf->Cell($colInvestorW, 9, 'Investor', 1, 0, 'L', true);
$pdf->Cell($colAmountW,   9, 'Amount',   1, 1, 'L', true);

$pdf->SetFont('helvetica', '', 10);
$pdf->Cell($colInvestorW, 9, $fullName, 1, 0, 'L');
$pdf->Cell($colAmountW,   9, $amountTx, 1, 1, 'L');

/* ---------- Credit (full row, manual) ---------- */
$pdf->SetFont('helvetica', 'B', 10);
$pdf->SetFillColor(245, 245, 245);
$pdf->Cell(186, 8, 'Credit:', 1, 1, 'L', true);
$pdf->SetFont('helvetica', '', 10);
$pdf->Cell(186, 10, '', 1, 1, 'L');  // empty, to write in later

/* ---------- Description (no outline) ---------- */
if (!empty($data['description'])) {
    $pdf->Ln(2);
    $pdf->SetFont('helvetica', 'B', 10);
    $pdf->Cell(0, 6, 'Description', 0, 1, 'L');      // label only
    $pdf->SetFont('helvetica', '', 10);
    $pdf->MultiCell(186, 6, (string)$data['description'], 0, 'L'); // no border
}

/* ---------- Received by / Signature dashed lines (fixed) ---------- */
$pdf->Ln(8);
$ySig = $pdf->GetY();                  // anchor BEFORE drawing

$pdf->SetDrawColor(120,130,120);
// dashed style
$pdf->SetLineStyle([
    'width' => 0.3,
    'cap'   => 'butt',
    'join'  => 'miter',
    'dash'  => '2,2',
    'color' => [120,130,120],
]);
// draw lines
$pdf->Line(12,  $ySig + 10, 100, $ySig + 10);  // Received by line
$pdf->Line(116, $ySig + 10, 198, $ySig + 10);  // Signature line
// reset to solid
$pdf->SetLineStyle([
    'width' => 0.3,
    'cap'   => 'butt',
    'join'  => 'miter',
    'dash'  => 0,
    'color' => [120,130,120],
]);

$pdf->SetFont('helvetica', '', 9);
$pdf->SetXY(12,  $ySig);
$pdf->Cell(88, 6, 'Received by (Name):', 0, 0, 'L');
$pdf->SetXY(116, $ySig);
$pdf->Cell(82, 6, 'Signature:',          0, 1, 'L');

/* ---------- QR bottom-right + hint ---------- */
$qrData = json_encode([
    'org'      => $ORG_NAME,
    'receipt'  => $rcp,
    'txn'      => $txn,
    'account'  => $account,
    'investor' => $fullName,
    'amount'   => $amount,
    'currency' => 'UGX',
    'type'     => $type,
    'date'     => $dt,
    'ver'      => '1.0',
], JSON_UNESCAPED_SLASHES);

$qrSize = 34;
$qrX = 12 + 186 - $qrSize; // right within margins
$qrY = max($pdf->GetY() + 8, 190);
$pdf->write2DBarcode($qrData, 'QRCODE,H', $qrX, $qrY, $qrSize, $qrSize, [
    'border'  => 0,
    'padding' => 0,
    'fgcolor' => [0,0,0],
    'bgcolor' => false
], 'N');

$pdf->SetFont('helvetica', '', 8);
$pdf->SetXY($qrX, $qrY + $qrSize + 1.5);
$pdf->MultiCell($qrSize, 5, "Scan to verify", 0, 'C');

/* ---------- Footer note ---------- */
$pdf->Ln(8);
$pdf->SetFont('helvetica', '', 9);
$pdf->SetTextColor(70,70,70);
$pdf->MultiCell(0, 6, "Thank you for your investment. Please keep this receipt for your records.", 0, 'L');

/* ---------- Output ---------- */
$mode = ($action === 'inline') ? 'I' : 'D'; // I = inline, D = download
$pdf->Output("Receipt_{$rcp}.pdf", $mode);
exit;
