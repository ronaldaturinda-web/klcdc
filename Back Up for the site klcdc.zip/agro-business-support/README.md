# National Agro Business Support Initiative

A complete PHP web application for managing agricultural business investments with investor portfolio management, investment tracking, and automated reporting.

## Features

### Admin Panel
- **Dashboard**: Overview statistics and charts
- **Investor Management**: Add, edit, delete investor accounts
- **Investment Recording**: Record new investments (cash, material, labor)
- **PDF Generation**: Automatic receipt generation for transactions
- **Reports**: Generate investment statements and summary reports
- **User Management**: Manage user accounts and roles
- **Search & Filtering**: Advanced search and filtering capabilities

### Investor Portal
- **Personal Dashboard**: Investment overview and statistics
- **Investment History**: View all personal investment records
- **Profile Management**: Update personal information and profile picture
- **Receipt Downloads**: Download receipts for all transactions
- **Investment Statements**: Generate and download investment statements

### Security Features
- Password hashing using PHP password_hash()
- Prepared statements to prevent SQL injection
- CSRF token protection
- Session management with timeout
- Role-based access control
- Input sanitization and validation

## System Requirements

- **Web Server**: Apache/Nginx with PHP support
- **PHP**: Version 7.4 or higher
- **Database**: MySQL 5.7+ or MariaDB 10.2+
- **Extensions**: PDO, GD (for image handling)
- **Storage**: 500MB minimum disk space

## Installation Instructions

### 1. Download and Extract
1. Download the application files
2. Extract to your web server directory (e.g., `/var/www/html/agro-business-support/`)

### 2. Database Setup
1. Create a new MySQL database:
   ```sql
   CREATE DATABASE agro_business_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```

2. Import the database schema:
   ```bash
   mysql -u your_username -p agro_business_db < database/schema.sql
   ```

3. Update database configuration in `config/database.php`:
   ```php
   private $host = 'localhost';
   private $db_name = 'agro_business_db';
   private $username = 'your_db_username';
   private $password = 'your_db_password';
   ```

### 3. File Permissions
Set appropriate permissions for upload directories:
```bash
chmod 755 uploads/
chmod 755 uploads/profiles/
chmod 755 temp/
chmod 755 logs/
```

### 4. TCPDF Library Setup
Download and install TCPDF library:
1. Download TCPDF from: https://tcpdf.org/
2. Extract to `vendor/tcpdf/` directory
3. Ensure the path in `classes/PDFGenerator.php` is correct:
   ```php
   require_once '../vendor/tcpdf/tcpdf.php';
   ```

### 5. Configuration
1. Update application settings in `config/config.php`:
   - Set `APP_URL` to your domain
   - Configure file upload paths
   - Set company information for PDF generation

2. Create required directories:
   ```bash
   mkdir uploads uploads/profiles temp logs
   ```

## Default Login Credentials

### Admin Account
- **Username**: admin
- **Password**: admin123

### Sample Investor Account
- **Username**: investor1
- **Password**: password123

> **Important**: Change these default passwords immediately after installation!

## File Structure

```
agro-business-support/
├── admin/                  # Admin panel pages
│   ├── includes/          # Admin header/footer includes
│   ├── dashboard.php      # Admin dashboard
│   ├── investors.php      # Investor management
│   └── logout.php         # Admin logout
├── investor/              # Investor portal pages
│   ├── includes/         # Investor header/footer includes
│   ├── dashboard.php     # Investor dashboard
│   └── logout.php        # Investor logout
├── classes/              # PHP classes
│   ├── Auth.php         # Authentication
│   ├── User.php         # User management
│   ├── Investor.php     # Investor management
│   ├── Investment.php   # Investment management
│   └── PDFGenerator.php # PDF generation
├── config/              # Configuration files
│   ├── config.php      # Main configuration
│   └── database.php    # Database connection
├── assets/             # Static assets
│   ├── css/           # Stylesheets
│   ├── js/            # JavaScript files
│   └── images/        # Images
├── database/          # Database files
│   └── schema.sql     # Database schema
├── uploads/           # File uploads
│   └── profiles/      # Profile pictures
├── temp/             # Temporary files
├── logs/             # Application logs
├── vendor/           # Third-party libraries
│   └── tcpdf/        # TCPDF library
└── index.php         # Main login page
```

## Database Schema

### Users Table
- `id`: Primary key
- `username`: Unique username
- `email`: User email address
- `password`: Hashed password
- `role`: User role (admin/investor)
- `status`: Account status (active/inactive)

### Investors Table
- `id`: Primary key
- `user_id`: Foreign key to users table
- `account_number`: Unique account number
- `first_name`, `last_name`: Personal information
- `phone`, `address`, `city`, `state`: Contact information
- `profile_picture`: Profile image filename
- `date_joined`: Registration date
- `status`: Investor status

### Investments Table
- `id`: Primary key
- `investor_id`: Foreign key to investors table
- `transaction_id`: Unique transaction identifier
- `investment_type`: Type (cash/material/labor)
- `amount`: Investment amount
- `investment_date`: Date of investment
- `receipt_number`: Unique receipt number
- `description`: Investment description
- `status`: Transaction status

## Configuration Options

### Security Settings
```php
define('SESSION_TIMEOUT', 3600);        // Session timeout (seconds)
define('MAX_LOGIN_ATTEMPTS', 5);        // Max failed login attempts
define('LOCKOUT_TIME', 900);            // Account lockout time (seconds)
```

### File Upload Settings
```php
define('MAX_FILE_SIZE', 5242880);       // 5MB max file size
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif']);
```

### Company Information
```php
define('COMPANY_NAME', 'National Agro Business Support Initiative');
define('COMPANY_ADDRESS', 'Agricultural Development Center, Nigeria');
define('COMPANY_PHONE', '+234-xxx-xxx-xxxx');
define('COMPANY_EMAIL', 'info@agrobusiness.ng');
```

## Usage Guide

### For Administrators

1. **Login**: Use admin credentials to access admin panel
2. **Add Investors**: Create new investor accounts with complete profiles
3. **Record Investments**: Add investment transactions for any investor
4. **Generate Reports**: Create PDF reports and statements
5. **Manage Users**: Control user access and permissions

### For Investors

1. **Login**: Use investor credentials to access personal dashboard
2. **View Investments**: Review investment history and statistics
3. **Download Receipts**: Get PDF receipts for all transactions
4. **Update Profile**: Maintain personal information and profile picture
5. **Generate Statements**: Download investment statements

## Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Check database credentials in `config/database.php`
   - Ensure MySQL service is running
   - Verify database exists and user has proper permissions

2. **File Upload Issues**
   - Check directory permissions (755 for directories, 644 for files)
   - Verify PHP upload settings (upload_max_filesize, post_max_size)
   - Ensure upload directories exist

3. **PDF Generation Issues**
   - Verify TCPDF library is installed correctly
   - Check file permissions for temp directory
   - Ensure PHP GD extension is enabled

4. **Session Issues**
   - Check PHP session configuration
   - Verify session directory permissions
   - Ensure cookies are enabled in browser

### Logging
Application logs are stored in the `logs/` directory:
- `activity.log`: User activities and system events

## Security Considerations

1. **Change Default Passwords**: Update all default credentials
2. **Use HTTPS**: Enable SSL/TLS for production deployment
3. **Regular Updates**: Keep PHP and MySQL updated
4. **Backup**: Regular database and file backups
5. **Access Control**: Restrict file permissions appropriately

## Development Notes

### Assumptions Made
1. Nigerian currency (Naira) formatting
2. Lagos timezone setting
3. English language interface
4. Basic email validation (no SMTP configuration)
5. Single organization deployment

### Extensibility
The application is designed with modular classes for easy extension:
- Add new investment types by updating the database enum
- Extend reporting with additional PDF templates
- Add email notifications using PHPMailer
- Implement API endpoints for mobile apps

## Support

For technical support or feature requests:
- Email: support@agrobusiness.ng
- Documentation: See inline code comments
- Database: Refer to schema.sql for structure details

## License

Copyright (c) 2024 National Agro Business Support Initiative. All rights reserved.

---

**Version**: 1.0.0
**Last Updated**: January 2024
**PHP Version**: 7.4+
**MySQL Version**: 5.7+
