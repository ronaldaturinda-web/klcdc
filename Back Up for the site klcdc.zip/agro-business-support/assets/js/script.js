// assets/js/script.js
document.addEventListener('DOMContentLoaded', () => {
  const sidebars = document.querySelectorAll('.sidebar');
  const overlays = document.querySelectorAll('#sidebarOverlay, .sidebar-overlay');
  const toggles  = document.querySelectorAll('#sidebarToggle, .sidebar-toggle');

  function openSidebar(sb) {
    sb.classList.add('active');
    overlays.forEach(ov => ov.style.display = 'block');
  }
  
  function toggleSidebar() {
  const sidebar = document.querySelector('.sidebar');
  const overlay = document.getElementById('sidebarOverlay');

  if (sidebar) {
    sidebar.classList.toggle('active');
    sidebarOpen = !sidebarOpen;

    if (overlay) overlay.style.display = sidebarOpen ? 'block' : 'none';
    // NEW: lock background scroll when open (mobile)
    document.body.classList.toggle('sidebar-open', sidebarOpen);
  }
}

function closeSidebar() {
  const sidebar = document.querySelector('.sidebar');
  const overlay = document.getElementById('sidebarOverlay');

  if (sidebar) {
    sidebar.classList.remove('active');
    sidebarOpen = false;
    if (overlay) overlay.style.display = 'none';
    // NEW: unlock background scroll
    document.body.classList.remove('sidebar-open');
  }
}


  toggles.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      // Pick the first .sidebar (or the closest in future markup)
      const sb = sidebars[0] || document.querySelector('.sidebar');
      toggleSidebar(sb);
    });
  });

  overlays.forEach(ov => ov.addEventListener('click', () => {
    sidebars.forEach(closeSidebar);
  }));

  document.addEventListener('keyup', (e) => {
    if (e.key === 'Escape') sidebars.forEach(closeSidebar);
  });
});
