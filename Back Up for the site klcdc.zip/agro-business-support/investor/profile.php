<?php
// investor/profile.php
declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';

// Must be logged in (your investor/includes/header.php also checks)
if (!isLoggedIn()) { redirect('../index.php'); }

/** Resolve PDO similar to other pages */
function resolvePDO(): PDO {
    if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) return $GLOBALS['pdo'];
    if (function_exists('getDbConnection')) { $p = getDbConnection(); if ($p instanceof PDO) return $p; }
    if (class_exists('Database')) {
        $db = new Database();
        if (method_exists($db,'connect')) { $p = $db->connect(); if ($p instanceof PDO) return $p; }
        if (method_exists($db,'getConnection')) { $p = $db->getConnection(); if ($p instanceof PDO) return $p; }
    }
    throw new RuntimeException('DB connection not available.');
}
$pdo = resolvePDO();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

$userId = (int)($_SESSION['user_id'] ?? 0);
if ($userId <= 0) redirect('../index.php');

function h(?string $s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

/* ---------- Helpers for image upload ---------- */
function ensureUploadsDir(): string {
    // project root -> /uploads/profiles
    $base = realpath(__DIR__ . '/..'); // go up from /investor to project root-ish
    if (!$base) $base = dirname(__DIR__);
    $dir  = $base . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'profiles';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    return $dir;
}
function handleProfileUpload(?array $file): ?string {
    if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return null;

    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!isset($allowed[$mime])) {
        throw new RuntimeException('Invalid image type. Please upload JPG, PNG, or WEBP.');
    }

    // optional size gate (e.g., 5MB)
    if (($file['size'] ?? 0) > 5 * 1024 * 1024) {
        throw new RuntimeException('Image too large. Max 5 MB.');
    }

    $ext = $allowed[$mime];
    $dir = ensureUploadsDir();

    $name = 'pf_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dest = rtrim($dir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $name;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        throw new RuntimeException('Failed to save profile image.');
    }

    return $name; // stored in investors.profile_picture
}

/** Load current investor profile for this user */
$st = $pdo->prepare("
    SELECT i.id AS investor_id,
           i.account_number,
           i.first_name, i.last_name, i.phone, i.address, i.city, i.state, i.country, i.date_joined,
           i.profile_picture,
           u.id AS user_id, u.username, u.email, u.password
    FROM investors i
    JOIN users u ON u.id = i.user_id
    WHERE u.id = ?
    LIMIT 1
");
$st->execute([$userId]);
$me = $st->fetch();
if (!$me) { redirect('dashboard.php'); }

$notice = '';
$error  = '';

/** Handle profile update (text fields only) */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_profile') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please reload the page.';
    } else {
        $first = trim($_POST['first_name'] ?? '');
        $last  = trim($_POST['last_name']  ?? '');
        $email = trim($_POST['email']      ?? '');
        $phone = trim($_POST['phone']      ?? '');
        $addr  = trim($_POST['address']    ?? '');
        $city  = trim($_POST['city']       ?? '');
        $state = trim($_POST['state']      ?? '');

        if ($first==='' || $last==='' || $phone==='' || $addr==='' || $city==='' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please fill all fields correctly (valid email required).';
        } else {
            try {
                $pdo->beginTransaction();

                // Unique email check (exclude my own user)
                $chk = $pdo->prepare("SELECT 1 FROM users WHERE email = ? AND id <> ?");
                $chk->execute([$email, $me['user_id']]);
                if ($chk->fetch()) { throw new RuntimeException('Email already taken by another account.'); }

                // Update investors
                $u1 = $pdo->prepare("UPDATE investors SET first_name=?, last_name=?, phone=?, address=?, city=?, state=? WHERE id=?");
                $u1->execute([$first, $last, $phone, $addr, $city, $state, $me['investor_id']]);

                // Update users (email only here)
                $u2 = $pdo->prepare("UPDATE users SET email=? WHERE id=?");
                $u2->execute([$email, $me['user_id']]);

                $pdo->commit();

                $notice = 'Profile updated successfully.';
                // Refresh data
                $st->execute([$userId]);
                $me = $st->fetch();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $error = 'Update failed: ' . h($e->getMessage());
            }
        }
    }
}

/** Handle profile photo update (separate form) */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_photo') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please reload the page.';
    } else {
        try {
            $newName = handleProfileUpload($_FILES['profile_picture'] ?? null);
            if (!$newName) { throw new RuntimeException('Please choose an image to upload.'); }

            // (optional) delete old file
            if (!empty($me['profile_picture'])) {
                $old = ensureUploadsDir() . DIRECTORY_SEPARATOR . $me['profile_picture'];
                if (is_file($old)) @unlink($old);
            }

            $u = $pdo->prepare("UPDATE investors SET profile_picture=? WHERE id=?");
            $u->execute([$newName, $me['investor_id']]);

            $notice = 'Profile photo updated.';
            // refresh
            $st->execute([$userId]);
            $me = $st->fetch();
        } catch (Throwable $e) {
            $error = 'Photo update failed: ' . h($e->getMessage());
        }
    }
}

/** Handle password change */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'change_password') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please reload the page.';
    } else {
        $current = $_POST['current_password'] ?? '';
        $new     = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if ($new === '' || strlen($new) < 8) {
            $error = 'New password must be at least 8 characters.';
        } elseif ($new !== $confirm) {
            $error = 'New password and confirmation do not match.';
        } elseif (!password_verify($current, $me['password'])) {
            $error = 'Your current password is incorrect.';
        } else {
            try {
                $hash = password_hash($new, PASSWORD_DEFAULT);
                $u = $pdo->prepare("UPDATE users SET password=? WHERE id=?");
                $u->execute([$hash, $me['user_id']]);
                $notice = 'Password changed successfully.';
            } catch (Throwable $e) {
                $error = 'Could not change password: ' . h($e->getMessage());
            }
        }
    }
}

$page_title = 'My Profile';
include __DIR__ . '/includes/header.php';
?>
<style>
  /* Keep it scoped to investor main-content so global theme remains intact */
  .main-content .wrap{max-width:900px;margin:24px auto;padding:0 16px}
  .main-content .card{background:#fff;border:1px solid #e8edf1;border-radius:14px;box-shadow:0 6px 24px rgba(0,0,0,.06);padding:18px}
  .main-content h1{margin:0 0 6px;font-size:1.4rem}
  .main-content .muted{color:#6b7280}
  .main-content .grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
  .main-content label{display:block;font-size:.9rem;color:#6b7280;margin-bottom:6px}
  .main-content input,.main-content textarea{
    width:100%;padding:12px 14px;border:1px solid #e8edf1;border-radius:12px;background:#fff;outline:none;font-size:1rem
  }
  .main-content input:focus,.main-content textarea:focus{box-shadow:0 0 0 4px #d1fae5;border-color:#4a7c59}
  .main-content textarea{min-height:90px;resize:vertical}
  .main-content .row{display:flex;gap:10px;flex-wrap:wrap}
  .main-content .btn{appearance:none;border:1px solid transparent;border-radius:12px;padding:10px 14px;font-weight:700;cursor:pointer;text-decoration:none}
  .main-content .btn-primary{background:#2c5530;color:#fff;border-color:#2c5530}
  .main-content .btn-secondary{background:#fff;color:#2c5530;border-color:#2c5530}
  .main-content .alert{padding:12px 14px;border-radius:12px;margin:12px 0;border:1px solid #e8edf1}
  .main-content .alert-success{background:#eefaf1;color:#14532d}
  .main-content .alert-error{background:#fff5f5;color:#7f1d1d}
  @media (max-width:760px){.main-content .grid{grid-template-columns:1fr}}
  .main-content .badge{display:inline-block;background:#eef5ef;color:#2c5530;border:1px solid #dce9de;border-radius:999px;padding:4px 10px;font-size:.85rem}

  /* Photo card bits */
  .photo-wrap{display:flex; align-items:center; gap:16px; flex-wrap:wrap}
  .avatar{
    width:110px; height:110px; border-radius:50%;
    object-fit:cover; border:3px solid #2c5530;
    background:#f3f4f6; display:block;
  }
  .avatar-fallback{
    width:110px; height:110px; border-radius:50%;
    display:flex; align-items:center; justify-content:center;
    background:#2c5530; color:#fff; font-size:32px; font-weight:700; border:3px solid #2c5530;
  }
</style>

<div class="main-content">
  <div class="wrap">

    <div class="card" style="margin-bottom:12px;">
      <h1>My Profile</h1>
      <div class="muted">View and update your contact details, change your password, and update your profile photo.</div>

      <?php if ($error): ?>
        <div class="alert alert-error"><strong>Error:</strong> <?=h($error)?></div>
      <?php elseif ($notice): ?>
        <div class="alert alert-success"><?=h($notice)?></div>
      <?php endif; ?>
    </div>

    <!-- Basic info summary -->
    <div class="card" style="margin-bottom:12px;">
      <div class="row" style="justify-content:space-between;align-items:center">
        <div>
          <div class="badge">Account: <?=h($me['account_number'])?></div>
          <div class="badge">Joined: <?=h(substr((string)$me['date_joined'],0,10))?></div>
        </div>
        <div class="badge">Username: <?=h($me['username'])?></div>
      </div>
    </div>

    <!-- Profile Photo -->
    <div class="card" style="margin-bottom:12px;">
      <h2 style="margin:0 0 10px;font-size:1.1rem">Profile Photo</h2>
      <div class="photo-wrap">
        <?php
          $picPath = '';
          if (!empty($me['profile_picture'])) {
              $picPath = '../uploads/profiles/' . $me['profile_picture'];
          }
        ?>
        <?php if ($picPath && is_file(realpath(__DIR__ . '/../uploads/profiles/' . $me['profile_picture']))): ?>
          <img src="<?=h($picPath)?>" alt="Profile Picture" class="avatar">
        <?php else: ?>
          <div class="avatar-fallback">
            <?= strtoupper(substr((string)$me['first_name'],0,1) . substr((string)$me['last_name'],0,1)) ?>
          </div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data" style="display:flex; gap:10px; align-items:center;">
          <input type="hidden" name="csrf_token" value="<?=generateCSRFToken()?>">
          <input type="hidden" name="action" value="update_photo">
          <input class="form-control" type="file" name="profile_picture" accept="image/*" required>
          <button class="btn btn-primary" type="submit">Upload</button>
        </form>
        <div class="muted" style="flex-basis:100%;">Recommended: square image (~300×300). JPG/PNG/WEBP, ≤ 5MB. We’ll crop visually with <code>object-fit:cover</code>.</div>
      </div>
    </div>

    <!-- Update Profile -->
    <div class="card" style="margin-bottom:12px;">
      <h2 style="margin:0 0 10px;font-size:1.1rem">Contact Details</h2>
      <form method="post" novalidate>
        <input type="hidden" name="csrf_token" value="<?=generateCSRFToken()?>">
        <input type="hidden" name="action" value="update_profile">

        <div class="grid">
          <div>
            <label>First Name</label>
            <input name="first_name" value="<?=h($me['first_name'])?>" required>
          </div>
          <div>
            <label>Last Name</label>
            <input name="last_name" value="<?=h($me['last_name'])?>" required>
          </div>
          <div>
            <label>Email</label>
            <input type="email" name="email" value="<?=h($me['email'])?>" required>
          </div>
          <div>
            <label>Phone</label>
            <input name="phone" value="<?=h($me['phone'])?>" required>
          </div>
          <div style="grid-column:1/-1">
            <label>Address</label>
            <input name="address" value="<?=h($me['address'])?>" required>
          </div>
          <div>
            <label>City</label>
            <input name="city" value="<?=h($me['city'])?>" required>
          </div>
          <div>
            <label>State/Region</label>
            <input name="state" value="<?=h($me['state'])?>">
          </div>
        </div>

        <div class="row" style="justify-content:flex-end;margin-top:10px">
          <a class="btn btn-secondary" href="dashboard.php">Cancel</a>
          <button class="btn btn-primary" type="submit">Save Changes</button>
        </div>
      </form>
    </div>

    <!-- Change Password -->
    <div class="card">
      <h2 style="margin:0 0 10px;font-size:1.1rem">Change Password</h2>
      <form method="post" novalidate>
        <input type="hidden" name="csrf_token" value="<?=generateCSRFToken()?>">
        <input type="hidden" name="action" value="change_password">

        <div class="grid">
          <div>
            <label>Current Password</label>
            <input type="password" name="current_password" required>
          </div>
          <div>
            <label>New Password (min 8 chars)</label>
            <input type="password" name="new_password" required>
          </div>
          <div>
            <label>Confirm New Password</label>
            <input type="password" name="confirm_password" required>
          </div>
        </div>

        <div class="row" style="justify-content:flex-end;margin-top:10px">
          <button class="btn btn-primary" type="submit">Update Password</button>
        </div>
      </form>
    </div>

  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
