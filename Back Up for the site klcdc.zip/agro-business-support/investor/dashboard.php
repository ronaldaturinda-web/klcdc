<?php
/**
 * Investor Dashboard
 * National Agro Business Support Initiative
 */

require_once '../config/config.php';
require_once '../classes/Auth.php';
require_once '../classes/Investment.php';
require_once '../classes/Investor.php';

// Check authentication
if (!isLoggedIn()) {
    redirect('../index.php');
}

// Redirect admin to admin dashboard
if (isAdmin()) {
    redirect('../admin/dashboard.php');
}

$auth = new Auth();
$investment = new Investment();
$investor_class = new Investor();

// Validate session
if (!$auth->validateSession()) {
    redirect('../index.php');
}

// Get investor profile
$investor_profile = $investor_class->getInvestorByUserId($_SESSION['user_id']);

if (!$investor_profile) {
    // If no investor profile exists, redirect to complete profile
    redirect('complete_profile.php');
}

// Get investment statistics for this investor
$investor_investments = $investment->getInvestmentsByInvestorId($investor_profile['id']);

// Calculate statistics
$total_amount = 0;
$cash_total = 0;
$material_total = 0;
$labor_total = 0;
$total_transactions = count($investor_investments);

foreach ($investor_investments as $inv) {
    $total_amount += $inv['amount'];
    switch ($inv['investment_type']) {
        case 'cash':
            $cash_total += $inv['amount'];
            break;
        case 'material':
            $material_total += $inv['amount'];
            break;
        case 'labor':
            $labor_total += $inv['amount'];
            break;
    }
}

// Recent investments (last 5)
$recent_investments = array_slice($investor_investments, 0, 5);

$page_title = 'Investor Dashboard';
include 'includes/header.php';
?>

<div class="main-content">
    <div class="page-header">
        <h1><i class="fas fa-chart-line"></i> Investment Dashboard</h1>
        <p class="text-muted">Welcome back, <?php echo htmlspecialchars($investor_profile['first_name'] . ' ' . $investor_profile['last_name']); ?>!</p>
    </div>

    <!-- Profile Summary Card -->
    <div class="card mb-4">
        <div class="card-body">
            <div class="row">
                <div class="col-md-3 text-center">
                    <div class="profile-picture">
                        <?php if (!empty($investor_profile['profile_picture'])): ?>
                            <img src="../uploads/profiles/<?php echo htmlspecialchars($investor_profile['profile_picture']); ?>"
                                 alt="Profile Picture"
                                 style="width: 100px; height: 100px; border-radius: 50%; object-fit: cover; border: 3px solid var(--primary-color);">
                        <?php else: ?>
                            <div style="width: 100px; height: 100px; border-radius: 50%; background-color: var(--primary-color); display: flex; align-items: center; justify-content: center; color: white; font-size: 2rem; margin: 0 auto;">
                                <?php echo strtoupper(substr($investor_profile['first_name'], 0, 1) . substr($investor_profile['last_name'], 0, 1)); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-9">
                    <h3><?php echo htmlspecialchars($investor_profile['first_name'] . ' ' . $investor_profile['last_name']); ?></h3>
                    <p class="text-muted mb-2">
                        <i class="fas fa-id-card"></i> Account: <?php echo htmlspecialchars($investor_profile['account_number']); ?> |
                        <i class="fas fa-calendar"></i> Joined: <?php echo formatDate($investor_profile['date_joined'], 'd/m/Y'); ?>
                    </p>
                    <p class="text-muted mb-2">
                        <i class="fas fa-phone"></i> <?php echo htmlspecialchars($investor_profile['phone']); ?> |
                        <i class="fas fa-envelope"></i> <?php echo htmlspecialchars($investor_profile['email']); ?>
                    </p>
                    <p class="text-muted mb-0">
                        <i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($investor_profile['city'] . ', ' . $investor_profile['state']); ?>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Investment Statistics -->
    <div class="stats-grid">
        <div class="stat-card success">
            <div class="stat-icon">
                <i class="fas fa-money-bill-wave"></i>
            </div>
            <div class="stat-number"><?php echo formatCurrency($total_amount); ?></div>
            <div class="stat-label">Total Investments</div>
        </div>

        <div class="stat-card info">
            <div class="stat-icon">
                <i class="fas fa-chart-bar"></i>
            </div>
            <div class="stat-number"><?php echo number_format($total_transactions); ?></div>
            <div class="stat-label">Total Transactions</div>
        </div>

        <div class="stat-card warning">
            <div class="stat-icon">
                <i class="fas fa-coins"></i>
            </div>
            <div class="stat-number"><?php echo formatCurrency($cash_total); ?></div>
            <div class="stat-label">Cash Investments</div>
        </div>

        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-tools"></i>
            </div>
            <div class="stat-number"><?php echo formatCurrency($material_total + $labor_total); ?></div>
            <div class="stat-label">Material & Labor</div>
        </div>
    </div>

    <!-- Investment Breakdown -->
    <div class="row">
        <div class="col-md-8">
            <!-- Recent Investments -->
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3><i class="fas fa-clock"></i> Recent Investments</h3>
                    <a href="investments.php" class="btn btn-primary btn-sm">
                        <i class="fas fa-eye"></i> View All
                    </a>
                </div>
                <div class="card-body">
                    <?php if (!empty($recent_investments)): ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Type</th>
                                        <th>Amount</th>
                                        <th>Receipt</th>
                                        <th>Actions</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_investments as $inv): ?>
                                        <tr>
                                            <td><?php echo formatDate($inv['investment_date'], 'd/m/Y'); ?></td>
                                            <td>
                                                <span class="badge badge-<?php echo $inv['investment_type'] === 'cash' ? 'success' : ($inv['investment_type'] === 'material' ? 'warning' : 'info'); ?>">
                                                    <?php echo ucfirst($inv['investment_type']); ?>
                                                </span>
                                            </td>
                                            <td><strong><?php echo formatCurrency($inv['amount']); ?></strong></td>
                                            <td>
                                                <small class="text-muted"><?php echo htmlspecialchars($inv['receipt_number']); ?></small>
                                            </td>
                                            <td>
                                            <a href="print_receipt.php?id=<?= (int)$inv['id'] ?>"
                                            class="btn btn-sm btn-secondary" title="Print Receipt" target="_blank">
                                            <i class="fas fa-print"></i>
                                            </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                            <h5>No investments yet</h5>
                            <p class="text-muted">Your investment history will appear here once you make your first investment.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <!-- Investment Type Breakdown -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-pie-chart"></i> Investment Breakdown</h3>
                </div>
                <div class="card-body">
                    <?php if ($total_amount > 0): ?>
                        <canvas id="investmentBreakdownChart" width="300" height="300"></canvas>

                        <div class="mt-3">
                            <div class="d-flex justify-content-between mb-2">
                                <span><i class="fas fa-circle" style="color: #28a745;"></i> Cash:</span>
                                <strong><?php echo formatCurrency($cash_total); ?></strong>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span><i class="fas fa-circle" style="color: #ffc107;"></i> Material:</span>
                                <strong><?php echo formatCurrency($material_total); ?></strong>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span><i class="fas fa-circle" style="color: #17a2b8;"></i> Labor:</span>
                                <strong><?php echo formatCurrency($labor_total); ?></strong>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between">
                                <span><strong>Total:</strong></span>
                                <strong><?php echo formatCurrency($total_amount); ?></strong>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="fas fa-chart-pie fa-3x text-muted mb-3"></i>
                            <p class="text-muted">Investment breakdown will appear here once you make investments.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="card mt-3">
                <div class="card-header">
                    <h3><i class="fas fa-bolt"></i> Quick Actions</h3>
                </div>
                <div class="card-body">
                    <a href="investments.php" class="btn btn-primary btn-block mb-2">
                        <i class="fas fa-list"></i> View All Investments
                    </a>
                    <a href="download_statement.php" class="btn btn-info btn-block mb-2" target="_blank">
                        <i class="fas fa-file-download"></i> Download Statement
                    </a>
                    <a href="profile.php" class="btn btn-warning btn-block mb-2">
                        <i class="fas fa-user-edit"></i> Update Profile
                    </a>
                    <a href="change_password.php" class="btn btn-secondary btn-block">
                        <i class="fas fa-key"></i> Change Password
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if ($total_amount > 0): ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Investment Breakdown Chart
const breakdownCtx = document.getElementById('investmentBreakdownChart').getContext('2d');
const cashTotal = <?php echo $cash_total; ?>;
const materialTotal = <?php echo $material_total; ?>;
const laborTotal = <?php echo $labor_total; ?>;

new Chart(breakdownCtx, {
    type: 'doughnut',
    data: {
        labels: ['Cash', 'Material', 'Labor'],
        datasets: [{
            data: [cashTotal, materialTotal, laborTotal],
            backgroundColor: [
                'rgba(40, 167, 69, 0.8)',
                'rgba(255, 193, 7, 0.8)',
                'rgba(23, 162, 184, 0.8)'
            ],
            borderColor: [
                'rgba(40, 167, 69, 1)',
                'rgba(255, 193, 7, 1)',
                'rgba(23, 162, 184, 1)'
            ],
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'bottom'
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                        const percentage = ((context.raw / total) * 100).toFixed(1);
                        return context.label + ': UGX' + context.raw.toLocaleString() + ' (' + percentage + '%)';
                    }
                }
            }
        }
    }
});
</script>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
