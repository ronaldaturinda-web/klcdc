<?php
// investor/download_statement.php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) session_start();

require_once __DIR__ . '/../config/config.php';

// --- Auth: only investors (non-admin) may access this endpoint ---
if (!isLoggedIn()) {
    redirect('../index.php');
}
if (isAdmin()) {
    redirect('../admin/dashboard.php');
}

/** Resolve a PDO from common patterns seen in your project */
function resolvePDO(): PDO {
    if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) return $GLOBALS['pdo'];
    if (function_exists('getDbConnection')) { $p = getDbConnection(); if ($p instanceof PDO) return $p; }
    if (class_exists('Database')) {
        $db = new Database();
        if (method_exists($db, 'connect'))       { $p = $db->connect();       if ($p instanceof PDO) return $p; }
        if (method_exists($db, 'getConnection')) { $p = $db->getConnection(); if ($p instanceof PDO) return $p; }
    }
    throw new RuntimeException('Database connection not available.');
}

try {
    $pdo = resolvePDO();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    http_response_code(500);
    exit('Database connection error.');
}

/** TCPDF loader (for PDF) */
function tryIncludeTCPDF(): bool {
    $candidates = [
        __DIR__ . '/../vendor/tcpdf/tcpdf.php',
        __DIR__ . '/../tcpdf_min/tcpdf.php',
        __DIR__ . '/../tcpdf.php',
    ];
    foreach ($candidates as $p) {
        if (is_readable($p)) {
            if (!defined('K_PATH_CACHE')) {
                $cache = realpath(__DIR__ . '/../temp');
                if (!$cache) { @mkdir(__DIR__ . '/../temp', 0775, true); $cache = __DIR__ . '/../temp'; }
                define('K_PATH_CACHE', rtrim($cache, '/\\') . DIRECTORY_SEPARATOR);
            }
            require_once $p;
            return true;
        }
    }
    return false;
}

/** Helpers */
function h(?string $s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function moneyUGX(float $amount): string { return 'UGX ' . number_format($amount, 0, '.', ','); }
function parseDate(?string $s, string $endOfDay = '00:00:00'): ?string {
    if (!$s) return null;
    $ts = strtotime($s);
    if (!$ts) return null;
    return date('Y-m-d', $ts) . ' ' . $endOfDay;
}

/** Current user → investor profile */
$userId = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
if ($userId <= 0) redirect('../index.php');

$st = $pdo->prepare("SELECT id, account_number, first_name, last_name FROM investors WHERE user_id = ? LIMIT 1");
$st->execute([$userId]);
$investor = $st->fetch();
if (!$investor) { http_response_code(404); exit('Investor profile not found.'); }

$investorId = (int)$investor['id'];
$fullName   = $investor['first_name'] . ' ' . $investor['last_name'];
$accountNo  = $investor['account_number'];

/** Optional filters (date range) */
$fromR = trim($_GET['from'] ?? '');
$toR   = trim($_GET['to']   ?? '');
$from  = $fromR ? parseDate($fromR, '00:00:00') : null;
$to    = $toR   ? parseDate($toR,   '23:59:59') : null;

/** Fetch rows + totals */
$params = [':iid' => $investorId];
$where  = "WHERE inv.investor_id = :iid";
if ($from) { $where .= " AND inv.investment_date >= :from"; $params[':from'] = $from; }
if ($to)   { $where .= " AND inv.investment_date <= :to";   $params[':to']   = $to;   }

$sqlRows = "SELECT inv.investment_date, inv.transaction_id, inv.receipt_number, inv.investment_type, inv.amount, inv.description
            FROM investments inv
            $where
            ORDER BY inv.investment_date ASC, inv.id ASC";
$st = $pdo->prepare($sqlRows);
$st->execute($params);
$rows = $st->fetchAll();

$sqlTot = "SELECT
            SUM(inv.amount) AS total,
            SUM(CASE WHEN inv.investment_type='cash'     THEN inv.amount ELSE 0 END) AS cash,
            SUM(CASE WHEN inv.investment_type='material' THEN inv.amount ELSE 0 END) AS material,
            SUM(CASE WHEN inv.investment_type='labor'    THEN inv.amount ELSE 0 END) AS labor
           FROM investments inv
           $where";
$st = $pdo->prepare($sqlTot);
$st->execute($params);
$totals = $st->fetch() ?: ['total'=>0,'cash'=>0,'material'=>0,'labor'=>0];

$org = defined('APP_NAME') ? APP_NAME : 'National Agro Business Support Initiative';

/** CSV export if requested */
if (strtolower($_GET['format'] ?? '') === 'csv') {
    $fname = 'statement_' . preg_replace('/\W+/', '', (string)$accountNo) . '_' . date('Ymd_His') . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename='.$fname);
    $out = fopen('php://output', 'w');
    fputcsv($out, [$org . ' — Investor Statement']);
    fputcsv($out, ['Investor', $fullName]);
    fputcsv($out, ['Account',  $accountNo]);
    if ($fromR || $toR) fputcsv($out, ['Range', ($fromR ?: '…') . ' to ' . ($toR ?: '…')]);
    fputcsv($out, []);
    fputcsv($out, ['Date', 'Receipt', 'Transaction', 'Type', 'Amount (UGX)', 'Description']);
    foreach ($rows as $r) {
        fputcsv($out, [
            $r['investment_date'],
            $r['receipt_number'],
            $r['transaction_id'],
            strtoupper($r['investment_type']),
            number_format((float)$r['amount'], 0, '.', ','),
            (string)$r['description'],
        ]);
    }
    fputcsv($out, []);
    fputcsv($out, ['TOTAL', '', '', '', number_format((float)$totals['total'], 0, '.', ','), '']);
    fclose($out);
    exit;
}

/** PDF (default) */
if (!tryIncludeTCPDF()) {
    header('Content-Type: text/plain; charset=utf-8');
    echo "TCPDF not found.\n\n";
    $qs = $_GET; $qs['format'] = 'csv';
    echo 'Use CSV instead: download_statement.php?' . http_build_query($qs);
    exit;
}
while (ob_get_level()) { ob_end_clean(); }

$pdf = new TCPDF('P','mm','A4',true,'UTF-8',false);
$pdf->SetCreator($org);
$pdf->SetAuthor($org);
$pdf->SetTitle('Investor Statement');
$pdf->SetMargins(12,12,12);
$pdf->SetAutoPageBreak(true, 14);
$pdf->AddPage();
$pdf->SetFont('helvetica','',11);

// Brand header bar
$pdf->SetFillColor(44,85,48); // #2c5530
$pdf->Rect(12,12,186,16,'F');
$pdf->SetTextColor(255,255,255);
$pdf->SetFont('helvetica','B',13);
$pdf->SetXY(16,14);
$pdf->Write(8, $org);
$pdf->SetFont('helvetica','',11);
$pdf->SetXY(16,22);
$pdf->Write(6, 'Investor Statement');
$pdf->Ln(18);
$pdf->SetTextColor(0,0,0);

// Data for header blocks
$fullNameEsc  = h($fullName);
$accountNoEsc = h($accountNo);
$rangeText    = ($fromR || $toR) ? (($fromR ?: '…') . ' to ' . ($toR ?: '…')) : 'All time';
$rangeEsc     = h($rangeText);
$generatedAt  = date('d M Y, H:i');

// Info blocks (no function calls inside the string)
$hdr = ''
. '<style>'
. '.box{border:1px solid #e6e8ec;border-radius:8px;padding:8px}'
. '.label{color:#666;font-size:10px;text-transform:uppercase;letter-spacing:.02em}'
. '.value{font-size:12px}'
. '</style>'
. '<table cellpadding="4" cellspacing="4" width="100%">'
. '  <tr>'
. '    <td class="box" width="60%">'
. '      <div class="label">Investor</div>'
. '      <div class="value"><strong>'.$fullNameEsc.'</strong></div>'
. '      <div class="label" style="margin-top:6px;">Account</div>'
. '      <div class="value">'.$accountNoEsc.'</div>'
. '    </td>'
. '    <td class="box" width="40%">'
. '      <div class="label">Date Range</div>'
. '      <div class="value">'.$rangeEsc.'</div>'
. '      <div class="label" style="margin-top:6px;">Generated</div>'
. '      <div class="value">'.$generatedAt.'</div>'
. '    </td>'
. '  </tr>'
. '</table>';

$pdf->writeHTML($hdr, true, false, true, false, '');

// Totals row
$totRow = ''
. '<table cellpadding="5" width="100%" style="font-size:11px;">'
. '  <tr>'
. '    <td><b>Total:</b> '.moneyUGX((float)$totals['total']).'</td>'
. '    <td><b>Cash:</b> '.moneyUGX((float)$totals['cash']).'</td>'
. '    <td><b>Material:</b> '.moneyUGX((float)$totals['material']).'</td>'
. '    <td><b>Labor:</b> '.moneyUGX((float)$totals['labor']).'</td>'
. '  </tr>'
. '</table>';

$pdf->writeHTML($totRow, true, false, true, false, '');

// Transactions table
$tbl = "<br><table border='1' cellpadding='5' cellspacing='0' style='font-size:10.5px;'>"
     . "<thead>"
     . "  <tr style='background-color:#eef5ef;'>"
     . "    <th width='18%'>Date</th>"
     . "    <th width='14%'>Receipt</th>"
     . "    <th width='14%'>TXN</th>"
     . "    <th width='12%'>Type</th>"
     . "    <th width='14%'>Amount</th>"
     . "    <th width='28%'>Description</th>"
     . "  </tr>"
     . "</thead><tbody>";

if ($rows) {
    foreach ($rows as $r) {
        $tbl .= '<tr>'
              . '<td>'.h($r['investment_date']).'</td>'
              . '<td>'.h($r['receipt_number']).'</td>'
              . '<td>'.h($r['transaction_id']).'</td>'
              . '<td>'.strtoupper(h($r['investment_type'])).'</td>'
              . '<td>'.moneyUGX((float)$r['amount']).'</td>'
              . '<td>'.h((string)$r['description']).'</td>'
              . '</tr>';
    }
} else {
    $tbl .= "<tr><td colspan='6' style='text-align:center;color:#666;'>No investments found for the selected range.</td></tr>";
}
$tbl .= '</tbody></table>';

$pdf->writeHTML($tbl, true, false, true, false, '');

// Output
$fname = 'statement_' . preg_replace('/\W+/', '', (string)$accountNo) . '_' . date('Ymd_His') . '.pdf';
$pdf->Output($fname, 'I');
exit;
