<?php
// investor/complete_profile.php
declare(strict_types=1);

require_once '../config/config.php';
require_once '../classes/Auth.php';
require_once '../classes/Investor.php';

// --------------------------
// Configurable constants
// --------------------------
if (!defined('ACCOUNT_PREFIX')) define('ACCOUNT_PREFIX', 'NAB');        // e.g. NAB00123
if (!defined('DEFAULT_COUNTRY')) define('DEFAULT_COUNTRY', 'Uganda');   // default country for your project
if (!defined('ALLOW_PUBLIC_REGISTRATION')) define('ALLOW_PUBLIC_REGISTRATION', false);

// --------------------------
// Utilities
// --------------------------
function resolvePDO(): PDO {
    if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) return $GLOBALS['pdo'];
    if (function_exists('getDbConnection')) { $p = getDbConnection(); if ($p instanceof PDO) return $p; }
    if (class_exists('Database')) {
        $db = new Database();
        if (method_exists($db,'connect'))       { $p = $db->connect();       if ($p instanceof PDO) return $p; }
        if (method_exists($db,'getConnection')) { $p = $db->getConnection(); if ($p instanceof PDO) return $p; }
    }
    throw new RuntimeException('Database connection not available.');
}

try {
    $pdo = resolvePDO();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    http_response_code(500);
    exit('Database connection error.');
}

// Classes
$auth = new Auth();
$investorClass = new Investor();

// If logged in but session invalid, boot them
if (isLoggedIn() && !$auth->validateSession()) {
    redirect('../index.php');
}

// --------------------------
// Optional: Public registration path (if enabled)
// --------------------------
$registering = (!isLoggedIn() && ALLOW_PUBLIC_REGISTRATION);

// If not registering publicly, require login
if (!$registering && !isLoggedIn()) {
    redirect('../index.php');
}

// If the user is logged in but is an admin, they usually get redirected away
// But for safety: if someone changed role from admin->investor, they won't be admin anymore.
// So we don't force a redirect here.

// If user is logged in and already has an investor profile, go to investor dashboard
$currentUserId = $registering ? null : (int)($_SESSION['user_id'] ?? 0);
if (!$registering) {
    $existing = $investorClass->getInvestorByUserId($currentUserId);
    if ($existing) redirect('dashboard.php');
}

// --------------------------
// Helpers
// --------------------------
function generateAccountNumber(PDO $pdo): string {
    // Looks for highest numeric suffix after ACCOUNT_PREFIX and increments it
    $prefix = ACCOUNT_PREFIX;
    $stmt = $pdo->prepare("SELECT account_number FROM investors WHERE account_number LIKE ? ORDER BY id DESC LIMIT 1");
    $stmt->execute([$prefix.'%']);
    $last = $stmt->fetchColumn();

    $num = 0;
    if ($last && stripos($last, $prefix) === 0) {
        $suffix = preg_replace('/\D/', '', substr($last, strlen($prefix)));
        if ($suffix !== '') $num = (int)$suffix;
    }
    $next = $num + 1;
    // Zero-pad to 5 digits, e.g. NAB00001
    return $prefix . str_pad((string)$next, 5, '0', STR_PAD_LEFT);
}

function ensureUploadsDir(): string {
    // Save alongside ../uploads/profiles relative to /investor/
    $base = realpath(__DIR__ . '/../..'); // project root
    if (!$base) $base = dirname(__DIR__, 2);
    $dir  = $base . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'profiles';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    return $dir;
}

function handleProfileUpload(?array $file): ?string {
    if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return null;

    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!isset($allowed[$mime])) {
        throw new RuntimeException('Invalid image type. Please upload JPG, PNG, or WEBP.');
    }

    $ext = $allowed[$mime];
    $dir = ensureUploadsDir();

    $name = 'pf_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dest = rtrim($dir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $name;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        throw new RuntimeException('Failed to save profile image.');
    }

    // Path stored relative to /uploads/profiles
    return $name;
}

// --------------------------
// Registration (optional) or Profile Creation
// --------------------------
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $message = 'Invalid request. Please refresh and try again.';
        $message_type = 'error';
    } else {
        try {
            $pdo->beginTransaction();

            if ($registering) {
                // Create a new user first
                $username = sanitize_input($_POST['username'] ?? '');
                $email    = sanitize_input($_POST['email'] ?? '');
                $password = $_POST['password'] ?? '';
                $confirm  = $_POST['confirm_password'] ?? '';

                if ($username === '' || $email === '' || $password === '') {
                    throw new RuntimeException('Please fill all required user fields.');
                }
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    throw new RuntimeException('Please enter a valid email address.');
                }
                if ($password !== $confirm) {
                    throw new RuntimeException('Passwords do not match.');
                }

                // Check uniqueness
                $check = $pdo->prepare("SELECT 1 FROM users WHERE username = ? OR email = ? LIMIT 1");
                $check->execute([$username, $email]);
                if ($check->fetch()) {
                    throw new RuntimeException('Username or email already exists.');
                }

                $hash = password_hash($password, PASSWORD_BCRYPT);
                $role = 'investor'; // self-registered users are investors
                $insU = $pdo->prepare("INSERT INTO users (username, email, password, role, status) VALUES (?,?,?,?, 'active')");
                $insU->execute([$username, $email, $hash, $role]);
                $currentUserId = (int)$pdo->lastInsertId();

                // Log the user in (simple session set)
                $_SESSION['user_id'] = $currentUserId;
                $_SESSION['username'] = $username;
                $_SESSION['role'] = $role;
            }

            // Now create the investor profile for current user
            $first_name  = sanitize_input($_POST['first_name'] ?? '');
            $last_name   = sanitize_input($_POST['last_name'] ?? '');
            $phone       = sanitize_input($_POST['phone'] ?? '');
            $address     = sanitize_input($_POST['address'] ?? '');
            $city        = sanitize_input($_POST['city'] ?? '');
            $state       = sanitize_input($_POST['state'] ?? '');
            $country     = sanitize_input($_POST['country'] ?? DEFAULT_COUNTRY);
            $date_joined = sanitize_input($_POST['date_joined'] ?? date('Y-m-d'));

            if ($first_name==='' || $last_name==='' || $phone==='' || $address==='' || $city==='') {
                throw new RuntimeException('Please complete all required profile fields.');
            }

            // If investor already exists (race condition), stop
            $chk = $pdo->prepare("SELECT id FROM investors WHERE user_id = ? LIMIT 1");
            $chk->execute([$currentUserId]);
            if ($chk->fetch()) {
                // Someone just created it—commit and redirect
                $pdo->commit();
                redirect('dashboard.php');
            }

            $account_number = generateAccountNumber($pdo);

            // Handle optional picture
            $profile_picture = null;
            if (!empty($_FILES['profile_picture'])) {
                $profile_picture = handleProfileUpload($_FILES['profile_picture']);
            }

            $ins = $pdo->prepare("
                INSERT INTO investors
                    (user_id, account_number, first_name, last_name, phone, address, city, state, country, postal_code, profile_picture, date_joined, status)
                VALUES
                    (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
            ");
            $postal_code = sanitize_input($_POST['postal_code'] ?? null);
            $ins->execute([
                $currentUserId,
                $account_number,
                $first_name,
                $last_name,
                $phone,
                $address,
                $city,
                $state,
                $country ?: DEFAULT_COUNTRY,
                $postal_code,
                $profile_picture,
                $date_joined ?: date('Y-m-d'),
            ]);

            $pdo->commit();

            // Done → go to investor dashboard
            redirect('dashboard.php');
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $message = htmlspecialchars($e->getMessage());
            $message_type = 'error';
        }
    }
}

// If user is logged in and still has profile, bounce (in case of reload)
if (!$registering && $investorClass->getInvestorByUserId((int)$_SESSION['user_id'])) {
    redirect('dashboard.php');
}

// Prepare defaults for form
$today = date('Y-m-d');
$page_title = $registering ? 'Register & Complete Profile' : 'Complete Your Investor Profile';

// Minimal header include without redirecting admin away
// If your investor/includes/header.php redirects admins, we avoid it for the registration page,
// so we’ll just include assets directly to keep the look consistent.
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($page_title) ?> - <?= APP_NAME ?></title>
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
:root {
  --primary: #2c5530;
  --primary-600: #234726;
  --ring: #cfe9d4;
  --text: #1f2937;
  --muted: #6b7280;
  --border: #e5e7eb;
  --bg: #2c5530; /* Changed here */
  --danger: #dc3545;
  --warning: #f59e0b;
}


  body.login-page{background:var(--bg); color:var(--text);}

  .auth-wrap{max-width: 900px; margin: 40px auto; padding: 16px;}

  /* Card */
  .card{
    background:#fff;
    border:1px solid var(--border);
    border-radius:14px;
    box-shadow:0 8px 28px rgba(0,0,0,.06);
    overflow:hidden;
  }
  .card-header{
    padding:16px 18px;
    border-bottom:1px solid var(--border);
    background:linear-gradient(0deg,#fff, #fff);
  }
  .card-header h2,
  .card-header strong{margin:0; color:var(--text)}
  .card-header .text-muted{color:var(--muted)!important}
  .card-body{padding:18px}

  /* Grid layout */
  .grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:16px 14px;
  }
  @media (max-width: 768px){
    .grid{grid-template-columns:1fr}
  }

  /* Form basics */
  .form-group{display:flex; flex-direction:column; gap:6px;}
  .form-group label{
    font-size:.925rem; font-weight:600; color:var(--text);
  }
  .text-danger{color:var(--danger)}
  .text-muted{color:var(--muted)}
  .help{font-size:.85rem; color:var(--muted)}

  /* Inputs / selects / textarea unified */
  .form-control{
    appearance:none;
    display:block;
    width:100%;
    padding:12px 12px;
    font-size: .95rem;
    color:var(--text);
    background:#fff;
    border:1px solid var(--border);
    border-radius:10px;
    outline:none;
    transition:border-color .15s ease, box-shadow .15s ease, background .15s ease;
  }
  .form-control:hover{
    border-color:#d7dce1;
  }
  .form-control:focus{
    border-color:var(--primary);
    box-shadow:0 0 0 4px var(--ring);
  }
  .form-control.is-invalid{
    border-color:var(--danger);
    box-shadow:0 0 0 4px rgba(220,53,69,.15);
  }
  .form-control.is-valid{
    border-color:#198754;
    box-shadow:0 0 0 4px rgba(25,135,84,.15);
  }
  textarea.form-control{min-height:110px; resize:vertical}

  /* File input look */
  input[type="file"].form-control{
    padding:10px 12px;
  }

  /* Select arrow */
  select.form-control{
    background-image:
      linear-gradient(45deg, transparent 50%, var(--muted) 50%),
      linear-gradient(135deg, var(--muted) 50%, transparent 50%),
      linear-gradient(to right, transparent, transparent);
    background-position:
      calc(100% - 18px) calc(50% - 4px),
      calc(100% - 12px) calc(50% - 4px),
      100% 0;
    background-size:6px 6px, 6px 6px, 2.5em 2.5em;
    background-repeat:no-repeat;
  }

  /* Buttons */
  .btn{
    display:inline-flex; align-items:center; gap:.5rem;
    border:1px solid transparent; border-radius:10px;
    padding:10px 14px; font-weight:600; cursor:pointer; text-decoration:none;
    transition:transform .05s ease, box-shadow .2s ease, background .2s ease, border-color .2s ease, color .2s ease;
    box-shadow:0 2px 8px rgba(0,0,0,.04);
  }
  .btn:active{transform:translateY(1px)}
  .btn-primary{background:var(--primary); color:#fff; border-color:var(--primary)}
  .btn-primary:hover{background:var(--primary-600); border-color:var(--primary-600)}
  .btn-secondary{background:#fff; color:var(--text); border-color:var(--border)}
  .btn-secondary:hover{background:#f5f6f7}
  .btn-danger{background:var(--danger); color:#fff; border-color:var(--danger)}
  .btn-danger:hover{filter:brightness(.95)}
  .btn-success{background:#198754; color:#fff; border-color:#198754}
  .btn-info{background:#0ea5e9; color:#fff; border-color:#0ea5e9}

  .btn[disabled]{opacity:.65; pointer-events:none}

  /* Footer button row */
  .d-flex{display:flex; align-items:center}
  .justify-content-end{justify-content:flex-end}
  .gap-2{gap:.5rem}

  /* Alerts */
  .alert{
    padding:12px 14px; border-radius:10px; border:1px solid transparent; margin-bottom:14px;
    display:flex; align-items:center; gap:.6rem;
  }
  .alert-success{background:#ecfdf5; border-color:#d1fae5; color:#065f46}
  .alert-error{background:#fef2f2; border-color:#fecaca; color:#7f1d1d}

  /* Section spacing inside form cards */
  .card + .card{margin-top:14px}
</style>

</head>
<body class="login-page">
<div class="auth-wrap">
    <div class="card">
        <div class="card-header">
            <h2 style="margin:0;"><?= htmlspecialchars($page_title) ?></h2>
            <p class="text-muted" style="margin:.25rem 0 0;">Provide your details to set up your investor profile<?= $registering ? ' (and account)' : '' ?>.</p>
        </div>
        <div class="card-body">
            <?php if (!empty($message)): ?>
                <div class="alert alert-<?= $message_type === 'error' ? 'error' : 'success' ?>">
                    <i class="fas fa-<?= $message_type === 'error' ? 'exclamation-circle' : 'check-circle' ?>"></i>
                    <?= $message ?>
                </div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data" data-validate="true">
                <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

                <?php if ($registering): ?>
                <!-- Public registration (optional) -->
                <div class="card" style="margin-bottom:14px;">
                    <div class="card-header"><strong>Account (Login) Details</strong></div>
                    <div class="card-body grid">
                        <div class="form-group">
                            <label>Username <span class="text-danger">*</span></label>
                            <input class="form-control" name="username" required>
                        </div>
                        <div class="form-group">
                            <label>Email <span class="text-danger">*</span></label>
                            <input class="form-control" type="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label>Password <span class="text-danger">*</span></label>
                            <input class="form-control" type="password" name="password" required minlength="6">
                        </div>
                        <div class="form-group">
                            <label>Confirm Password <span class="text-danger">*</span></label>
                            <input class="form-control" type="password" name="confirm_password" required minlength="6">
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <div class="card" style="margin-bottom:14px;">
                    <div class="card-header"><strong>Personal Details</strong></div>
                    <div class="card-body grid">
                        <div class="form-group">
                            <label>First Name <span class="text-danger">*</span></label>
                            <input class="form-control" name="first_name" required>
                        </div>
                        <div class="form-group">
                            <label>Last Name <span class="text-danger">*</span></label>
                            <input class="form-control" name="last_name" required>
                        </div>
                        <div class="form-group">
                            <label>Phone <span class="text-danger">*</span></label>
                            <input class="form-control" name="phone" type="tel" required>
                        </div>
                        <div class="form-group">
                            <label>Date Joined <span class="text-danger">*</span></label>
                            <input class="form-control" type="date" name="date_joined" value="<?= htmlspecialchars($today) ?>" required>
                        </div>
                        <div class="form-group" style="grid-column: 1 / -1;">
                            <label>Address <span class="text-danger">*</span></label>
                            <input class="form-control" name="address" required>
                        </div>
                        <div class="form-group">
                            <label>City <span class="text-danger">*</span></label>
                            <input class="form-control" name="city" required>
                        </div>
                        <div class="form-group">
                            <label>State/Region</label>
                            <input class="form-control" name="state">
                        </div>
                        <div class="form-group">
                            <label>Country</label>
                            <input class="form-control" name="country" value="<?= htmlspecialchars(DEFAULT_COUNTRY) ?>">
                        </div>
                        <div class="form-group">
                            <label>Postal Code</label>
                            <input class="form-control" name="postal_code">
                        </div>
                        <!--<div class="form-group">
                            <label>Profile Picture</label>
                            <input class="form-control" type="file" name="profile_picture" accept="image/*">
                            <div class="help">JPG/PNG/WEBP, max a few MB.</div>
                        </div>-->
                    </div>
                </div>

                <div class="d-flex justify-content-end gap-2">
                    <?php if ($registering): ?>
                        <a class="btn btn-secondary" href="../index.php">Cancel</a>
                    <?php else: ?>
                        <a class="btn btn-secondary" href="dashboard.php">Cancel</a>
                    <?php endif; ?>
                    <button class="btn btn-primary" type="submit">
                        <i class="fas fa-save"></i> Save Profile
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="../assets/js/script.js"></script>
</body>
</html>
