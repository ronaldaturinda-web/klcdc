<?php
// investor/investments.php
declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../classes/Auth.php';

if (session_status() === PHP_SESSION_NONE) session_start();

$auth = new Auth();

// Must be logged in
if (!isLoggedIn()) {
    redirect('../index.php');
    exit;
}

// Optional: keep admins in admin area
if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    redirect('../admin/investments.php');
    exit;
}

/** Resolve PDO (compatible with your existing patterns) */
function resolvePDO(): PDO {
    if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) return $GLOBALS['pdo'];
    if (function_exists('getDbConnection')) {
        $p = getDbConnection(); if ($p instanceof PDO) return $p;
    }
    if (class_exists('Database')) {
        $db = new Database();
        if (method_exists($db,'connect'))       { $p = $db->connect();       if ($p instanceof PDO) return $p; }
        if (method_exists($db,'getConnection')) { $p = $db->getConnection(); if ($p instanceof PDO) return $p; }
    }
    throw new RuntimeException('Database connection not available.');
}

try {
    $pdo = resolvePDO();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    http_response_code(500);
    exit('Database connection not available.');
}

/** Helpers */
function moneyUGX(float $amount): string {
    // Use your global formatCurrency() if present, else a neat UGX formatter
    if (function_exists('formatCurrency')) return formatCurrency($amount);
    return 'UGX ' . number_format($amount, 0, '.', ',');
}
function validType(?string $t): ?string {
    $t = $t ? strtolower($t) : null;
    return in_array($t, ['cash','material','labor'], true) ? $t : null;
}
function parseDate(?string $s, string $eod = '00:00:00'): ?string {
    if (!$s) return null;
    $ts = strtotime($s);
    if (!$ts) return null;
    return date('Y-m-d', $ts) . ' ' . $eod;
}

/** Find the current investor_id from the logged-in user */
$userId = (int)($_SESSION['user_id'] ?? 0);
$investorId = 0;
if ($userId > 0) {
    $st = $pdo->prepare("SELECT id FROM investors WHERE user_id = ? AND status = 'active' LIMIT 1");
    $st->execute([$userId]);
    $row = $st->fetch();
    if ($row) $investorId = (int)$row['id'];
}
if ($investorId <= 0) {
    // Graceful message if profile not found
    $page_title = 'My Investments';
    include __DIR__ . '/includes/header.php';
    echo '<div class="main-content"><div class="card" style="margin:16px"><p>Your investor profile could not be found. Please contact support.</p></div></div>';
    include __DIR__ . '/includes/footer.php';
    exit;
}

/** Filters (GET) */
$qRaw  = trim($_GET['q']   ?? '');
$type  = validType($_GET['type'] ?? null);
$fromR = trim($_GET['from'] ?? '');
$toR   = trim($_GET['to']   ?? '');
$from  = $fromR ? parseDate($fromR,'00:00:00') : null;
$to    = $toR   ? parseDate($toR,'23:59:59')  : null;

/** Build WHERE for this investor */
function buildWhereForInvestor(array $filters, array &$params, int $investorId): string {
    $params[':inv_id'] = $investorId;
    $w = ["inv.investor_id = :inv_id"];
    if (!empty($filters['q'])) {
        $w[] = "(inv.transaction_id LIKE :q OR inv.receipt_number LIKE :q OR inv.description LIKE :q)";
        $params[':q'] = '%'.$filters['q'].'%';
    }
    if (!empty($filters['type'])) { $w[] = "inv.investment_type = :t"; $params[':t'] = $filters['type']; }
    if (!empty($filters['from'])) { $w[] = "inv.investment_date >= :from"; $params[':from'] = $filters['from']; }
    if (!empty($filters['to']))   { $w[] = "inv.investment_date <= :to";   $params[':to']   = $filters['to']; }
    return 'WHERE ' . implode(' AND ', $w);
}

/** Totals */
function totalsForInvestor(PDO $pdo, array $filters, int $investorId): array {
    $params=[]; $where=buildWhereForInvestor($filters,$params,$investorId);
    $sql="SELECT
            SUM(inv.amount) AS total_amount,
            SUM(CASE WHEN inv.investment_type='cash' THEN inv.amount ELSE 0 END) AS total_cash,
            SUM(CASE WHEN inv.investment_type='material' THEN inv.amount ELSE 0 END) AS total_material,
            SUM(CASE WHEN inv.investment_type='labor' THEN inv.amount ELSE 0 END) AS total_labor
          FROM investments inv
          $where";
    $st=$pdo->prepare($sql); $st->execute($params); $r=$st->fetch()?:[];
    return [
        'total_amount'   => (float)($r['total_amount']??0),
        'total_cash'     => (float)($r['total_cash']??0),
        'total_material' => (float)($r['total_material']??0),
        'total_labor'    => (float)($r['total_labor']??0),
    ];
}

/** Count + fetch */
function countInvestments(PDO $pdo, array $filters, int $investorId): int {
    $params=[]; $where=buildWhereForInvestor($filters,$params,$investorId);
    $st=$pdo->prepare("SELECT COUNT(*) AS c FROM investments inv $where");
    $st->execute($params); $row=$st->fetch();
    return (int)($row['c']??0);
}
function fetchInvestments(PDO $pdo, array $filters, int $investorId, int $limit, int $offset): array {
    $params=[]; $where=buildWhereForInvestor($filters,$params,$investorId);
    $sql="SELECT inv.id, inv.transaction_id, inv.receipt_number, inv.investment_type,
                 inv.amount, inv.description, inv.investment_date
          FROM investments inv
          $where
          ORDER BY inv.investment_date DESC, inv.id DESC
          LIMIT $limit OFFSET $offset";
    $st=$pdo->prepare($sql); $st->execute($params); return $st->fetchAll();
}

/** Optional: CSV export of this investor's records only */
if (($_GET['export'] ?? '') === 'csv') {
    $filters = ['q'=>$qRaw?:null,'type'=>$type,'from'=>$from,'to'=>$to];
    $params=[]; $where=buildWhereForInvestor($filters,$params,$investorId);
    $sql="SELECT inv.investment_date, inv.transaction_id, inv.receipt_number, inv.investment_type, inv.amount, inv.description
          FROM investments inv
          $where
          ORDER BY inv.investment_date DESC, inv.id DESC";
    $st=$pdo->prepare($sql); $st->execute($params); $rows=$st->fetchAll();

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=my_investments.csv');
    $out=fopen('php://output','w');
    fputcsv($out, ['Date','TXN','Receipt','Type','Amount(UGX)','Description']);
    foreach($rows as $r){
        fputcsv($out, [
            $r['investment_date'],
            $r['transaction_id'],
            $r['receipt_number'],
            strtoupper($r['investment_type']),
            number_format((float)$r['amount'],0,'.',','),
            (string)$r['description'],
        ]);
    }
    fclose($out); exit;
}

/** Pagination + data */
$filters = ['q'=>$qRaw?:null,'type'=>$type,'from'=>$from,'to'=>$to,'from_raw'=>$fromR,'to_raw'=>$toR];
$perPage = max(10,(int)($_GET['per'] ?? 25));
$page    = max(1,(int)($_GET['page'] ?? 1));
$total   = countInvestments($pdo,$filters,$investorId);
$pages   = max(1,(int)ceil($total/$perPage));
$page    = min($page,$pages);
$offset  = ($page-1)*$perPage;

$rows   = fetchInvestments($pdo,$filters,$investorId,$perPage,$offset);
$totals = totalsForInvestor($pdo,$filters,$investorId);

/** Page */
$page_title = 'My Investments';
include __DIR__ . '/includes/header.php';
?>
<div class="main-content">
  <div class="card" style="margin-bottom:12px;">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;">
      <h1 style="margin:0;font-size:1.35rem">My Investments</h1>
      <div style="display:flex;gap:8px;">
        <a class="btn btn-secondary" href="dashboard.php">← Dashboard</a>
        <a class="btn btn-secondary" href="?<?=http_build_query(array_merge($_GET,['export'=>'csv','page'=>null]))?>">Export CSV</a>
      </div>
    </div>

    <!-- Filters -->
    <form class="toolbar" method="get" style="display:flex;gap:10px;flex-wrap:wrap;align-items:end;margin-top:12px">
      <div class="field" style="display:flex;flex-direction:column;gap:4px">
        <label>Search</label>
        <input type="text" name="q" value="<?=htmlspecialchars($qRaw)?>" placeholder="receipt, TXN, note" style="padding:10px 12px;border:1px solid #e8edf1;border-radius:12px;background:#fff;outline:none">
      </div>
      <div class="field" style="display:flex;flex-direction:column;gap:4px">
        <label>Type</label>
        <select name="type" style="padding:10px 12px;border:1px solid #e8edf1;border-radius:12px;background:#fff;outline:none">
          <option value="">All</option>
          <option value="cash"     <?=$type==='cash'?'selected':''?>>Cash</option>
          <option value="material" <?=$type==='material'?'selected':''?>>Material</option>
          <option value="labor"    <?=$type==='labor'?'selected':''?>>Labor</option>
        </select>
      </div>
      <div class="field" style="display:flex;flex-direction:column;gap:4px">
        <label>From</label>
        <input type="date" name="from" value="<?=htmlspecialchars($fromR)?>" style="padding:10px 12px;border:1px solid #e8edf1;border-radius:12px;background:#fff;outline:none">
      </div>
      <div class="field" style="display:flex;flex-direction:column;gap:4px">
        <label>To</label>
        <input type="date" name="to" value="<?=htmlspecialchars($toR)?>" style="padding:10px 12px;border:1px solid #e8edf1;border-radius:12px;background:#fff;outline:none">
      </div>
      <div class="field" style="display:flex;flex-direction:column;gap:4px">
        <label>Per page</label>
        <select name="per" style="padding:10px 12px;border:1px solid #e8edf1;border-radius:12px;background:#fff;outline:none">
          <?php foreach([10,25,50,100] as $opt): ?>
            <option value="<?=$opt?>" <?=$perPage===$opt?'selected':''?>><?=$opt?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field" style="display:flex;gap:8px;flex-direction:row;align-items:center;">
        <button class="btn btn-primary" type="submit">Apply</button>
        <a class="btn btn-secondary" href="investments.php">Reset</a>
      </div>
    </form>

    <!-- Totals -->
    <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:12px">
      <div class="badge" style="display:inline-flex;align-items:center;gap:6px;background:#eef5ef;color:#2c5530;border-radius:999px;padding:6px 10px;border:1px solid #dce9de">
        <strong>Total:</strong> <?=moneyUGX($totals['total_amount'])?>
      </div>
      <div class="badge" style="display:inline-flex;align-items:center;gap:6px;background:#eef5ef;color:#2c5530;border-radius:999px;padding:6px 10px;border:1px solid #dce9de">
        <strong>Cash:</strong> <?=moneyUGX($totals['total_cash'])?>
      </div>
      <div class="badge" style="display:inline-flex;align-items:center;gap:6px;background:#eef5ef;color:#2c5530;border-radius:999px;padding:6px 10px;border:1px solid #dce9de">
        <strong>Material:</strong> <?=moneyUGX($totals['total_material'])?>
      </div>
      <div class="badge" style="display:inline-flex;align-items:center;gap:6px;background:#eef5ef;color:#2c5530;border-radius:999px;padding:6px 10px;border:1px solid #dce9de">
        <strong>Labor:</strong> <?=moneyUGX($totals['total_labor'])?>
      </div>
      <div class="badge" style="display:inline-flex;align-items:center;gap:6px;background:#eef5ef;color:#2c5530;border-radius:999px;padding:6px 10px;border:1px solid #dce9de">
        <strong>Records:</strong> <?=$total?>
      </div>
    </div>
  </div>

  <!-- Table -->
  <div class="card">
    <div style="overflow:auto">
      <table style="width:100%;border-collapse:separate;border-spacing:0 8px">
        <thead>
          <tr>
            <th style="text-align:left;padding:0 10px;min-width:150px;color:#374151;font-size:.9rem;">Date & Time</th>
            <th style="text-align:left;padding:0 10px;color:#374151;font-size:.9rem;">Type</th>
            <th style="text-align:right;padding:0 10px;min-width:120px;color:#374151;font-size:.9rem;">Amount</th>
            <th style="text-align:left;padding:0 10px;color:#374151;font-size:.9rem;">Receipt</th>
            <th style="text-align:left;padding:0 10px;color:#374151;font-size:.9rem;">TXN</th>
            <th style="text-align:left;padding:0 10px;min-width:140px;color:#374151;font-size:.9rem;">Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php if(!$rows): ?>
          <tr><td colspan="6" style="text-align:center;color:#6b7280;background:transparent;border:none;box-shadow:none">No investments found.</td></tr>
        <?php else: foreach($rows as $r): ?>
          <tr style="box-shadow:0 4px 12px rgba(0,0,0,.04);border-radius:12px">
            <td style="background:#fff;border:1px solid #e8edf1;border-left:1px solid #e8edf1;border-top-left-radius:12px;border-bottom-left-radius:12px;padding:12px 10px">
              <?=htmlspecialchars($r['investment_date'])?>
            </td>
            <td style="background:#fff;border:1px solid #e8edf1;padding:12px 10px">
              <span class="badge" style="display:inline-flex;align-items:center;gap:6px;background:#eef5ef;color:#2c5530;border-radius:999px;padding:4px 10px;border:1px solid #dce9de">
                <?=strtoupper(htmlspecialchars($r['investment_type']))?>
              </span>
            </td>
            <td style="background:#fff;border:1px solid #e8edf1;text-align:right;padding:12px 10px">
              <?=moneyUGX((float)$r['amount'])?>
            </td>
            <td style="background:#fff;border:1px solid #e8edf1;padding:12px 10px">
              <?=htmlspecialchars($r['receipt_number'])?>
            </td>
            <td style="background:#fff;border:1px solid #e8edf1;padding:12px 10px">
              <?=htmlspecialchars($r['transaction_id'])?>
            </td>
            <td style="background:#fff;border:1px solid #e8edf1;border-right:1px solid #e8edf1;border-top-right-radius:12px;border-bottom-right-radius:12px;padding:12px 10px">
              <a class="btn btn-secondary" href="print_receipt.php?id=<?= (int)$r['id'] ?>" target="_blank" rel="noopener">Print Receipt</a>
            </td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>

    <!-- Pagination -->
    <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px">
      <?php
        $qs=$_GET; unset($qs['page']); $base='?'.http_build_query($qs);
        echo $page>1 ? '<a class="btn btn-secondary" href="'.$base.'&page='.($page-1).'">« Prev</a>' : '<span class="btn btn-secondary" style="opacity:.6">« Prev</span>';
        $window=5; $start=max(1,$page-$window); $end=min($pages,$page+$window);
        for($i=$start;$i<=$end;$i++){
          if ($i===$page) echo '<span class="btn btn-primary">'.$i.'</span>';
          else echo '<a class="btn btn-secondary" href="'.$base.'&page='.$i.'">'.$i.'</a>';
        }
        echo $page<$pages ? '<a class="btn btn-secondary" href="'.$base.'&page='.($page+1).'">Next »</a>' : '<span class="btn btn-secondary" style="opacity:.6">Next »</span>';
      ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
