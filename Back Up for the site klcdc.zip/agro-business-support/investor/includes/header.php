<?php
/**
 * Investor Header Include (scrollable sidebar)
 * National Agro Business Support Initiative
 */

if (!isLoggedIn()) {
    redirect('../index.php');
}

// Redirect admin to admin dashboard
if (isAdmin()) {
    redirect('../admin/dashboard.php');
}

if (!isset($page_title)) $page_title = 'Dashboard';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($page_title) ?> - <?= APP_NAME ?></title>

  <link rel="stylesheet" href="../assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="icon" type="image/x-icon" href="../assets/images/favicon.ico">
  <link rel="icon" type="image/x-icon" href="favicon.ico">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">


  <style>
    /* --- Layout utilities (unchanged) --- */
    .row { display:flex; flex-wrap:wrap; margin:-0.75rem; }
    .col-md-3,.col-md-4,.col-md-6,.col-md-8,.col-md-12 { padding:0.75rem; }
    .col-md-3{flex:0 0 25%;max-width:25%}
    .col-md-4{flex:0 0 33.333333%;max-width:33.333333%}
    .col-md-6{flex:0 0 50%;max-width:50%}
    .col-md-8{flex:0 0 66.666667%;max-width:66.666667%}
    .col-md-12{flex:0 0 100%;max-width:100%}
    @media (max-width:768px){
      .col-md-3,.col-md-4,.col-md-6,.col-md-8{flex:0 0 100%;max-width:100%}
    }

    .page-header{margin-bottom:2rem;padding-bottom:1rem;border-bottom:1px solid var(--border-color)}
    .page-header h1{margin-bottom:0.5rem;color:var(--primary-color)}

    /* --- BRAND BLOCKS (unchanged look) --- */
    .brand-block{ display:flex; flex-direction:column; line-height:1.15; }
    .sidebar .sidebar-header .brand-abbr{
      color:#fff; font-weight:800; font-size:1.6rem; letter-spacing:.4px; margin:0 0 2px 0;
    }
    .sidebar .sidebar-header .brand-full{
      color:rgba(255,255,255,.92); font-weight:600; font-size:.88rem; margin:0 0 2px 0;
    }
    .sidebar .sidebar-header .brand-meta{
      color:rgba(255,255,255,.88); font-size:.8rem; text-transform:uppercase; letter-spacing:.1em; margin:2px 0 0 0;
    }

    /* --- Mobile header (unchanged look) --- */
    .mobile-header{
      display:none; background-color:var(--primary-color); color:#fff;
      padding:0.75rem 1rem; position:fixed; top:0; left:0; right:0; z-index:1001;
    }
    .mobile-header .brand-abbr{ color:#fff; font-weight:800; font-size:1.1rem; margin:0; }
    .mobile-header .brand-full{ color:rgba(255,255,255,.95); font-weight:600; font-size:.78rem; margin:.1rem 0 0 0; }
    .mobile-header .brand-meta{ color:rgba(255,255,255,.9); font-size:.72rem; text-transform:uppercase; letter-spacing:.08em; margin:.15rem 0 0 0; }
    .mobile-header .sidebar-toggle{ background:none; border:0; color:#fff; font-size:1.25rem; cursor:pointer; margin-left:auto; }

    /* --- MAKE SIDEBAR SCROLLABLE & STICKY --- */
    .sidebar {
      position: fixed;
      top: 0; left: 0;
      width: 260px;
      height: 100vh;                 /* full viewport height */
      overflow-y: auto;              /* <-- scrolling */
      -webkit-overflow-scrolling: touch;
      z-index: 1000;
      /* keep your existing theme colors from style.css */
    }
    .sidebar-header { position: sticky; top: 0; z-index: 1; } /* header in sidebar stays visible */

    /* Push page content to the right of the fixed sidebar */
    .main-content {
      margin-left: 260px;
      padding: 1.5rem;
    }

    /* Dark overlay for mobile when the drawer is open */
    .sidebar-overlay {
      display:none; position:fixed; inset:0;
      background:rgba(0,0,0,.5); z-index:999;
    }

    /* --- Mobile drawer behavior --- */
    @media (max-width: 768px){
      .mobile-header{display:flex; align-items:center; gap:.75rem}
      .main-content{margin-left:0; padding-top:4rem;}   /* space under mobile header */

      .sidebar{
        transform: translateX(-100%);   /* hidden by default on mobile */
        transition: transform .25s ease;
      }
      .sidebar.open{
        transform: translateX(0);       /* slide in */
      }
      .sidebar-overlay.show{ display:block; }
    }
  </style>
</head>
<body>
  <!-- Mobile Header -->
  <div class="mobile-header">
    <div class="brand-block">
      <div class="brand-abbr">NABSI</div>
      <div class="brand-full">          </div>
      <div class="brand-meta">Investor Panel</div>
    </div>
    <button class="sidebar-toggle" id="sidebarToggle" aria-label="Toggle menu">
      <i class="fas fa-bars"></i>
    </button>
  </div>

  <!-- Sidebar Overlay -->
  <div class="sidebar-overlay" id="sidebarOverlay"></div>

  <!-- Sidebar (scrollable) -->
  <div class="sidebar">
    <div class="sidebar-header">
      <div class="brand-block">
        <div class="brand-abbr">KLCDC</div>
        <div class="brand-full">Kaliro Lord's Community Development Corporation</div>
        <div class="brand-meta">Investor Panel</div>
      </div>
    </div>

    <ul class="sidebar-menu">
      <li>
        <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>">
          <i class="fas fa-chart-line"></i> Dashboard
        </a>
      </li>
      <li>
        <a href="investments.php" class="<?= basename($_SERVER['PHP_SELF']) == 'investments.php' ? 'active' : '' ?>">
          <i class="fas fa-money-bill-wave"></i> My Investments
        </a>
      </li>
      <li>
        <a href="profile.php" class="<?= basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : '' ?>">
          <i class="fas fa-user"></i> My Profile
        </a>
      </li>
      <li>
        <a href="download_statement.php" target="_blank">
          <i class="fas fa-file-download"></i> Download Statement
        </a>
      </li>
      <li>
        <a href="change_password.php" class="<?= basename($_SERVER['PHP_SELF']) == 'change_password.php' ? 'active' : '' ?>">
          <i class="fas fa-key"></i> Change Password
        </a>
      </li>
      <li>
        <a href="../admin/dashboard.php" style="border-top: 1px solid var(--border-color); margin-top: 1rem; padding-top: 1rem;">
          <i class="fas fa-user-shield"></i> Refresh
        </a>
      </li>
      <li>
        <a href="logout.php" data-confirm="Are you sure you want to logout?">
          <i class="fas fa-sign-out-alt"></i> Logout
        </a>
      </li>
    </ul>

    <div class="sidebar-footer" style="padding: 1rem; text-align: center; color: #6c757d; font-size: 0.875rem; margin-top: auto;">
      <p>Logged in as:<br><strong><?= htmlspecialchars($_SESSION['username'] ?? '') ?></strong></p>
      <p>&copy; <?= date('Y') ?> AgriSupport</p>
    </div>
  </div>

  <!-- Alert Container -->
  <div id="alertContainer"></div>

  <!-- Your existing JS -->
  <script src="../assets/js/script.js"></script>

  <!-- Tiny helper (non-invasive) to ensure the drawer toggles -->
  <script>
    (function () {
      const sidebar = document.querySelector('.sidebar');
      const overlay = document.getElementById('sidebarOverlay');
      const toggle  = document.getElementById('sidebarToggle');

      if (!sidebar || !overlay || !toggle) return;

      function openSidebar() {
        sidebar.classList.add('open');
        overlay.classList.add('show');
        document.body.style.overflow = 'hidden';
      }
      function closeSidebar() {
        sidebar.classList.remove('open');
        overlay.classList.remove('show');
        document.body.style.overflow = '';
      }

      toggle.addEventListener('click', openSidebar);
      overlay.addEventListener('click', closeSidebar);

      // Close on ESC
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeSidebar();
      });
    })();
  </script>
