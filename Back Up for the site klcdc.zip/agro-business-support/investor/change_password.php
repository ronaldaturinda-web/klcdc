<?php
// investor/change_password.php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) session_start();

require_once __DIR__ . '/../config/config.php';

// Auth: only logged-in investors (non-admin) can access
if (!isLoggedIn()) {
    redirect('../index.php');
}
if (isAdmin()) {
    redirect('../admin/dashboard.php');
}

/** Robust PDO resolver (works with your various config styles) */
function resolvePDO(): PDO {
    if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) return $GLOBALS['pdo'];
    if (function_exists('getDbConnection')) { $p = getDbConnection(); if ($p instanceof PDO) return $p; }
    if (class_exists('Database')) {
        $db = new Database();
        if (method_exists($db, 'connect'))       { $p = $db->connect();       if ($p instanceof PDO) return $p; }
        if (method_exists($db, 'getConnection')) { $p = $db->getConnection(); if ($p instanceof PDO) return $p; }
    }
    throw new RuntimeException('Database connection not available.');
}

try {
    $pdo = resolvePDO();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    http_response_code(500);
    exit('Database connection error.');
}

function h(?string $s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

$userId = (int)($_SESSION['user_id'] ?? 0);
$username = (string)($_SESSION['username'] ?? '');

$errors = [];
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request. Please refresh the page and try again.';
    } else {
        $current = (string)($_POST['current_password'] ?? '');
        $new     = (string)($_POST['new_password'] ?? '');
        $confirm = (string)($_POST['confirm_password'] ?? '');

        // Basic validation
        if ($current === '' || $new === '' || $confirm === '') $errors[] = 'All fields are required.';
        if ($new !== $confirm) $errors[] = 'New password and confirmation do not match.';
        if (strlen($new) < 8) $errors[] = 'New password must be at least 8 characters.';
        if (!preg_match('/[A-Za-z]/', $new) || !preg_match('/\d/', $new)) {
            $errors[] = 'New password must include at least one letter and one number.';
        }
        if ($current === $new) $errors[] = 'New password must be different from current password.';

        if (!$errors) {
            // Fetch current hash
            $st = $pdo->prepare("SELECT password FROM users WHERE id = ? LIMIT 1");
            $st->execute([$userId]);
            $row = $st->fetch();

            if (!$row || !password_verify($current, (string)$row['password'])) {
                $errors[] = 'Your current password is incorrect.';
            } else {
                // Update to new hash
                $hash = password_hash($new, PASSWORD_DEFAULT);
                $u = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                $u->execute([$hash, $userId]);
                $success = 'Password changed successfully.';
            }
        }
    }
}

$page_title = 'Change Password';
include __DIR__ . '/includes/header.php';
?>
<div class="main-content">
  <div class="page-header">
    <h1><i class="fas fa-key"></i> Change Password</h1>
    <p class="text-muted">Update your account password</p>
  </div>

  <?php if ($errors): ?>
    <div class="alert alert-error">
      <i class="fas fa-exclamation-circle"></i>
      <ul style="margin:0;padding-left:18px">
        <?php foreach ($errors as $e): ?>
          <li><?=h($e)?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php elseif ($success): ?>
    <div class="alert alert-success">
      <i class="fas fa-check-circle"></i>
      <?=h($success)?>
    </div>
  <?php endif; ?>

  <div class="card">
    <div class="card-body">
      <form method="post" novalidate>
        <input type="hidden" name="csrf_token" value="<?=generateCSRFToken()?>">

        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label>Current Password</label>
              <input class="form-control" type="password" name="current_password" autocomplete="current-password" required>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label>New Password</label>
              <input class="form-control" type="password" name="new_password" autocomplete="new-password" required>
              <small class="text-muted">At least 8 characters, include letters and numbers.</small>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label>Confirm New Password</label>
              <input class="form-control" type="password" name="confirm_password" autocomplete="new-password" required>
            </div>
          </div>
        </div>

        <div class="d-flex justify-content-end gap-2 mt-3">
          <a href="dashboard.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Cancel</a>
          <button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> Update Password</button>
        </div>
      </form>
    </div>
  </div>
</div>

<style>
/* Light layout polish (keeps your theme) */
.main-content .card { border-radius: 14px; }
.main-content .form-group label { color: #6b7280; font-size: .95rem; }
.main-content .form-control {
  border-radius: 12px; border: 1px solid #e8edf1; padding: 12px 14px;
}
.main-content .form-control:focus {
  outline: none; box-shadow: 0 0 0 4px #d1fae5; border-color: #4a7c59;
}
.main-content .alert { border-radius: 12px; }
</style>

<?php include __DIR__ . '/includes/footer.php'; ?>
