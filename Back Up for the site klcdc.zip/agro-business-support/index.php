<?php
/**
 * Login Page
 * National Agro Business Support Initiative
 */

require_once 'config/config.php';
require_once 'classes/Auth.php';

$auth = new Auth();

// Ensure session counter exists
if (!isset($_SESSION['login_failures'])) {
    $_SESSION['login_failures'] = 0;
}

// Already logged in? Send to the right dashboard
if (isLoggedIn()) {
    if (isAdmin()) {
        redirect('admin/dashboard.php');
    } else {
        redirect('investor/dashboard.php');
    }
}

$error_message = '';
$success_message = '';

// Handle login
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    if (!verifyCSRFToken($_POST['csrf_token'])) {
        $error_message = 'Invalid request. Please try again.';
        // Count as a failure to avoid leaking CSRF validation state
        $_SESSION['login_failures'] = ($_SESSION['login_failures'] ?? 0) + 1;
    } else {
        $username = sanitize_input($_POST['username']);
        $password = $_POST['password'];

        if (empty($username) || empty($password)) {
            $error_message = 'Please enter both username and password.';
            $_SESSION['login_failures'] = ($_SESSION['login_failures'] ?? 0) + 1;
        } else {
            $result = $auth->login($username, $password);
            if ($result['success']) {
                // Reset failures on success
                $_SESSION['login_failures'] = 0;
                redirect($result['role'] === 'admin' ? 'admin/dashboard.php' : 'investor/dashboard.php');
            } else {
                $error_message = $result['message'];
                $_SESSION['login_failures'] = ($_SESSION['login_failures'] ?? 0) + 1;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - <?php echo APP_NAME; ?></title>
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <!-- Small helper style so the logo image replaces the old icon cleanly -->
  <style>
    /* Circular logo container */
    .login-header .logo{
        width: 84px;
        height: 84px;
        margin: 0 auto 10px;
        border-radius: 50%;
        overflow: hidden;
        background: #fff;
        border: 2px solid rgba(0,0,0,.06);
        box-shadow: 0 2px 10px rgba(0,0,0,.08);
        display: grid;
        place-items: center;
    }
    .login-header .logo img{
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: block;
    }
    .login-header .logo i{ font-size: 42px; color: #2c5530; }
    /* Tiny helper for the register hint */
    .register-hint{
        margin-top: 10px;
        text-align: center;
        font-size: .95rem;
        color: #374151;
    }
    .register-hint a{
        color: #2c5530;
        font-weight: 600;
        text-decoration: none;
    }
    .register-hint a:hover{ text-decoration: underline; }
  </style>
</head>
<body class="login-page">
  <div class="login-container">
    <div class="login-card">
      <div class="login-header">
        <div class="logo">
          <!-- REPLACED the seedling icon with your logo.png in the project root -->
          <img src="logo.png" alt="NABSI Logo"
               onerror="this.closest('.logo').innerHTML='<i class=&quot;fas fa-seedling&quot;></i>';"/>
        </div>
        <h1>KALIRO LORD'S COMMUNITY DEVELOPMENT CORPRATION</h1>
        <p>Login Here</p>
      </div>

      <div class="login-form">
        <?php if (!empty($error_message)): ?>
          <div class="alert alert-error">
            <i class="fas fa-exclamation-circle"></i>
            <?php echo htmlspecialchars($error_message); ?>
          </div>
        <?php endif; ?>

        <?php if (!empty($success_message)): ?>
          <div class="alert alert-success">
            <i class="fas fa-check-circle"></i>
            <?php echo htmlspecialchars($success_message); ?>
          </div>
        <?php endif; ?>

        <form method="POST" action="" id="loginForm">
          <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">

          <div class="form-group">
            <label for="username">
              <i class="fas fa-user"></i>
              Username or Email
            </label>
            <input type="text" id="username" name="username"
                   value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                   required>
          </div>

          <div class="form-group">
            <label for="password">
              <i class="fas fa-lock"></i>
              Password
            </label>
            <div class="password-input">
              <input type="password" id="password" name="password" required>
              <button type="button" class="password-toggle" onclick="togglePassword()">
                <i class="fas fa-eye" id="passwordIcon"></i>
              </button>
            </div>
          </div>

          <button type="submit" name="login" class="btn btn-primary btn-block">
            <i class="fas fa-sign-in-alt"></i>
            Login
          </button>
        </form>

        <?php if (($_SESSION['login_failures'] ?? 0) >= 2): ?>
          <div class="register-hint">
            No account? <a href="investor/complete_profile.php">Register</a>
          </div>
        <?php endif; ?>
      </div>

      <div class="login-footer">
        <p>&copy; <?php echo date('Y'); ?>-Kaliro Lords's Community Development Corporation</p>
      </div>
    </div>
  </div>

  <script src="assets/js/script.js"></script>
  <script>
    function togglePassword() {
      const passwordInput = document.getElementById('password');
      const passwordIcon = document.getElementById('passwordIcon');

      if (passwordInput.type === 'password') {
          passwordInput.type = 'text';
          passwordIcon.classList.remove('fa-eye');
          passwordIcon.classList.add('fa-eye-slash');
      } else {
          passwordInput.type = 'password';
          passwordIcon.classList.remove('fa-eye-slash');
          passwordIcon.classList.add('fa-eye');
      }
    }

    // Basic check before submit
    document.getElementById('loginForm').addEventListener('submit', function(e) {
      const username = document.getElementById('username').value.trim();
      const password = document.getElementById('password').value;
      if (!username || !password) {
          e.preventDefault();
          alert('Please fill in all fields.');
      }
    });
  </script>
</body>
</html>
