<?php
/**
 * Authentication Class
 * National Agro Business Support Initiative
 */

require_once __DIR__ . '/../config/config.php';


class Auth {
    private $conn;

    public function __construct() {
        $this->conn = getDbConnection();
    }

    /**
     * Login user
     */
    public function login($username, $password) {
        try {
            // Check for too many failed attempts
            if ($this->isAccountLocked($username)) {
                return [
                    'success' => false,
                    'message' => 'Account locked due to too many failed attempts. Try again later.'
                ];
            }

            $query = "SELECT u.id, u.username, u.email, u.password, u.role, u.status
                     FROM users u
                     WHERE (u.username = :username OR u.email = :username) AND u.status = 'active'";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':username', $username);
            $stmt->execute();

            if ($stmt->rowCount() == 1) {
                $user = $stmt->fetch();

                if (password_verify($password, $user['password'])) {
                    // Reset failed attempts
                    $this->resetFailedAttempts($username);

                    // Create session
                    $this->createSession($user);

                    logActivity("User login successful", $user['id']);

                    return [
                        'success' => true,
                        'message' => 'Login successful',
                        'role' => $user['role']
                    ];
                } else {
                    // Record failed attempt
                    $this->recordFailedAttempt($username);
                    logActivity("Failed login attempt for username: $username");

                    return [
                        'success' => false,
                        'message' => 'Invalid username or password'
                    ];
                }
            } else {
                // Record failed attempt
                $this->recordFailedAttempt($username);
                logActivity("Failed login attempt for username: $username");

                return [
                    'success' => false,
                    'message' => 'Invalid username or password'
                ];
            }
        } catch (Exception $e) {
            error_log("Login error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Login failed. Please try again.'
            ];
        }
    }

    /**
     * Create user session
     */
    private function createSession($user) {
        // Regenerate session ID for security
        session_regenerate_id(true);

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['login_time'] = time();
        $_SESSION['last_activity'] = time();

        // Store session in database
        $session_id = session_id();
        $ip_address = $_SERVER['REMOTE_ADDR'];
        $user_agent = $_SERVER['HTTP_USER_AGENT'];

        $query = "INSERT INTO user_sessions (id, user_id, ip_address, user_agent)
                 VALUES (:session_id, :user_id, :ip_address, :user_agent)
                 ON DUPLICATE KEY UPDATE last_activity = CURRENT_TIMESTAMP";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':session_id', $session_id);
        $stmt->bindParam(':user_id', $user['id']);
        $stmt->bindParam(':ip_address', $ip_address);
        $stmt->bindParam(':user_agent', $user_agent);
        $stmt->execute();
    }

    /**
     * Logout user
     */
    public function logout() {
        if (isset($_SESSION['user_id'])) {
            $user_id = $_SESSION['user_id'];

            // Remove session from database
            $session_id = session_id();
            $query = "DELETE FROM user_sessions WHERE id = :session_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':session_id', $session_id);
            $stmt->execute();

            logActivity("User logout", $user_id);
        }

        // Destroy session
        session_unset();
        session_destroy();

        return true;
    }

    /**
     * Check if session is valid
     */
    public function validateSession() {
        if (!isset($_SESSION['user_id'])) {
            return false;
        }

        // Check session timeout
        if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT)) {
            $this->logout();
            return false;
        }

        // Update last activity
        $_SESSION['last_activity'] = time();

        // Update session in database
        $session_id = session_id();
        $query = "UPDATE user_sessions SET last_activity = CURRENT_TIMESTAMP WHERE id = :session_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':session_id', $session_id);
        $stmt->execute();

        return true;
    }

    /**
     * Record failed login attempt
     */
    private function recordFailedAttempt($username) {
        $ip_address = $_SERVER['REMOTE_ADDR'];
        $attempt_time = date('Y-m-d H:i:s');

        if (!isset($_SESSION['failed_attempts'])) {
            $_SESSION['failed_attempts'] = [];
        }

        $_SESSION['failed_attempts'][$username] = [
            'count' => isset($_SESSION['failed_attempts'][$username]['count']) ?
                      $_SESSION['failed_attempts'][$username]['count'] + 1 : 1,
            'last_attempt' => $attempt_time,
            'ip' => $ip_address
        ];
    }

    /**
     * Reset failed attempts
     */
    private function resetFailedAttempts($username) {
        if (isset($_SESSION['failed_attempts'][$username])) {
            unset($_SESSION['failed_attempts'][$username]);
        }
    }

    /**
     * Check if account is locked
     */
    private function isAccountLocked($username) {
        if (!isset($_SESSION['failed_attempts'][$username])) {
            return false;
        }

        $attempts = $_SESSION['failed_attempts'][$username];

        if ($attempts['count'] >= MAX_LOGIN_ATTEMPTS) {
            $lock_time = strtotime($attempts['last_attempt']) + LOCKOUT_TIME;
            if (time() < $lock_time) {
                return true;
            } else {
                // Lock time expired, reset attempts
                $this->resetFailedAttempts($username);
                return false;
            }
        }

        return false;
    }

    /**
     * Change password
     */
    public function changePassword($user_id, $current_password, $new_password) {
        try {
            // Verify current password
            $query = "SELECT password FROM users WHERE id = :user_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();

            $user = $stmt->fetch();

            if (!password_verify($current_password, $user['password'])) {
                return [
                    'success' => false,
                    'message' => 'Current password is incorrect'
                ];
            }

            // Update password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $query = "UPDATE users SET password = :password, updated_at = CURRENT_TIMESTAMP WHERE id = :user_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':password', $hashed_password);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();

            logActivity("Password changed", $user_id);

            return [
                'success' => true,
                'message' => 'Password changed successfully'
            ];

        } catch (Exception $e) {
            error_log("Password change error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Failed to change password'
            ];
        }
    }

    /**
     * Get user info
     */
    public function getUserInfo($user_id) {
        try {
            $query = "SELECT u.*, i.* FROM users u
                     LEFT JOIN investors i ON u.id = i.user_id
                     WHERE u.id = :user_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();

            return $stmt->fetch();
        } catch (Exception $e) {
            error_log("Get user info error: " . $e->getMessage());
            return false;
        }
    }
}
?>
