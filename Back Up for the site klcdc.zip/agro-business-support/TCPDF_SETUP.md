# TCPDF Library Setup Guide

This application uses TCPDF for generating PDF receipts and reports. Since TCPDF is an external library, it needs to be downloaded and installed separately.

## Installation Steps

### Method 1: Download from Official Website

1. **Download TCPDF**
   - Go to: https://tcpdf.org/
   - Download the latest stable version (zip file)

2. **Extract and Install**
   ```bash
   # Create vendor directory if it doesn't exist
   mkdir -p vendor

   # Extract TCPDF to vendor/tcpdf/
   unzip tcpdf_6_4_4.zip -d vendor/
   mv vendor/tcpdf_6_4_4 vendor/tcpdf
   ```

3. **Verify Installation**
   - Ensure the file `vendor/tcpdf/tcpdf.php` exists
   - Check that the classes/PDFGenerator.php can include the file

### Method 2: Download via Composer (if available)

```bash
composer require tecnickcom/tcpdf
```

If using Composer, update the include path in `classes/PDFGenerator.php`:
```php
require_once '../vendor/tecnickcom/tcpdf/tcpdf.php';
```

### Method 3: Manual Download with cURL/wget

```bash
# Create vendor directory
mkdir -p vendor

# Download TCPDF
cd vendor
wget https://github.com/tecnickcom/TCPDF/archive/6.4.4.zip
unzip 6.4.4.zip
mv TCPDF-6.4.4 tcpdf
cd ..
```

## Directory Structure After Installation

```
agro-business-support/
├── vendor/
│   └── tcpdf/
│       ├── tcpdf.php          # Main TCPDF class
│       ├── config/
│       ├── fonts/
│       ├── include/
│       └── examples/
```

## Testing TCPDF Installation

Create a test file `test_tcpdf.php` in the root directory:

```php
<?php
require_once 'vendor/tcpdf/tcpdf.php';

// Create new PDF document
$pdf = new TCPDF();

// Add a page
$pdf->AddPage();

// Set font
$pdf->SetFont('helvetica', '', 12);

// Add content
$pdf->Cell(0, 10, 'TCPDF Installation Test', 0, 1, 'C');

// Output PDF
$pdf->Output('test.pdf', 'I');
?>
```

Run this file in your browser. If TCPDF is correctly installed, you should see a PDF with the test message.

## Troubleshooting

### Common Issues

1. **File not found error**
   - Check the path in `classes/PDFGenerator.php`
   - Ensure TCPDF files are in the correct directory

2. **Permission errors**
   - Set appropriate permissions:
     ```bash
     chmod -R 755 vendor/tcpdf/
     chmod -R 755 temp/
     ```

3. **Font issues**
   - TCPDF includes standard fonts, but for special characters, ensure UTF-8 encoding
   - Use 'helvetica' or 'dejavusans' fonts for broader character support

4. **Memory errors**
   - Increase PHP memory limit in php.ini:
     ```php
     memory_limit = 256M
     ```

### Alternative: Simplified PDF Generation

If TCPDF installation is problematic, you can use a simpler approach by creating HTML-based "PDFs" (which are actually styled HTML pages that can be printed to PDF):

1. Create HTML templates with proper CSS for printing
2. Use `window.print()` JavaScript function
3. Style with `@media print` CSS rules

Example in `classes/SimplePDFGenerator.php`:
```php
<?php
class SimplePDFGenerator {
    public function generateReceipt($data) {
        $html = '<html><head><style>@media print { /* print styles */ }</style></head>';
        $html .= '<body>' . $this->buildReceiptHTML($data) . '</body></html>';
        return $html;
    }
}
?>
```

## Configuration

After successful installation, the PDFGenerator class should work without modification. The class includes:

- Receipt generation for investments
- Investment statement generation
- Summary report generation
- Proper formatting for Nigerian currency
- Company branding and layout

## Support

If you encounter issues with TCPDF installation:
1. Check the official TCPDF documentation: https://tcpdf.org/docs/
2. Verify PHP version compatibility (PHP 5.5+ required)
3. Ensure all required PHP extensions are installed (GD, mbstring)

---

**Note**: TCPDF is a third-party library and is not included with this application due to licensing considerations. Please download it separately from the official source.
